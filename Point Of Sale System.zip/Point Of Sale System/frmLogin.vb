﻿Public Class frmLogin
    Private attempts As Integer = 0

    Private Sub ShowError(msg As String)
        lblError.Text = msg
        lblError.Visible = True
    End Sub

    Private Sub chkShow_CheckedChanged(sender As Object, e As EventArgs) Handles chkShow.CheckedChanged
        txtPassword.UseSystemPasswordChar = Not chkShow.Checked
    End Sub

    Private Sub txtUsername_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUsername.KeyPress
        If e.KeyChar = " "c Then e.Handled = True
    End Sub

    Private Sub Input_TextChanged(sender As Object, e As EventArgs) _
        Handles txtUsername.TextChanged, txtPassword.TextChanged
        lblError.Visible = False
    End Sub

    Private Sub ReturnToLogin()
        attempts = 0
        AppData.CurrentUser = ""
        txtUsername.Clear()
        txtPassword.Clear()
        lblError.Visible = False
        Me.Show()
        txtUsername.Focus()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim user As String = txtUsername.Text.Trim()
        Dim pass As String = txtPassword.Text

        If user = "" AndAlso pass = "" Then
            ShowError("Please enter your username and password.")
            txtUsername.Focus()
            Exit Sub
        End If
        If user = "" Then
            ShowError("Please enter your username.")
            txtUsername.Focus()
            Exit Sub
        End If
        If pass = "" Then
            ShowError("Please enter your password.")
            txtPassword.Focus()
            Exit Sub
        End If

        Dim acc As Account = AppData.FindAccount(user)
        Dim userOk As Boolean = (acc IsNot Nothing)
        Dim passOk As Boolean = userOk AndAlso (pass = acc.Password)

        If Not passOk Then
            attempts += 1
            Dim left As Integer = 3 - attempts

            If attempts >= 3 Then
                MessageBox.Show("Too many failed attempts. The application will close.",
                                "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Application.Exit()
                Exit Sub
            End If

            ' Clear and focus FIRST, then show the message last
            If userOk Then
                txtPassword.Clear()
                txtPassword.Focus()
                ShowError("Incorrect password. Attempts left: " & left)
            ElseIf AppData.PasswordExists(pass) Then
                txtUsername.Focus()
                txtUsername.SelectAll()
                ShowError("Username not found. Attempts left: " & left)
            Else
                txtUsername.Clear()
                txtPassword.Clear()
                txtUsername.Focus()
                ShowError("Wrong username and password. Attempts left: " & left)
            End If
            Exit Sub
        End If

        If Not acc.Active Then
            txtPassword.Clear()
            txtPassword.Focus()
            ShowError("This account is disabled. Contact the admin.")
            Exit Sub
        End If

        acc.LastLogin = DateTime.Now.ToString("dd/MM HH:mm")
        AppData.CurrentUser = acc.Username

        If acc.Role = "Admin" Then
            Dim adm As New AdminForm()
            AddHandler adm.FormClosed,
                Sub(s As Object, a As FormClosedEventArgs)
                    If adm.LoggedOut Then
                        ReturnToLogin()
                    Else
                        Me.Close()
                    End If
                End Sub
            adm.Show()
        Else
            Dim dash As New frmDashboard()
            dash.lblUser.Text = AppData.DisplayName(AppData.CurrentUser) & " ▾"
            AddHandler dash.FormClosed,
                Sub(s As Object, a As FormClosedEventArgs)
                    If dash.LoggedOut Then
                        ReturnToLogin()
                    Else
                        Me.Close()
                    End If
                End Sub
            dash.Show()
        End If

        Me.Hide()
    End Sub
End Class