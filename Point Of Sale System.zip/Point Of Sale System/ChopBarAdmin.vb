﻿Imports System.Drawing
Imports System.Windows.Forms

''' <summary>
''' ChopBar POS | Admin - code-behind. Reads and writes the shared data in AppData.
''' </summary>
Public Class AdminForm

    Public LoggedOut As Boolean = False

    Private Shared ReadOnly Green As Color = Color.FromArgb(15, 92, 61)
    Private Shared ReadOnly TabIdle As Color = Color.FromArgb(214, 224, 219)
    Private Shared ReadOnly BorderCol As Color = Color.FromArgb(208, 216, 212)
    Private Shared ReadOnly Cedi As String = "GH" & ChrW(&H20B5)
    Private ReadOnly inv As System.Globalization.CultureInfo = System.Globalization.CultureInfo.InvariantCulture
    Private barPct() As Double = {0.0, 0.0, 0.0, 0.0}
    Private selMenuId As Integer = 0

    ' ====================================================================
    ' Load
    ' ====================================================================
    Private Sub AdminForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If DesignMode Then Return

        lblHeaderRight.Text = Date.Now.ToString("ddd, dd MMM yyyy") & "   |   " &
                              AppData.DisplayName(AppData.CurrentUser) & " " & ChrW(&H25BE)
        lblHeaderRight.Left = btnLogout.Left - lblHeaderRight.Width - 14

        Dim sc As Single = CSng(Me.DeviceDpi) / 96.0F
        tabs.DrawMode = TabDrawMode.OwnerDrawFixed
        tpOverview.Text = "Overview"
        tpMenu.Text = "Menu management"
        tpSales.Text = "Sales reports"
        tpStaff.Text = "Staff accounts"
        tabs.ItemSize = New Size(CInt(150 * sc), CInt(36 * sc))
        tabs.Invalidate()

        dtpFrom.Value = Date.Today
        dtpTo.Value = Date.Today
        txtPassword.Clear()
        cboRole.SelectedIndex = 1

        SetPlaceholder(txtSearch, "Search items...")
        SetPlaceholder(txtItemName, "e.g. Kenkey")
        SetPlaceholder(txtUsername, "Username")

        RefreshCashierCombo()
        RefreshAll()
    End Sub

    Private Sub RefreshAll()
        RefreshOverview()
        RefreshMenuGrid()
        RefreshSalesGrid()
        RefreshStaffGrid()
    End Sub

    Private Sub tabs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tabs.SelectedIndexChanged
        If DesignMode Then Return
        RefreshAll()
    End Sub

    ' ====================================================================
    ' Small helpers
    ' ====================================================================
    Private Sub Warn(msg As String)
        MessageBox.Show(msg, "ChopBar POS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    End Sub

    Private Sub Info(msg As String)
        MessageBox.Show(msg, "ChopBar POS", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Function FieldText(tb As TextBox) As String
        If tb.ForeColor = Color.Gray Then Return ""
        Return tb.Text.Trim()
    End Function

    Private Sub SetField(tb As TextBox, value As String)
        tb.ForeColor = Color.Black
        tb.Text = value
    End Sub

    Private Sub ResetPlaceholder(tb As TextBox, hint As String)
        tb.ForeColor = Color.Gray
        tb.Text = hint
    End Sub

    Private Function TypeText(s As SaleRecord) As String
        Return s.OrderType & If(s.Table <> "", " T" & s.Table, "")
    End Function

    Private Sub SetPlaceholder(tb As TextBox, hint As String)
        tb.ForeColor = Color.Gray
        tb.Text = hint
        AddHandler tb.Enter,
            Sub(s As Object, a As EventArgs)
                If tb.ForeColor = Color.Gray Then
                    tb.Text = ""
                    tb.ForeColor = Color.Black
                End If
            End Sub
        AddHandler tb.Leave,
            Sub(s As Object, a As EventArgs)
                If tb.Text.Trim() = "" Then
                    tb.ForeColor = Color.Gray
                    tb.Text = hint
                End If
            End Sub
    End Sub

    ' ====================================================================
    ' Owner-drawn tabs
    ' ====================================================================
    Private Sub tabs_DrawItem(sender As Object, e As DrawItemEventArgs) Handles tabs.DrawItem
        Dim selected As Boolean = (e.Index = tabs.SelectedIndex)
        Dim r As Rectangle = e.Bounds
        Using bg As New SolidBrush(If(selected, Color.White, TabIdle))
            e.Graphics.FillRectangle(bg, r)
        End Using
        Using p As New Pen(BorderCol)
            e.Graphics.DrawRectangle(p, r.X, r.Y, r.Width - 1, r.Height - 1)
        End Using
        Dim caption As String = tabs.TabPages(e.Index).Text
        Dim textColor As Color = If(selected, Green, Color.FromArgb(50, 60, 55))
        Dim fontStyle As FontStyle = If(selected, FontStyle.Bold, FontStyle.Regular)
        Using f As New Font(tabs.Font, fontStyle)
            TextRenderer.DrawText(e.Graphics, caption, f, r, textColor,
                                  TextFormatFlags.HorizontalCenter Or
                                  TextFormatFlags.VerticalCenter Or
                                  TextFormatFlags.NoPadding)
        End Using
    End Sub

    ' ====================================================================
    ' Status colouring (Active/Available = green, Disabled/Sold out = red)
    ' ====================================================================
    Private Sub Grid_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) _
            Handles gridMenu.CellFormatting, gridStaff.CellFormatting
        Dim g As DataGridView = DirectCast(sender, DataGridView)
        If e.RowIndex < 0 OrElse e.Value Is Nothing Then Return
        If g.Columns(e.ColumnIndex).HeaderText <> "Status" Then Return
        Select Case e.Value.ToString()
            Case "Active", "Available"
                e.CellStyle.BackColor = Color.FromArgb(226, 241, 233)
                e.CellStyle.ForeColor = Green
            Case "Disabled", "Sold out"
                e.CellStyle.BackColor = Color.FromArgb(248, 220, 220)
                e.CellStyle.ForeColor = Color.FromArgb(170, 40, 40)
        End Select
    End Sub

    ' ====================================================================
    ' OVERVIEW
    ' ====================================================================
    Private Sub SizeBars()
        Dim tracks() As Panel = {pnlTrack1, pnlTrack2, pnlTrack3, pnlTrack4}
        Dim fills() As Panel = {pnlFill1, pnlFill2, pnlFill3, pnlFill4}
        For i As Integer = 0 To 3
            fills(i).Width = CInt(tracks(i).Width * barPct(i))
        Next
    End Sub

    Private Sub cardCategory_Resize(sender As Object, e As EventArgs) Handles cardCategory.Resize
        SizeBars()
    End Sub

    Private Sub RefreshOverview()
        Dim today As Date = Date.Today
        Dim sum As Decimal = 0D
        Dim count As Integer = 0
        Dim qtyByItem As New Dictionary(Of String, Integer)
        Dim amtByCat As New Dictionary(Of String, Decimal)

        For Each s As SaleRecord In AppData.SalesList
            If s.SoldAt.Date <> today Then Continue For
            count += 1
            sum += s.Total
            For Each ln As SaleLine In s.Lines
                If qtyByItem.ContainsKey(ln.Name) Then
                    qtyByItem(ln.Name) += ln.Qty
                Else
                    qtyByItem(ln.Name) = ln.Qty
                End If
                If amtByCat.ContainsKey(ln.Category) Then
                    amtByCat(ln.Category) += ln.Amount
                Else
                    amtByCat(ln.Category) = ln.Amount
                End If
            Next
        Next

        Dim bestItem As String = "-"
        Dim bestQty As Integer = 0
        For Each kv As KeyValuePair(Of String, Integer) In qtyByItem
            If kv.Value > bestQty Then
                bestQty = kv.Value
                bestItem = kv.Key
            End If
        Next

        ovVal1.Text = Cedi & sum.ToString("0.00")
        ovVal2.Text = count.ToString()
        ovVal3.Text = bestItem
        ovVal4.Text = AppData.SoldOutCount().ToString()

        ' Recent sales (latest 8)
        gridRecent.Rows.Clear()
        Dim stopAt As Integer = Math.Max(0, AppData.SalesList.Count - 8)
        For i As Integer = AppData.SalesList.Count - 1 To stopAt Step -1
            Dim s As SaleRecord = AppData.SalesList(i)
            gridRecent.Rows.Add(s.Ticket.ToString("000"), s.SoldAt.ToString("HH:mm"),
                                TypeText(s), s.Method, Cedi & s.Total.ToString("0.00"))
        Next
        gridRecent.ClearSelection()

        ' Sales by category (top 4 today)
        Dim names As New List(Of String)(amtByCat.Keys)
        Dim lblCats() As Label = {lblCat1, lblCat2, lblCat3, lblCat4}
        Dim maxAmt As Decimal = 0D
        For i As Integer = 0 To 3
            Dim bestName As String = Nothing
            Dim bestAmt As Decimal = -1D
            For Each n As String In names
                If amtByCat(n) > bestAmt Then
                    bestAmt = amtByCat(n)
                    bestName = n
                End If
            Next
            If bestName Is Nothing Then
                lblCats(i).Text = "-"
                barPct(i) = 0.0
            Else
                If i = 0 Then maxAmt = bestAmt
                lblCats(i).Text = bestName
                barPct(i) = If(maxAmt > 0D, CDbl(bestAmt / maxAmt), 0.0)
                names.Remove(bestName)
            End If
        Next
        SizeBars()
    End Sub

    ' ====================================================================
    ' MENU MANAGEMENT
    ' ====================================================================
    Private Sub RefreshMenuGrid()
        Dim q As String = FieldText(txtSearch).ToLower()
        gridMenu.Rows.Clear()
        For Each m As MenuEntry In AppData.MenuList
            If q <> "" AndAlso Not m.Name.ToLower().Contains(q) Then Continue For
            Dim idx As Integer = gridMenu.Rows.Add(m.Name, m.Category, Cedi & m.Price.ToString("0.00"),
                                                   If(m.SoldOut, "Sold out", "Available"))
            gridMenu.Rows(idx).Tag = m.Id
        Next
        gridMenu.ClearSelection()
    End Sub

    Private Sub ClearMenuForm()
        selMenuId = 0
        ResetPlaceholder(txtItemName, "e.g. Kenkey")
        cboCategory.SelectedIndex = -1
        txtPrice.Text = "0.00"
        btnSoldOut.Text = "Mark sold out"
        gridMenu.ClearSelection()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If DesignMode Then Return
        RefreshMenuGrid()
    End Sub

    Private Sub txtPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPrice.KeyPress
        If e.KeyChar = ChrW(Keys.Back) Then Return
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then e.Handled = True
        If e.KeyChar = "."c AndAlso txtPrice.Text.Contains(".") Then e.Handled = True
    End Sub

    Private Sub gridMenu_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridMenu.CellClick
        If e.RowIndex < 0 Then Return
        Dim m As MenuEntry = AppData.FindMenuById(CInt(gridMenu.Rows(e.RowIndex).Tag))
        If m Is Nothing Then Return
        selMenuId = m.Id
        SetField(txtItemName, m.Name)
        cboCategory.SelectedIndex = cboCategory.FindStringExact(m.Category)
        txtPrice.Text = m.Price.ToString("0.00")
        btnSoldOut.Text = If(m.SoldOut, "Mark available", "Mark sold out")
    End Sub

    Private Sub btnSaveItem_Click(sender As Object, e As EventArgs) Handles btnSaveItem.Click
        Dim nm As String = FieldText(txtItemName)
        If nm = "" Then
            Warn("Enter the item name.")
            txtItemName.Focus()
            Return
        End If
        If nm.Contains("|") Then
            Warn("The item name cannot contain the | character.")
            Return
        End If
        If cboCategory.SelectedIndex < 0 Then
            Warn("Choose a category.")
            Return
        End If
        Dim price As Decimal = 0D
        If Not Decimal.TryParse(txtPrice.Text.Trim(), Globalization.NumberStyles.Number, inv, price) OrElse price <= 0D Then
            Warn("Enter a valid price greater than 0.")
            txtPrice.Focus()
            Return
        End If
        Dim other As MenuEntry = AppData.FindMenu(nm)
        If other IsNot Nothing AndAlso other.Id <> selMenuId Then
            Warn("An item with that name already exists.")
            Return
        End If

        Dim cat As String = CStr(cboCategory.SelectedItem)
        If selMenuId <> 0 Then
            Dim m As MenuEntry = AppData.FindMenuById(selMenuId)
            If m IsNot Nothing Then
                m.Name = nm
                m.Category = cat
                m.Price = price
            End If
        Else
            AppData.MenuList.Add(New MenuEntry With {
                .Id = AppData.NextMenuId(), .Name = nm, .Category = cat, .Price = price})
        End If

        RefreshMenuGrid()
        ClearMenuForm()
        RefreshOverview()
        Info("Item saved. The cashier sees it the next time they log in.")
    End Sub

    Private Sub btnSoldOut_Click(sender As Object, e As EventArgs) Handles btnSoldOut.Click
        Dim m As MenuEntry = AppData.FindMenuById(selMenuId)
        If m Is Nothing Then
            Warn("Click an item in the table first.")
            Return
        End If
        m.SoldOut = Not m.SoldOut
        RefreshMenuGrid()
        ClearMenuForm()
        RefreshOverview()
    End Sub

    Private Sub btnDeleteItem_Click(sender As Object, e As EventArgs) Handles btnDeleteItem.Click
        Dim m As MenuEntry = AppData.FindMenuById(selMenuId)
        If m Is Nothing Then
            Warn("Click an item in the table first.")
            Return
        End If
        If MessageBox.Show("Delete " & m.Name & " from the menu?", "Delete item",
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) <> DialogResult.Yes Then Return
        AppData.MenuList.Remove(m)
        RefreshMenuGrid()
        ClearMenuForm()
        RefreshOverview()
    End Sub

    ' ====================================================================
    ' SALES REPORTS
    ' ====================================================================
    Private Sub RefreshCashierCombo()
        Dim keep As String = cboCashier.Text
        cboCashier.Items.Clear()
        cboCashier.Items.Add("All")
        For Each a As Account In AppData.Accounts
            If a.Role = "Cashier" Then cboCashier.Items.Add(a.Username)
        Next
        Dim i As Integer = cboCashier.FindStringExact(keep)
        cboCashier.SelectedIndex = If(i >= 0, i, 0)
    End Sub

    Private Function FilteredSales() As List(Of SaleRecord)
        Dim result As New List(Of SaleRecord)
        Dim d1 As Date = dtpFrom.Value.Date
        Dim d2 As Date = dtpTo.Value.Date
        Dim who As String = cboCashier.Text
        For Each s As SaleRecord In AppData.SalesList
            If s.SoldAt.Date < d1 OrElse s.SoldAt.Date > d2 Then Continue For
            If who <> "" AndAlso who <> "All" AndAlso
               Not String.Equals(s.Cashier, who, StringComparison.OrdinalIgnoreCase) Then Continue For
            result.Add(s)
        Next
        Return result
    End Function

    Private Sub RefreshSalesGrid()
        Dim list As List(Of SaleRecord) = FilteredSales()
        Dim total As Decimal = 0D
        Dim cash As Decimal = 0D
        Dim momo As Decimal = 0D
        Dim dine As Integer = 0
        Dim take As Integer = 0

        gridSales.Rows.Clear()
        For i As Integer = list.Count - 1 To 0 Step -1
            Dim s As SaleRecord = list(i)
            gridSales.Rows.Add(s.Ticket.ToString("000"), s.SoldAt.ToString("dd/MM HH:mm"),
                               s.Cashier, s.Customer, TypeText(s), s.Items, s.Method,
                               Cedi & s.Total.ToString("0.00"))
        Next
        For Each s As SaleRecord In list
            total += s.Total
            If s.Method = "Cash" Then cash += s.Total
            If s.Method = "Mobile Money" Then momo += s.Total
            If s.OrderType = "Take Away" Then take += 1 Else dine += 1
        Next
        gridSales.ClearSelection()

        saVal1.Text = Cedi & total.ToString("0.00")
        saVal2.Text = Cedi & cash.ToString("0.00")
        saVal3.Text = Cedi & momo.ToString("0.00")
        saVal4.Text = dine & " / " & take
    End Sub

    Private Sub btnFilter_Click(sender As Object, e As EventArgs) Handles btnFilter.Click
        If dtpFrom.Value.Date > dtpTo.Value.Date Then
            Warn("The From date cannot be after the To date.")
            Return
        End If
        RefreshSalesGrid()
    End Sub

    Private Sub btnDaily_Click(sender As Object, e As EventArgs) Handles btnDaily.Click
        Dim count As Integer = 0
        Dim total As Decimal = 0D
        Dim dine As Integer = 0
        Dim take As Integer = 0
        Dim cash As Decimal = 0D
        Dim momo As Decimal = 0D
        Dim card As Decimal = 0D
        Dim bank As Decimal = 0D
        For Each s As SaleRecord In AppData.SalesList
            If s.SoldAt.Date <> Date.Today Then Continue For
            count += 1
            total += s.Total
            If s.OrderType = "Take Away" Then take += 1 Else dine += 1
            Select Case s.Method
                Case "Cash"
                    cash += s.Total
                Case "Mobile Money"
                    momo += s.Total
                Case "Card"
                    card += s.Total
                Case Else
                    bank += s.Total
            End Select
        Next
        MessageBox.Show("DAILY REPORT - " & Date.Today.ToString("dd MMM yyyy") & vbCrLf &
                        "All cashiers" & vbCrLf &
                        "----------------------------" & vbCrLf &
                        "Total Sales: " & Cedi & total.ToString("0.00") & vbCrLf &
                        "Total Orders: " & count & vbCrLf &
                        "   Dine In: " & dine & vbCrLf &
                        "   Take Away: " & take & vbCrLf &
                        "Average Order: " & Cedi & If(count = 0, 0D, total / count).ToString("0.00") & vbCrLf &
                        "Cash: " & Cedi & cash.ToString("0.00") & vbCrLf &
                        "Mobile Money: " & Cedi & momo.ToString("0.00") & vbCrLf &
                        "Card: " & Cedi & card.ToString("0.00") & vbCrLf &
                        "Bank Transfer: " & Cedi & bank.ToString("0.00"),
                        "Daily Report", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Function Csv(text As String) As String
        Return """" & text.Replace("""", """""") & """"
    End Function

    Private Sub btnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click
        Dim list As List(Of SaleRecord) = FilteredSales()
        If list.Count = 0 Then
            Warn("There are no sales to export for this filter.")
            Return
        End If

        Using dlg As New SaveFileDialog()
            dlg.Filter = "CSV file (*.csv)|*.csv"
            dlg.FileName = "ChopBar_Sales_" & Date.Today.ToString("yyyy-MM-dd") & ".csv"
            If dlg.ShowDialog(Me) <> DialogResult.OK Then Return

            Dim sb As New System.Text.StringBuilder()
            sb.AppendLine("Ticket,Date,Time,Cashier,Customer,Order Type,Table,Items,Payment Method,Total")
            For Each s As SaleRecord In list
                sb.AppendLine(String.Join(",", New String() {
                    s.Ticket.ToString("000"), s.SoldAt.ToString("yyyy-MM-dd"), s.SoldAt.ToString("HH:mm"),
                    Csv(s.Cashier), Csv(s.Customer), s.OrderType, s.Table, Csv(s.Items),
                    s.Method, s.Total.ToString("0.00", inv)}))
            Next
            Try
                System.IO.File.WriteAllText(dlg.FileName, sb.ToString(), New System.Text.UTF8Encoding(True))
                Info("Sales exported to " & dlg.FileName)
            Catch ex As Exception
                Warn("Could not save the file: " & ex.Message)
            End Try
        End Using
    End Sub

    ' ====================================================================
    ' STAFF ACCOUNTS
    ' ====================================================================
    Private Sub RefreshStaffGrid()
        gridStaff.Rows.Clear()
        For Each a As Account In AppData.Accounts
            gridStaff.Rows.Add(a.Username, a.Role, If(a.Active, "Active", "Disabled"), a.LastLogin)
        Next
        gridStaff.ClearSelection()
    End Sub

    Private Sub ClearStaffForm()
        ResetPlaceholder(txtUsername, "Username")
        txtPassword.Clear()
        cboRole.SelectedIndex = 1
        btnDisable.Text = "Disable"
        gridStaff.ClearSelection()
    End Sub

    Private Sub txtUsername_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUsername.KeyPress
        If e.KeyChar = " "c Then e.Handled = True
    End Sub

    Private Sub gridStaff_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridStaff.CellClick
        If e.RowIndex < 0 Then Return
        Dim a As Account = AppData.FindAccount(CStr(gridStaff.Rows(e.RowIndex).Cells(0).Value))
        If a Is Nothing Then Return
        SetField(txtUsername, a.Username)
        cboRole.SelectedIndex = cboRole.FindStringExact(a.Role)
        txtPassword.Clear()
        btnDisable.Text = If(a.Active, "Disable", "Enable")
    End Sub

    Private Sub btnSaveAccount_Click(sender As Object, e As EventArgs) Handles btnSaveAccount.Click
        Dim user As String = FieldText(txtUsername)
        Dim pass As String = txtPassword.Text
        Dim role As String = If(cboRole.SelectedIndex >= 0, CStr(cboRole.SelectedItem), "Cashier")
        Dim msg As String

        If user = "" Then
            Warn("Enter a username.")
            txtUsername.Focus()
            Return
        End If
        If user.Contains(" ") Then
            Warn("Usernames cannot contain spaces.")
            Return
        End If

        Dim acc As Account = AppData.FindAccount(user)
        If acc Is Nothing Then
            If pass.Length < 4 Then
                Warn("Enter a password of at least 4 characters for the new account.")
                txtPassword.Focus()
                Return
            End If
            AppData.Accounts.Add(New Account With {.Username = user, .Password = pass, .Role = role})
            msg = "Account created."
        Else
            If String.Equals(acc.Username, AppData.CurrentUser, StringComparison.OrdinalIgnoreCase) AndAlso role <> acc.Role Then
                Warn("You cannot change your own role.")
                Return
            End If
            If acc.Role = "Admin" AndAlso role <> "Admin" AndAlso acc.Active AndAlso AppData.ActiveAdminCount() <= 1 Then
                Warn("There must be at least one active admin.")
                Return
            End If
            If pass <> "" Then
                If pass.Length < 4 Then
                    Warn("The password must be at least 4 characters.")
                    txtPassword.Focus()
                    Return
                End If
                acc.Password = pass
            End If
            acc.Role = role
            msg = "Account updated."
        End If

        RefreshStaffGrid()
        RefreshCashierCombo()
        ClearStaffForm()
        Info(msg)
    End Sub

    Private Sub btnResetPwd_Click(sender As Object, e As EventArgs) Handles btnResetPwd.Click
        Dim acc As Account = AppData.FindAccount(FieldText(txtUsername))
        If acc Is Nothing Then
            Warn("Click an account in the table first.")
            Return
        End If
        acc.Password = "1234"
        Info("The password for " & acc.Username & " was reset to 1234.")
    End Sub

    Private Sub btnDisable_Click(sender As Object, e As EventArgs) Handles btnDisable.Click
        Dim acc As Account = AppData.FindAccount(FieldText(txtUsername))
        If acc Is Nothing Then
            Warn("Click an account in the table first.")
            Return
        End If

        If acc.Active Then
            If String.Equals(acc.Username, AppData.CurrentUser, StringComparison.OrdinalIgnoreCase) Then
                Warn("You cannot disable your own account.")
                Return
            End If
            If acc.Role = "Admin" AndAlso AppData.ActiveAdminCount() <= 1 Then
                Warn("There must be at least one active admin.")
                Return
            End If
            acc.Active = False
        Else
            acc.Active = True
        End If

        RefreshStaffGrid()
        ClearStaffForm()
    End Sub

    ' ====================================================================
    ' Logout
    ' ====================================================================
    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        If MessageBox.Show("Are you sure you want to log out?", "Logout",
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            LoggedOut = True
            Me.Close()
        End If
    End Sub

End Class