﻿Public Class frmDashboard

    ' ================= DATA =================
    Private Class OrderLine
        Public BasePrice As Decimal
        Public Extra As Decimal
        Public SizeAdj As Decimal
        Public Size As String = "Regular"
        Public Protein As String = ""
        Public Extras As New List(Of String)
        Public Note As String = ""
        Public ReadOnly Property Unit As Decimal
            Get
                Return BasePrice + SizeAdj + Extra
            End Get
        End Property
    End Class

    Private Const Cedi As String = "GH₵"
    Private Const PackFee As Decimal = 2D
    Private currentCat As String = "All"
    Private ready As Boolean = False
    Private receiptText As String = ""
    Private ReadOnly cms As New ContextMenuStrip()
    Private WithEvents pd As New System.Drawing.Printing.PrintDocument()

    Public LoggedOut As Boolean = False

    ' ================= LOAD =================
    Private Sub frmDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblDate.Text = "Today: " & Date.Today.ToString("dd MMM yyyy")

        rbAll.Tag = "All"
        rbBanku.Tag = "Banku"
        rbWaakye.Tag = "Waakye"
        rbJollof.Tag = "Jollof"
        rbFufu.Tag = "Fufu"
        rbDrinks.Tag = "Drinks"
        rbOthers.Tag = "Others"

        Dim miStock As New ToolStripMenuItem("Mark as sold out / available")
        AddHandler miStock.Click, AddressOf ToggleStock
        cms.Items.Add(miStock)

        BuildMenuButtons()

        rbAll.Checked = True
        rbCash.Checked = True
        rbDineIn.Checked = True
        rbAll.ForeColor = Color.White
        rbCash.ForeColor = Color.White
        rbDineIn.ForeColor = Color.White
        rbRegular.ForeColor = Color.White

        dtpFrom.Value = Date.Today
        dtpTo.Value = Date.Today

        FilterMeals("All")
        ShowHistory(False)
        RefreshStats()
        ready = True
        UpdateTotals()
        RestoreCustomization()
    End Sub

    ' ================= LOGOUT =================
    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Dim msg As String = If(lvOrder.Items.Count > 0,
                               "You have an unpaid order. Log out and discard it?",
                               "Are you sure you want to log out?")
        If MessageBox.Show(msg, "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            LoggedOut = True
            Me.Close()
        End If
    End Sub

    ' ================= MEAL BUTTONS (built from the shared menu) =================
    Private Sub BuildMenuButtons()
        ' Copy the look of the first designer button, then rebuild from the shared menu
        Dim sz As New Size(100, 100)
        Dim fnt As Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)
        Dim mg As New Padding(3)
        Dim bdr As Color = Color.FromArgb(200, 205, 210)
        Dim hov As Color = Color.FromArgb(231, 241, 236)
        Dim down As Color = Color.FromArgb(231, 241, 236)
        Dim bdrSize As Integer = 1

        Dim first As Button = Nothing
        For Each c As Control In flpMeals.Controls
            If TypeOf c Is Button Then
                first = DirectCast(c, Button)
                Exit For
            End If
        Next
        If first IsNot Nothing Then
            sz = first.Size
            fnt = DirectCast(first.Font.Clone(), Font)
            mg = first.Margin
            bdr = first.FlatAppearance.BorderColor
            hov = first.FlatAppearance.MouseOverBackColor
            down = first.FlatAppearance.MouseDownBackColor
            bdrSize = first.FlatAppearance.BorderSize
        End If

        Dim oldControls(flpMeals.Controls.Count - 1) As Control
        flpMeals.Controls.CopyTo(oldControls, 0)
        flpMeals.Controls.Clear()
        For Each c As Control In oldControls
            c.Dispose()
        Next

        For Each m As MenuEntry In AppData.MenuList
            Dim b As New Button()
            b.Size = sz
            b.Font = fnt
            b.Margin = mg
            b.FlatStyle = FlatStyle.Flat
            b.FlatAppearance.BorderColor = bdr
            b.FlatAppearance.BorderSize = bdrSize
            b.FlatAppearance.MouseOverBackColor = hov
            b.FlatAppearance.MouseDownBackColor = down
            b.UseVisualStyleBackColor = False
            b.BackColor = Color.White
            b.ForeColor = Color.FromArgb(31, 41, 51)
            b.Cursor = Cursors.Hand
            b.TextAlign = ContentAlignment.MiddleCenter
            b.Tag = m.Name & "|" & m.Price.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) & "|" & m.Category
            AddHandler b.Click, AddressOf MealButton_Click
            b.ContextMenuStrip = cms
            RefreshMealButton(b)
            flpMeals.Controls.Add(b)
        Next
    End Sub

    Private Sub FilterMeals(cat As String)
        currentCat = cat
        Dim q As String = txtSearch.Text.Trim().ToLower()
        For Each c As Control In flpMeals.Controls
            Dim parts() As String = CStr(c.Tag).Split("|"c)
            Dim okCat As Boolean = (q <> "") OrElse (cat = "All") OrElse (parts.Length = 3 AndAlso parts(2) = cat)
            Dim okName As Boolean = (q = "") OrElse parts(0).ToLower().Contains(q)
            c.Visible = okCat AndAlso okName
        Next
        UpdateMealCount()
    End Sub

    Private Sub UpdateMealCount()
        Dim shown As Integer = 0
        For Each c As Control In flpMeals.Controls
            If c.Visible Then shown += 1
        Next
        lblMealCount.Text = "Showing " & shown & " of " & flpMeals.Controls.Count &
                            "   |   Sold out: " & AppData.SoldOutCount()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        FilterMeals(currentCat)
    End Sub

    Private Sub MealButton_Click(sender As Object, e As EventArgs)
        Dim b As Button = DirectCast(sender, Button)
        Dim nm As String = CStr(b.Tag).Split("|"c)(0)
        Dim m As MenuEntry = AppData.FindMenu(nm)
        If m Is Nothing Then Exit Sub
        If m.SoldOut Then
            MessageBox.Show(m.Name & " is sold out.", "Sold Out", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        AddToOrder(m.Name, m.Price)
    End Sub

    Private Sub RefreshMealButton(b As Button)
        Dim nm As String = CStr(b.Tag).Split("|"c)(0)
        Dim m As MenuEntry = AppData.FindMenu(nm)
        If m Is Nothing Then
            b.Text = nm
            Exit Sub
        End If
        If m.SoldOut Then
            b.Text = m.Name & vbCrLf & "SOLD OUT"
            b.BackColor = Color.FromArgb(235, 235, 235)
            b.ForeColor = Color.FromArgb(150, 150, 150)
        Else
            b.Text = m.Name & vbCrLf & Cedi & m.Price.ToString("0.00")
            b.BackColor = Color.White
            b.ForeColor = Color.FromArgb(31, 41, 51)
        End If
    End Sub

    Private Sub ToggleStock(sender As Object, e As EventArgs)
        Dim owner As ContextMenuStrip = DirectCast(DirectCast(sender, ToolStripMenuItem).Owner, ContextMenuStrip)
        Dim b As Button = TryCast(owner.SourceControl, Button)
        If b Is Nothing Then Exit Sub
        Dim m As MenuEntry = AppData.FindMenu(CStr(b.Tag).Split("|"c)(0))
        If m Is Nothing Then Exit Sub
        m.SoldOut = Not m.SoldOut
        RefreshMealButton(b)
        UpdateMealCount()
    End Sub

    ' ================= TOGGLES (MENU / PAYMENT / ORDER TYPE) =================
    Private Sub Category_CheckedChanged(sender As Object, e As EventArgs) _
        Handles rbAll.CheckedChanged, rbBanku.CheckedChanged, rbWaakye.CheckedChanged,
                rbJollof.CheckedChanged, rbFufu.CheckedChanged, rbDrinks.CheckedChanged,
                rbOthers.CheckedChanged
        Dim rb As RadioButton = DirectCast(sender, RadioButton)
        rb.ForeColor = If(rb.Checked, Color.White, Color.FromArgb(31, 41, 51))
        If rb.Checked AndAlso rb.Tag IsNot Nothing Then FilterMeals(CStr(rb.Tag))
    End Sub

    Private Sub PayMethod_CheckedChanged(sender As Object, e As EventArgs) _
        Handles rbCash.CheckedChanged, rbMoMo.CheckedChanged,
                rbCard.CheckedChanged, rbBank.CheckedChanged
        Dim rb As RadioButton = DirectCast(sender, RadioButton)
        rb.ForeColor = If(rb.Checked, Color.White, Color.FromArgb(31, 41, 51))
    End Sub

    Private Sub OrderType_CheckedChanged(sender As Object, e As EventArgs) _
        Handles rbDineIn.CheckedChanged, rbTakeAway.CheckedChanged
        Dim rb As RadioButton = DirectCast(sender, RadioButton)
        rb.ForeColor = If(rb.Checked, Color.White, Color.FromArgb(31, 41, 51))
        lblTableCap.Visible = rbDineIn.Checked
        txtTable.Visible = rbDineIn.Checked
        If Not rbDineIn.Checked Then txtTable.Clear()
        If ready Then UpdateTotals()
    End Sub

    Private Function SelectedMethod() As String
        If rbCash.Checked Then Return "Cash"
        If rbMoMo.Checked Then Return "Mobile Money"
        If rbCard.Checked Then Return "Card"
        Return "Bank Transfer"
    End Function

    Private Function SelectedOrderType() As String
        Return If(rbTakeAway.Checked, "Take Away", "Dine In")
    End Function

    ' ================= CURRENT ORDER =================
    Private Sub AddToOrder(itemName As String, price As Decimal)
        Dim qty As Integer = CInt(nudQty.Value)

        For Each item As ListViewItem In lvOrder.Items
            If item.Text = itemName AndAlso item.SubItems(4).Text = "None" Then
                Dim newQty As Integer = CInt(item.SubItems(2).Text) + qty
                item.SubItems(2).Text = newQty.ToString()
                item.SubItems(3).Text = Cedi & (newQty * price).ToString("0.00")
                nudQty.Value = 1
                UpdateTotals()
                Exit Sub
            End If
        Next

        Dim li As New ListViewItem(itemName)
        li.Tag = New OrderLine With {.BasePrice = price}
        li.SubItems.Add(Cedi & price.ToString("0.00"))
        li.SubItems.Add(qty.ToString())
        li.SubItems.Add(Cedi & (qty * price).ToString("0.00"))
        li.SubItems.Add("None")
        lvOrder.Items.Add(li)

        nudQty.Value = 1
        UpdateTotals()
    End Sub

    ' ----- money: subtotal, discount, packaging fee, final total -----
    Private Function GetSubtotal() As Decimal
        Dim total As Decimal = 0D
        For Each item As ListViewItem In lvOrder.Items
            total += CType(item.Tag, OrderLine).Unit * CInt(item.SubItems(2).Text)
        Next
        Return total
    End Function

    Private Function DiscountPercent() As Decimal
        Dim p As Decimal = 0D
        Decimal.TryParse(txtDiscount.Text.Trim(), System.Globalization.NumberStyles.Number,
                         System.Globalization.CultureInfo.InvariantCulture, p)
        If p < 0D Then p = 0D
        If p > 100D Then p = 100D
        Return p
    End Function

    Private Function DiscountAmount(subtotal As Decimal) As Decimal
        Return Math.Round(subtotal * DiscountPercent() / 100D, 2)
    End Function

    Private Function FeeAmount(subtotal As Decimal) As Decimal
        Return If(subtotal > 0D AndAlso rbTakeAway.Checked, PackFee, 0D)
    End Function

    Private Function GetTotal() As Decimal
        Dim subtotal As Decimal = GetSubtotal()
        Return subtotal - DiscountAmount(subtotal) + FeeAmount(subtotal)
    End Function

    Private Sub UpdateTotals()
        Dim subtotal As Decimal = GetSubtotal()
        Dim disc As Decimal = DiscountAmount(subtotal)
        Dim fee As Decimal = FeeAmount(subtotal)
        lblTotal.Text = Cedi & (subtotal - disc + fee).ToString("0.00")
        If subtotal = 0D Then
            lblBreakdown.Text = ""
        Else
            lblBreakdown.Text = "Sub " & subtotal.ToString("0.00") &
                                "   Disc -" & disc.ToString("0.00") &
                                "   Fee +" & fee.ToString("0.00")
        End If
        CalculateChange()
    End Sub

    Private Sub CalculateChange()
        Dim total As Decimal = GetTotal()
        Dim paid As Decimal = 0D
        Decimal.TryParse(txtPaid.Text.Trim(), paid)
        If total > 0 AndAlso paid >= total Then
            lblChange.Text = Cedi & (paid - total).ToString("0.00")
        Else
            lblChange.Text = Cedi & "0.00"
        End If
    End Sub

    Private Sub ResetOrder()
        lvOrder.Items.Clear()
        txtPaid.Clear()
        txtDiscount.Clear()
        txtTable.Clear()
        nudQty.Value = 1
        rbDineIn.Checked = True
        UpdateTotals()
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If lvOrder.SelectedItems.Count = 0 Then
            MessageBox.Show("Please select an item from the list to remove.",
                            "Validation Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        lvOrder.SelectedItems(0).Remove()
        UpdateTotals()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        If lvOrder.Items.Count = 0 Then Exit Sub
        If MessageBox.Show("Are you sure you want to clear the entire order?", "Confirm Clear",
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            ResetOrder()
        End If
    End Sub

    ' ================= NUMBER-ONLY BOXES =================
    Private Sub Amount_KeyPress(sender As Object, e As KeyPressEventArgs) _
        Handles txtPaid.KeyPress, txtAmount.KeyPress, txtDiscount.KeyPress
        Dim tb As TextBox = DirectCast(sender, TextBox)
        If e.KeyChar = ChrW(Keys.Back) Then Exit Sub
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then e.Handled = True
        If e.KeyChar = "."c AndAlso tb.Text.Contains(".") Then e.Handled = True
    End Sub

    Private Sub txtTable_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTable.KeyPress
        If e.KeyChar = ChrW(Keys.Back) Then Exit Sub
        If Not Char.IsDigit(e.KeyChar) Then e.Handled = True
    End Sub

    Private Sub txtPaid_TextChanged(sender As Object, e As EventArgs) Handles txtPaid.TextChanged
        If txtAmount.Text <> txtPaid.Text Then txtAmount.Text = txtPaid.Text
        CalculateChange()
    End Sub

    Private Sub txtAmount_TextChanged(sender As Object, e As EventArgs) Handles txtAmount.TextChanged
        If txtPaid.Text <> txtAmount.Text Then txtPaid.Text = txtAmount.Text
    End Sub

    Private Sub txtDiscount_TextChanged(sender As Object, e As EventArgs) Handles txtDiscount.TextChanged
        Dim p As Decimal = 0D
        If Decimal.TryParse(txtDiscount.Text.Trim(), System.Globalization.NumberStyles.Number,
                            System.Globalization.CultureInfo.InvariantCulture, p) AndAlso p > 100D Then
            txtDiscount.Text = "100"
            txtDiscount.SelectionStart = txtDiscount.Text.Length
        End If
        If ready Then UpdateTotals()
    End Sub

    ' ================= RECEIPT (BUILD + PREVIEW + PRINT) =================
    Private Function Pad2(leftText As String, rightText As String, width As Integer) As String
        Dim space As Integer = width - rightText.Length
        If leftText.Length > space - 1 Then leftText = leftText.Substring(0, space - 1)
        Return leftText.PadRight(space) & rightText
    End Function

    Private Sub AppendWrapped(sb As System.Text.StringBuilder, text As String, indent As String, width As Integer)
        Dim chunk As Integer = width - indent.Length
        Dim i As Integer = 0
        Do While i < text.Length
            Dim len As Integer = Math.Min(chunk, text.Length - i)
            sb.AppendLine(indent & text.Substring(i, len))
            i += len
        Loop
    End Sub

    Private Function BuildReceipt(ticket As Integer, subtotal As Decimal, disc As Decimal,
                                  fee As Decimal, total As Decimal, paid As Decimal) As String
        Const w As Integer = 34
        Dim sep As String = New String("-"c, w)
        Dim sb As New System.Text.StringBuilder()

        sb.AppendLine("CHOPBAR POS".PadLeft((w + 11) \ 2))
        sb.AppendLine("RECEIPT".PadLeft((w + 7) \ 2))
        sb.AppendLine(sep)
        sb.AppendLine("Ticket No : " & ticket.ToString("000"))
        Dim typeText As String = SelectedOrderType()
        If rbDineIn.Checked AndAlso txtTable.Text.Trim() <> "" Then typeText &= " (Table " & txtTable.Text.Trim() & ")"
        sb.AppendLine("Order Type: " & typeText)
        sb.AppendLine("Date      : " & DateTime.Now.ToString("dd MMM yyyy HH:mm"))
        sb.AppendLine("Cashier   : " & AppData.DisplayName(AppData.CurrentUser))
        sb.AppendLine(sep)

        For Each item As ListViewItem In lvOrder.Items
            sb.AppendLine(Pad2(item.Text & " x" & item.SubItems(2).Text, item.SubItems(3).Text, w))
            If item.SubItems(4).Text <> "None" Then
                AppendWrapped(sb, item.SubItems(4).Text, "  ", w)
            End If
        Next

        sb.AppendLine(sep)
        sb.AppendLine(Pad2("Subtotal", Cedi & subtotal.ToString("0.00"), w))
        If disc > 0D Then
            sb.AppendLine(Pad2("Discount (" & DiscountPercent().ToString("0.##") & "%)", "-" & Cedi & disc.ToString("0.00"), w))
        End If
        If fee > 0D Then
            sb.AppendLine(Pad2("Take-Away Pack", Cedi & fee.ToString("0.00"), w))
        End If
        sb.AppendLine(Pad2("TOTAL", Cedi & total.ToString("0.00"), w))
        sb.AppendLine(Pad2("Paid", Cedi & paid.ToString("0.00"), w))
        sb.AppendLine(Pad2("Change", Cedi & (paid - total).ToString("0.00"), w))
        sb.AppendLine("Method: " & SelectedMethod())
        sb.AppendLine(sep)
        sb.AppendLine("Thank you. Enjoy your meal!".PadLeft((w + 27) \ 2))
        Return sb.ToString()
    End Function

    Private Sub pd_PrintPage(sender As Object, e As System.Drawing.Printing.PrintPageEventArgs) Handles pd.PrintPage
        Using f As New Font("Courier New", 10)
            e.Graphics.DrawString(receiptText, f, Brushes.Black, 20, 20)
        End Using
        e.HasMorePages = False
    End Sub

    Private Sub ShowReceipt(text As String, ticket As Integer)
        receiptText = text
        Using dlg As New PrintPreviewDialog()
            dlg.Document = pd
            dlg.Text = "Receipt - Ticket " & ticket.ToString("000")
            dlg.Width = 520
            dlg.Height = 720
            dlg.StartPosition = FormStartPosition.CenterParent
            dlg.ShowDialog(Me)
        End Using
    End Sub

    ' ================= PAYMENT =================
    Private Sub Pay_Click(sender As Object, e As EventArgs) Handles btnPay.Click, btnComplete.Click
        If lvOrder.Items.Count = 0 Then
            MessageBox.Show("Please add at least one item to the order.",
                            "Empty Order", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim paid As Decimal = 0D
        If Not Decimal.TryParse(txtPaid.Text.Trim(), paid) OrElse paid <= 0 Then
            MessageBox.Show("Please enter a valid amount paid.",
                            "Invalid Payment", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPaid.Focus()
            Exit Sub
        End If

        Dim subtotal As Decimal = GetSubtotal()
        Dim disc As Decimal = DiscountAmount(subtotal)
        Dim fee As Decimal = FeeAmount(subtotal)
        Dim total As Decimal = subtotal - disc + fee

        If paid < total Then
            MessageBox.Show("Payment is insufficient! Short by " & Cedi & (total - paid).ToString("0.00"),
                            "Insufficient Payment", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPaid.Focus()
            Exit Sub
        End If

        Dim ticket As Integer = AppData.NextTicket()
        ShowReceipt(BuildReceipt(ticket, subtotal, disc, fee, total, paid), ticket)

        Dim names As New List(Of String)
        Dim lines As New List(Of SaleLine)
        For Each item As ListViewItem In lvOrder.Items
            Dim q As Integer = CInt(item.SubItems(2).Text)
            names.Add(item.Text & If(q > 1, " x" & q, ""))
            lines.Add(New SaleLine With {
                .Name = item.Text,
                .Category = AppData.CategoryOf(item.Text),
                .Qty = q,
                .Amount = CType(item.Tag, OrderLine).Unit * q})
        Next
        AddSale(String.Join(", ", names), total, ticket, lines)

        ResetOrder()
    End Sub

    ' ================= MEAL CUSTOMIZATION =================
    Private Function ProteinBoxes() As CheckBox()
        Return {cbBeef, cbChicken, cbFish, cbTurkey}
    End Function

    Private Function ExtraBoxes() As CheckBox()
        Return {cbShito, cbEgg, cbAvocado, cbPlantain}
    End Function

    Private Function OptionName(cb As CheckBox) As String
        Dim i As Integer = cb.Text.IndexOf(" (+")
        Return If(i >= 0, cb.Text.Substring(0, i), cb.Text)
    End Function

    Private Function OptionPrice(cb As CheckBox) As Decimal
        Dim i As Integer = cb.Text.IndexOf("(+" & Cedi)
        If i < 0 Then Return 0D
        Dim s As String = cb.Text.Substring(i + 2 + Cedi.Length).TrimEnd(")"c)
        Return Decimal.Parse(s, System.Globalization.CultureInfo.InvariantCulture)
    End Function

    Private Function ProfileOf(itemName As String) As String
        Select Case itemName
            Case "Waakye", "Jollof Rice", "Fried Rice", "Plain Rice"
                Return "Rice"
            Case "Banku", "Fufu"
                Return "Swallow"
            Case "Turkey Stew", "Chicken Stew", "Beef Stew"
                Return "Stew"
            Case "Bottled Water", "Sobolo", "Soft Drink", "Malta Guinness", "Fruit Juice", "Palm Wine"
                Return "Drink"
        End Select
        ' Items added by the admin: choose by category
        Select Case AppData.CategoryOf(itemName)
            Case "Drinks"
                Return "Drink"
            Case "Waakye", "Jollof"
                Return "Rice"
            Case "Banku", "Fufu"
                Return "Swallow"
        End Select
        Return "None"
    End Function

    Private Function HasPortion(itemName As String) As Boolean
        Select Case ProfileOf(itemName)
            Case "Rice", "Swallow", "Stew"
                Return True
            Case "Drink"
                Return itemName = "Sobolo" OrElse itemName = "Fruit Juice" OrElse itemName = "Palm Wine"
            Case Else
                Return False
        End Select
    End Function

    Private Function PortionAdj(size As String, itemName As String) As Decimal
        Dim isDrink As Boolean = (ProfileOf(itemName) = "Drink")
        Select Case size
            Case "Small"
                Return If(isDrink, -1D, -2D)
            Case "Large"
                Return If(isDrink, 2D, 3D)
            Case Else
                Return 0D
        End Select
    End Function

    Private Function SelectedSize() As String
        If rbSmall.Checked Then Return "Small"
        If rbLarge.Checked Then Return "Large"
        Return "Regular"
    End Function

    Private Sub FillOptions(boxes() As CheckBox, names() As String, prices() As Decimal)
        For i As Integer = 0 To boxes.Length - 1
            If i < names.Length Then
                boxes(i).Text = names(i) & If(prices(i) > 0D, " (+" & Cedi & prices(i).ToString("0.00") & ")", "")
                boxes(i).Visible = True
            Else
                boxes(i).Checked = False
                boxes(i).Visible = False
            End If
        Next
    End Sub

    Private Sub HideOptions(boxes() As CheckBox)
        For Each cb As CheckBox In boxes
            cb.Checked = False
            cb.Visible = False
        Next
    End Sub

    Private Sub ApplyProfile(itemName As String)
        Dim p As String = ProfileOf(itemName)
        lblProtein.Visible = (p <> "None")
        lblExtras.Visible = (p = "Rice" OrElse p = "Swallow" OrElse p = "Stew")

        Select Case p
            Case "Rice"
                lblProtein.Text = "Choose Protein (Max 1)"
                FillOptions(ProteinBoxes(), {"Beef", "Chicken", "Fish", "Turkey"}, {4D, 5D, 4D, 5D})
                lblExtras.Text = "Extras"
                FillOptions(ExtraBoxes(), {"Extra Shito", "Fried Egg", "Plantain", "Avocado"}, {2D, 2D, 2D, 2D})
            Case "Swallow"
                lblProtein.Text = "Choose Soup (Max 1)"
                If itemName = "Fufu" Then
                    FillOptions(ProteinBoxes(), {"Light Soup", "Groundnut Soup", "Palm Nut Soup"}, {0D, 0D, 0D})
                Else
                    FillOptions(ProteinBoxes(), {"Okro Soup", "Pepper Sauce", "Shito"}, {0D, 0D, 0D})
                End If
                lblExtras.Text = "Add Protein / Extras"
                FillOptions(ExtraBoxes(), {"Tilapia", "Goat Meat", "Beef", "Extra Ball"}, {8D, 6D, 5D, 4D})
            Case "Stew"
                lblProtein.Text = "Spice Level (Max 1)"
                FillOptions(ProteinBoxes(), {"Mild", "Medium", "Hot"}, {0D, 0D, 0D})
                lblExtras.Text = "Extras"
                FillOptions(ExtraBoxes(), {"Extra Meat", "Boiled Egg", "Plantain", "Extra Shito"}, {5D, 2D, 3D, 2D})
            Case "Drink"
                lblProtein.Text = "Serve (Max 1)"
                FillOptions(ProteinBoxes(), {"Chilled", "Room Temp", "With Ice"}, {0D, 0D, 0D})
                HideOptions(ExtraBoxes())
            Case Else
                HideOptions(ProteinBoxes())
                HideOptions(ExtraBoxes())
        End Select

        Dim showPortion As Boolean = HasPortion(itemName)
        lblPortion.Visible = showPortion
        rbSmall.Visible = showPortion
        rbRegular.Visible = showPortion
        rbLarge.Visible = showPortion
        If showPortion Then
            Dim small As Decimal = PortionAdj("Small", itemName)
            Dim large As Decimal = PortionAdj("Large", itemName)
            lblPortion.Text = "Portion Size (Small -" & Cedi & Math.Abs(small).ToString("0.00") &
                              ", Large +" & Cedi & large.ToString("0.00") & ")"
        End If
    End Sub

    Private Sub Protein_CheckedChanged(sender As Object, e As EventArgs) _
        Handles cbBeef.CheckedChanged, cbChicken.CheckedChanged,
                cbFish.CheckedChanged, cbTurkey.CheckedChanged
        Dim cb As CheckBox = DirectCast(sender, CheckBox)
        If Not cb.Checked Then Exit Sub
        For Each other As CheckBox In ProteinBoxes()
            If other IsNot cb Then other.Checked = False
        Next
    End Sub

    Private Sub Portion_CheckedChanged(sender As Object, e As EventArgs) _
        Handles rbSmall.CheckedChanged, rbRegular.CheckedChanged, rbLarge.CheckedChanged
        Dim rb As RadioButton = DirectCast(sender, RadioButton)
        rb.ForeColor = If(rb.Checked, Color.White, Color.FromArgb(31, 41, 51))
    End Sub

    Private Sub RestoreCustomization()
        If lvOrder.SelectedItems.Count = 0 Then
            lblSelected.Text = "Selected Item: None"
            ApplyProfile("")
            rbRegular.Checked = True
            txtNote.Clear()
            Exit Sub
        End If

        Dim item As ListViewItem = lvOrder.SelectedItems(0)
        Dim line As OrderLine = CType(item.Tag, OrderLine)
        lblSelected.Text = "Selected: " & item.Text & " (" & Cedi & line.BasePrice.ToString("0.00") & ")"
        ApplyProfile(item.Text)

        For Each cb As CheckBox In ProteinBoxes()
            cb.Checked = cb.Visible AndAlso (OptionName(cb) = line.Protein)
        Next
        For Each cb As CheckBox In ExtraBoxes()
            cb.Checked = cb.Visible AndAlso line.Extras.Contains(OptionName(cb))
        Next
        Select Case line.Size
            Case "Small"
                rbSmall.Checked = True
            Case "Large"
                rbLarge.Checked = True
            Case Else
                rbRegular.Checked = True
        End Select
        txtNote.Text = line.Note
    End Sub

    Private Sub lvOrder_SelectedIndexChanged(sender As Object, e As EventArgs) _
        Handles lvOrder.SelectedIndexChanged
        RestoreCustomization()
    End Sub

    Private Sub btnCustCancel_Click(sender As Object, e As EventArgs) Handles btnCustCancel.Click
        RestoreCustomization()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If lvOrder.SelectedItems.Count = 0 Then
            MessageBox.Show("Select an item in Current Order first.",
                            "No Item Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim item As ListViewItem = lvOrder.SelectedItems(0)
        Dim line As OrderLine = CType(item.Tag, OrderLine)
        Dim extraTotal As Decimal = 0D

        line.Protein = ""
        For Each cb As CheckBox In ProteinBoxes()
            If cb.Visible AndAlso cb.Checked Then
                line.Protein = OptionName(cb)
                extraTotal += OptionPrice(cb)
            End If
        Next

        line.Extras.Clear()
        For Each cb As CheckBox In ExtraBoxes()
            If cb.Visible AndAlso cb.Checked Then
                line.Extras.Add(OptionName(cb))
                extraTotal += OptionPrice(cb)
            End If
        Next
        line.Extra = extraTotal

        line.Size = If(HasPortion(item.Text), SelectedSize(), "Regular")
        line.SizeAdj = PortionAdj(line.Size, item.Text)
        line.Note = txtNote.Text.Trim()

        Dim parts As New List(Of String)
        If line.Size <> "Regular" Then parts.Add(line.Size)
        If line.Protein <> "" Then parts.Add(line.Protein)
        parts.AddRange(line.Extras)
        If line.Note <> "" Then parts.Add("Note: " & line.Note)

        Dim qty As Integer = CInt(item.SubItems(2).Text)
        item.SubItems(1).Text = Cedi & line.Unit.ToString("0.00")
        item.SubItems(3).Text = Cedi & (line.Unit * qty).ToString("0.00")
        item.SubItems(4).Text = If(parts.Count = 0, "None", String.Join(", ", parts))
        UpdateTotals()
    End Sub

    ' ================= HISTORY LOG + QUICK STATS (this cashier's sales) =================
    Private Function IsMine(s As SaleRecord) As Boolean
        Return String.Equals(s.Cashier, AppData.CurrentUser, StringComparison.OrdinalIgnoreCase)
    End Function

    Private Sub AddSale(items As String, total As Decimal, ticket As Integer, lines As List(Of SaleLine))
        Dim s As New SaleRecord()
        s.SoldAt = DateTime.Now
        s.Cashier = AppData.CurrentUser
        s.Customer = "Walk-in"
        s.OrderType = SelectedOrderType()
        s.Table = If(rbDineIn.Checked, txtTable.Text.Trim(), "")
        s.Items = items
        s.Total = total
        s.Method = SelectedMethod()
        s.Ticket = ticket
        s.Lines = lines
        AppData.SalesList.Add(s)
        ShowHistory(False)
        RefreshStats()
    End Sub

    Private Sub ShowHistory(useDates As Boolean)
        lvHistory.Items.Clear()
        For i As Integer = AppData.SalesList.Count - 1 To 0 Step -1
            Dim s As SaleRecord = AppData.SalesList(i)
            If Not IsMine(s) Then Continue For
            If useDates AndAlso (s.SoldAt.Date < dtpFrom.Value.Date OrElse s.SoldAt.Date > dtpTo.Value.Date) Then Continue For
            Dim li As New ListViewItem(s.SoldAt.ToString("dd MMM HH:mm"))
            li.SubItems.Add(s.OrderType & If(s.Table <> "", " T" & s.Table, ""))
            li.SubItems.Add(s.Items)
            li.SubItems.Add(Cedi & s.Total.ToString("0.00"))
            li.SubItems.Add(s.Method)
            lvHistory.Items.Add(li)
        Next
    End Sub

    Private Sub RefreshStats()
        Dim count As Integer = 0
        Dim sum As Decimal = 0D
        Dim methods As New Dictionary(Of String, Integer)

        For Each s As SaleRecord In AppData.SalesList
            If IsMine(s) AndAlso s.SoldAt.Date = Date.Today Then
                count += 1
                sum += s.Total
                If methods.ContainsKey(s.Method) Then
                    methods(s.Method) += 1
                Else
                    methods(s.Method) = 1
                End If
            End If
        Next

        lblSalesVal.Text = Cedi & sum.ToString("0.00")
        lblOrdersVal.Text = count.ToString()
        lblAvgVal.Text = Cedi & If(count = 0, 0D, sum / count).ToString("0.00")

        Dim best As String = "-"
        Dim bestCount As Integer = 0
        For Each kv As KeyValuePair(Of String, Integer) In methods
            If kv.Value > bestCount Then
                best = kv.Key
                bestCount = kv.Value
            End If
        Next
        lblMethodVal.Text = best
    End Sub

    Private Sub btnViewAll_Click(sender As Object, e As EventArgs) Handles btnViewAll.Click
        ShowHistory(False)
    End Sub

    Private Sub btnFilter_Click(sender As Object, e As EventArgs) Handles btnFilter.Click
        If dtpFrom.Value.Date > dtpTo.Value.Date Then
            MessageBox.Show("The From date cannot be after the To date.",
                            "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        ShowHistory(True)
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click
        RefreshStats()
        Dim dineIn As Integer = 0
        Dim takeAway As Integer = 0
        For Each s As SaleRecord In AppData.SalesList
            If IsMine(s) AndAlso s.SoldAt.Date = Date.Today Then
                If s.OrderType = "Take Away" Then takeAway += 1 Else dineIn += 1
            End If
        Next
        MessageBox.Show("DAILY REPORT - " & Date.Today.ToString("dd MMM yyyy") & vbCrLf &
                        "Cashier: " & AppData.DisplayName(AppData.CurrentUser) & vbCrLf &
                        "----------------------------" & vbCrLf &
                        "Total Sales: " & lblSalesVal.Text & vbCrLf &
                        "Total Orders: " & lblOrdersVal.Text & vbCrLf &
                        "   Dine In: " & dineIn & vbCrLf &
                        "   Take Away: " & takeAway & vbCrLf &
                        "Average Order: " & lblAvgVal.Text & vbCrLf &
                        "Most Used Payment: " & lblMethodVal.Text,
                        "Daily Report", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

End Class