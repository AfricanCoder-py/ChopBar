﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        pnlHeader = New Panel()
        btnLogout = New Button()
        lblUserIcon = New Label()
        lblCalIcon = New Label()
        lblLogo = New Label()
        lblUser = New Label()
        lblDate = New Label()
        lblTitle = New Label()
        pnlPayment = New Panel()
        txtDiscount = New TextBox()
        lblDiscCap = New Label()
        btnComplete = New Button()
        txtAmount = New TextBox()
        lblAmtCap = New Label()
        rbBank = New RadioButton()
        rbCard = New RadioButton()
        rbMoMo = New RadioButton()
        rbCash = New RadioButton()
        lblPaymentTitle = New Label()
        pnlCustomization = New Panel()
        rbLarge = New RadioButton()
        rbRegular = New RadioButton()
        rbSmall = New RadioButton()
        lblPortion = New Label()
        btnUpdate = New Button()
        btnCustCancel = New Button()
        txtNote = New TextBox()
        cbPlantain = New CheckBox()
        cbAvocado = New CheckBox()
        cbEgg = New CheckBox()
        cbShito = New CheckBox()
        cbTurkey = New CheckBox()
        cbFish = New CheckBox()
        cbChicken = New CheckBox()
        cbBeef = New CheckBox()
        lblNote = New Label()
        lblExtras = New Label()
        lblProtein = New Label()
        lblSelected = New Label()
        lblCustTitle = New Label()
        pnlOrder = New Panel()
        lblBreakdown = New Label()
        txtTable = New TextBox()
        lblTableCap = New Label()
        rbTakeAway = New RadioButton()
        rbDineIn = New RadioButton()
        lblChangeCap = New Label()
        lblChange = New Label()
        lblOrderTitle = New Label()
        btnReport = New Button()
        btnPay = New Button()
        lvOrder = New ListView()
        colItem = New ColumnHeader()
        colPrice = New ColumnHeader()
        colQty = New ColumnHeader()
        colSub = New ColumnHeader()
        colCust = New ColumnHeader()
        nudQty = New NumericUpDown()
        txtPaid = New TextBox()
        lblPaidCap = New Label()
        lblQtyCap = New Label()
        lblTotalCap = New Label()
        lblTotal = New Label()
        btnRemove = New Button()
        btnClear = New Button()
        pnlMeals = New Panel()
        lblMealCount = New Label()
        flpMeals = New FlowLayoutPanel()
        btnWaakye = New Button()
        btnFufu = New Button()
        btnBanku = New Button()
        btnJollof = New Button()
        btnFriedRice = New Button()
        btnPlainRice = New Button()
        btnTurkey = New Button()
        btnChicken = New Button()
        btnBeef = New Button()
        btnWater = New Button()
        btnSobolo = New Button()
        btnSoftDrink = New Button()
        btnMalta = New Button()
        btnJuice = New Button()
        btnPalmWine = New Button()
        lblMealsTitle = New Label()
        txtSearch = New TextBox()
        lblStockHint = New Label()
        pnlStats = New Panel()
        pnlAvgCard = New Panel()
        lblAvgVal = New Label()
        lblAvgCap = New Label()
        Panel2 = New Panel()
        lblMethodVal = New Label()
        lblMethodCap = New Label()
        Panel1 = New Panel()
        lblOrdersVal = New Label()
        lblOrdersCap = New Label()
        pnlSalesCard = New Panel()
        lblSalesVal = New Label()
        lblSalesCap = New Label()
        lblStatsTitle = New Label()
        pnlHistory = New Panel()
        dtpTo = New DateTimePicker()
        lblTo = New Label()
        dtpFrom = New DateTimePicker()
        lblFrom = New Label()
        btnFilter = New Button()
        btnViewAll = New Button()
        lvHistory = New ListView()
        colHDate = New ColumnHeader()
        colHCust = New ColumnHeader()
        colHItems = New ColumnHeader()
        colHTotal = New ColumnHeader()
        colHMethod = New ColumnHeader()
        lblHistoryTitle = New Label()
        tabMain = New TabControl()
        tpOrder = New TabPage()
        pnlMenu = New Panel()
        rbDrinks = New RadioButton()
        rbOthers = New RadioButton()
        rbFufu = New RadioButton()
        rbJollof = New RadioButton()
        rbWaakye = New RadioButton()
        rbBanku = New RadioButton()
        rbAll = New RadioButton()
        lblMenu = New Label()
        tpReports = New TabPage()
        pnlHeader.SuspendLayout()
        pnlPayment.SuspendLayout()
        pnlCustomization.SuspendLayout()
        pnlOrder.SuspendLayout()
        CType(nudQty, ComponentModel.ISupportInitialize).BeginInit()
        pnlMeals.SuspendLayout()
        flpMeals.SuspendLayout()
        pnlStats.SuspendLayout()
        pnlAvgCard.SuspendLayout()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        pnlSalesCard.SuspendLayout()
        pnlHistory.SuspendLayout()
        tabMain.SuspendLayout()
        tpOrder.SuspendLayout()
        pnlMenu.SuspendLayout()
        tpReports.SuspendLayout()
        SuspendLayout()
        ' 
        ' pnlHeader
        ' 
        pnlHeader.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        pnlHeader.Controls.Add(btnLogout)
        pnlHeader.Controls.Add(lblUserIcon)
        pnlHeader.Controls.Add(lblCalIcon)
        pnlHeader.Controls.Add(lblLogo)
        pnlHeader.Controls.Add(lblUser)
        pnlHeader.Controls.Add(lblDate)
        pnlHeader.Controls.Add(lblTitle)
        pnlHeader.Dock = DockStyle.Top
        pnlHeader.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlHeader.Location = New Point(0, 0)
        pnlHeader.Name = "pnlHeader"
        pnlHeader.Size = New Size(1295, 56)
        pnlHeader.TabIndex = 0
        ' 
        ' btnLogout
        ' 
        btnLogout.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        btnLogout.BackColor = Color.FromArgb(CByte(245), CByte(183), CByte(0))
        btnLogout.Cursor = Cursors.Hand
        btnLogout.FlatAppearance.BorderSize = 0
        btnLogout.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(20), CByte(120), CByte(80))
        btnLogout.FlatStyle = FlatStyle.Flat
        btnLogout.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogout.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnLogout.Location = New Point(1160, 12)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(110, 32)
        btnLogout.TabIndex = 10
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' lblUserIcon
        ' 
        lblUserIcon.BackColor = Color.Transparent
        lblUserIcon.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblUserIcon.ForeColor = Color.White
        lblUserIcon.Location = New Point(1010, 12)
        lblUserIcon.Name = "lblUserIcon"
        lblUserIcon.Size = New Size(40, 36)
        lblUserIcon.TabIndex = 9
        lblUserIcon.Text = "👤"
        ' 
        ' lblCalIcon
        ' 
        lblCalIcon.BackColor = Color.Transparent
        lblCalIcon.Font = New Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCalIcon.ForeColor = Color.White
        lblCalIcon.Location = New Point(760, 12)
        lblCalIcon.Name = "lblCalIcon"
        lblCalIcon.Size = New Size(40, 36)
        lblCalIcon.TabIndex = 8
        lblCalIcon.Text = "📅"
        lblCalIcon.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblLogo
        ' 
        lblLogo.AutoSize = True
        lblLogo.Font = New Font("Segoe UI Emoji", 18.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblLogo.ForeColor = Color.White
        lblLogo.Location = New Point(12, 8)
        lblLogo.Name = "lblLogo"
        lblLogo.Size = New Size(58, 40)
        lblLogo.TabIndex = 7
        lblLogo.Text = "🍴"
        ' 
        ' lblUser
        ' 
        lblUser.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        lblUser.AutoSize = True
        lblUser.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblUser.ForeColor = Color.White
        lblUser.Location = New Point(1050, 17)
        lblUser.Name = "lblUser"
        lblUser.Size = New Size(90, 25)
        lblUser.TabIndex = 6
        lblUser.Text = "Admin ▾"
        ' 
        ' lblDate
        ' 
        lblDate.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        lblDate.AutoSize = True
        lblDate.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDate.ForeColor = Color.White
        lblDate.Location = New Point(800, 17)
        lblDate.Name = "lblDate"
        lblDate.Size = New Size(178, 25)
        lblDate.TabIndex = 5
        lblDate.Text = "Today: 31 Oct, 2026"
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.ForeColor = Color.FromArgb(CByte(245), CByte(183), CByte(0))
        lblTitle.Location = New Point(84, 6)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(232, 46)
        lblTitle.TabIndex = 4
        lblTitle.Text = "ChopBar POS"
        ' 
        ' pnlPayment
        ' 
        pnlPayment.Controls.Add(txtDiscount)
        pnlPayment.Controls.Add(lblDiscCap)
        pnlPayment.Controls.Add(btnComplete)
        pnlPayment.Controls.Add(txtAmount)
        pnlPayment.Controls.Add(lblAmtCap)
        pnlPayment.Controls.Add(rbBank)
        pnlPayment.Controls.Add(rbCard)
        pnlPayment.Controls.Add(rbMoMo)
        pnlPayment.Controls.Add(rbCash)
        pnlPayment.Controls.Add(lblPaymentTitle)
        pnlPayment.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlPayment.Location = New Point(12, 426)
        pnlPayment.Name = "pnlPayment"
        pnlPayment.Size = New Size(446, 226)
        pnlPayment.TabIndex = 3
        ' 
        ' txtDiscount
        ' 
        txtDiscount.BorderStyle = BorderStyle.FixedSingle
        txtDiscount.Font = New Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtDiscount.Location = New Point(170, 100)
        txtDiscount.MaxLength = 5
        txtDiscount.Name = "txtDiscount"
        txtDiscount.Size = New Size(254, 30)
        txtDiscount.TabIndex = 16
        ' 
        ' lblDiscCap
        ' 
        lblDiscCap.AutoSize = True
        lblDiscCap.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblDiscCap.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblDiscCap.Location = New Point(12, 104)
        lblDiscCap.Name = "lblDiscCap"
        lblDiscCap.Size = New Size(117, 23)
        lblDiscCap.TabIndex = 15
        lblDiscCap.Text = "Discount (%):"
        ' 
        ' btnComplete
        ' 
        btnComplete.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        btnComplete.Cursor = Cursors.Hand
        btnComplete.FlatAppearance.BorderSize = 0
        btnComplete.FlatAppearance.MouseDownBackColor = Color.FromArgb(CByte(20), CByte(120), CByte(80))
        btnComplete.FlatStyle = FlatStyle.Flat
        btnComplete.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnComplete.ForeColor = Color.White
        btnComplete.Location = New Point(12, 174)
        btnComplete.Name = "btnComplete"
        btnComplete.Size = New Size(424, 40)
        btnComplete.TabIndex = 14
        btnComplete.Text = "✔  Complete Payment"
        btnComplete.UseVisualStyleBackColor = False
        ' 
        ' txtAmount
        ' 
        txtAmount.BorderStyle = BorderStyle.FixedSingle
        txtAmount.Font = New Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtAmount.Location = New Point(170, 138)
        txtAmount.MaxLength = 10
        txtAmount.Name = "txtAmount"
        txtAmount.PlaceholderText = "GH₵0.00"
        txtAmount.Size = New Size(254, 31)
        txtAmount.TabIndex = 13
        ' 
        ' lblAmtCap
        ' 
        lblAmtCap.AutoSize = True
        lblAmtCap.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAmtCap.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblAmtCap.Location = New Point(12, 142)
        lblAmtCap.Name = "lblAmtCap"
        lblAmtCap.Size = New Size(156, 23)
        lblAmtCap.TabIndex = 12
        lblAmtCap.Text = "Amount Received:"
        ' 
        ' rbBank
        ' 
        rbBank.Appearance = Appearance.Button
        rbBank.BackColor = Color.White
        rbBank.Cursor = Cursors.Hand
        rbBank.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbBank.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbBank.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbBank.FlatStyle = FlatStyle.Flat
        rbBank.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbBank.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbBank.Location = New Point(336, 40)
        rbBank.Name = "rbBank"
        rbBank.Size = New Size(100, 52)
        rbBank.TabIndex = 11
        rbBank.TabStop = True
        rbBank.Text = "🏦 " & vbCrLf & "Bank Transfer"
        rbBank.TextAlign = ContentAlignment.MiddleCenter
        rbBank.UseVisualStyleBackColor = False
        ' 
        ' rbCard
        ' 
        rbCard.Appearance = Appearance.Button
        rbCard.BackColor = Color.White
        rbCard.Cursor = Cursors.Hand
        rbCard.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbCard.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbCard.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbCard.FlatStyle = FlatStyle.Flat
        rbCard.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbCard.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbCard.Location = New Point(228, 40)
        rbCard.Name = "rbCard"
        rbCard.Size = New Size(100, 52)
        rbCard.TabIndex = 10
        rbCard.TabStop = True
        rbCard.Text = "💳" & vbCrLf & "Card"
        rbCard.TextAlign = ContentAlignment.MiddleCenter
        rbCard.UseVisualStyleBackColor = False
        ' 
        ' rbMoMo
        ' 
        rbMoMo.Appearance = Appearance.Button
        rbMoMo.BackColor = Color.White
        rbMoMo.Cursor = Cursors.Hand
        rbMoMo.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbMoMo.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbMoMo.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbMoMo.FlatStyle = FlatStyle.Flat
        rbMoMo.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbMoMo.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbMoMo.Location = New Point(120, 40)
        rbMoMo.Name = "rbMoMo"
        rbMoMo.Size = New Size(100, 52)
        rbMoMo.TabIndex = 9
        rbMoMo.TabStop = True
        rbMoMo.Text = "📱 " & vbCrLf & "MoMo"
        rbMoMo.TextAlign = ContentAlignment.MiddleCenter
        rbMoMo.UseVisualStyleBackColor = False
        ' 
        ' rbCash
        ' 
        rbCash.Appearance = Appearance.Button
        rbCash.BackColor = Color.White
        rbCash.Cursor = Cursors.Hand
        rbCash.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbCash.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbCash.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbCash.FlatStyle = FlatStyle.Flat
        rbCash.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbCash.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbCash.Location = New Point(12, 40)
        rbCash.Name = "rbCash"
        rbCash.Size = New Size(100, 52)
        rbCash.TabIndex = 8
        rbCash.TabStop = True
        rbCash.Text = "💵 " & vbCrLf & "Cash"
        rbCash.TextAlign = ContentAlignment.MiddleCenter
        rbCash.UseVisualStyleBackColor = False
        ' 
        ' lblPaymentTitle
        ' 
        lblPaymentTitle.AutoSize = True
        lblPaymentTitle.BackColor = Color.Transparent
        lblPaymentTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblPaymentTitle.Location = New Point(12, 8)
        lblPaymentTitle.Name = "lblPaymentTitle"
        lblPaymentTitle.Size = New Size(175, 28)
        lblPaymentTitle.TabIndex = 7
        lblPaymentTitle.Text = "Payment Method"
        ' 
        ' pnlCustomization
        ' 
        pnlCustomization.Controls.Add(rbLarge)
        pnlCustomization.Controls.Add(rbRegular)
        pnlCustomization.Controls.Add(rbSmall)
        pnlCustomization.Controls.Add(lblPortion)
        pnlCustomization.Controls.Add(btnUpdate)
        pnlCustomization.Controls.Add(btnCustCancel)
        pnlCustomization.Controls.Add(txtNote)
        pnlCustomization.Controls.Add(cbPlantain)
        pnlCustomization.Controls.Add(cbAvocado)
        pnlCustomization.Controls.Add(cbEgg)
        pnlCustomization.Controls.Add(cbShito)
        pnlCustomization.Controls.Add(cbTurkey)
        pnlCustomization.Controls.Add(cbFish)
        pnlCustomization.Controls.Add(cbChicken)
        pnlCustomization.Controls.Add(cbBeef)
        pnlCustomization.Controls.Add(lblNote)
        pnlCustomization.Controls.Add(lblExtras)
        pnlCustomization.Controls.Add(lblProtein)
        pnlCustomization.Controls.Add(lblSelected)
        pnlCustomization.Controls.Add(lblCustTitle)
        pnlCustomization.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlCustomization.Location = New Point(712, 8)
        pnlCustomization.Name = "pnlCustomization"
        pnlCustomization.Size = New Size(556, 410)
        pnlCustomization.TabIndex = 0
        ' 
        ' rbLarge
        ' 
        rbLarge.Appearance = Appearance.Button
        rbLarge.BackColor = Color.White
        rbLarge.Cursor = Cursors.Hand
        rbLarge.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbLarge.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbLarge.FlatStyle = FlatStyle.Flat
        rbLarge.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbLarge.Location = New Point(224, 228)
        rbLarge.Name = "rbLarge"
        rbLarge.Size = New Size(100, 30)
        rbLarge.TabIndex = 49
        rbLarge.TabStop = True
        rbLarge.Text = "Large"
        rbLarge.UseVisualStyleBackColor = False
        ' 
        ' rbRegular
        ' 
        rbRegular.Appearance = Appearance.Button
        rbRegular.BackColor = Color.White
        rbRegular.Cursor = Cursors.Hand
        rbRegular.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbRegular.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbRegular.FlatStyle = FlatStyle.Flat
        rbRegular.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbRegular.Location = New Point(118, 228)
        rbRegular.Name = "rbRegular"
        rbRegular.Size = New Size(100, 30)
        rbRegular.TabIndex = 48
        rbRegular.TabStop = True
        rbRegular.Text = "Regular"
        rbRegular.UseVisualStyleBackColor = False
        ' 
        ' rbSmall
        ' 
        rbSmall.Appearance = Appearance.Button
        rbSmall.BackColor = Color.White
        rbSmall.Cursor = Cursors.Hand
        rbSmall.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbSmall.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbSmall.FlatStyle = FlatStyle.Flat
        rbSmall.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbSmall.Location = New Point(12, 228)
        rbSmall.Name = "rbSmall"
        rbSmall.Size = New Size(100, 30)
        rbSmall.TabIndex = 47
        rbSmall.TabStop = True
        rbSmall.Text = "Small"
        rbSmall.UseVisualStyleBackColor = False
        ' 
        ' lblPortion
        ' 
        lblPortion.AutoSize = True
        lblPortion.Location = New Point(12, 195)
        lblPortion.Name = "lblPortion"
        lblPortion.Size = New Size(126, 28)
        lblPortion.TabIndex = 6
        lblPortion.Text = "Portion Size"
        ' 
        ' btnUpdate
        ' 
        btnUpdate.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        btnUpdate.Cursor = Cursors.Hand
        btnUpdate.FlatAppearance.BorderSize = 0
        btnUpdate.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnUpdate.ForeColor = Color.White
        btnUpdate.Location = New Point(156, 364)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(132, 32)
        btnUpdate.TabIndex = 46
        btnUpdate.Text = "Update Item"
        btnUpdate.UseVisualStyleBackColor = False
        ' 
        ' btnCustCancel
        ' 
        btnCustCancel.BackColor = Color.FromArgb(CByte(225), CByte(225), CByte(225))
        btnCustCancel.Cursor = Cursors.Hand
        btnCustCancel.FlatAppearance.BorderColor = Color.FromArgb(CByte(150), CByte(150), CByte(150))
        btnCustCancel.FlatStyle = FlatStyle.Flat
        btnCustCancel.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCustCancel.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnCustCancel.Location = New Point(12, 364)
        btnCustCancel.Name = "btnCustCancel"
        btnCustCancel.Size = New Size(132, 32)
        btnCustCancel.TabIndex = 45
        btnCustCancel.Text = "Cancel"
        btnCustCancel.UseVisualStyleBackColor = False
        ' 
        ' txtNote
        ' 
        txtNote.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtNote.Location = New Point(12, 326)
        txtNote.MaxLength = 40
        txtNote.Name = "txtNote"
        txtNote.PlaceholderText = "e.g. Less pepper"
        txtNote.Size = New Size(276, 30)
        txtNote.TabIndex = 44
        ' 
        ' cbPlantain
        ' 
        cbPlantain.AutoSize = True
        cbPlantain.BackColor = Color.Transparent
        cbPlantain.Cursor = Cursors.Hand
        cbPlantain.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbPlantain.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbPlantain.Location = New Point(298, 162)
        cbPlantain.Name = "cbPlantain"
        cbPlantain.Size = New Size(164, 24)
        cbPlantain.TabIndex = 43
        cbPlantain.Text = "Plantain (+GH₵2.00)"
        cbPlantain.UseVisualStyleBackColor = False
        ' 
        ' cbAvocado
        ' 
        cbAvocado.AutoSize = True
        cbAvocado.BackColor = Color.Transparent
        cbAvocado.Cursor = Cursors.Hand
        cbAvocado.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbAvocado.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbAvocado.Location = New Point(298, 140)
        cbAvocado.Name = "cbAvocado"
        cbAvocado.Size = New Size(170, 24)
        cbAvocado.TabIndex = 42
        cbAvocado.Text = "Avocado (+GH₵2.00)"
        cbAvocado.UseVisualStyleBackColor = False
        ' 
        ' cbEgg
        ' 
        cbEgg.AutoSize = True
        cbEgg.BackColor = Color.Transparent
        cbEgg.Cursor = Cursors.Hand
        cbEgg.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbEgg.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbEgg.Location = New Point(298, 118)
        cbEgg.Name = "cbEgg"
        cbEgg.Size = New Size(174, 24)
        cbEgg.TabIndex = 41
        cbEgg.Text = "Fried Egg (+GH₵2.00)"
        cbEgg.UseVisualStyleBackColor = False
        ' 
        ' cbShito
        ' 
        cbShito.AutoSize = True
        cbShito.BackColor = Color.Transparent
        cbShito.Cursor = Cursors.Hand
        cbShito.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbShito.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbShito.Location = New Point(298, 96)
        cbShito.Name = "cbShito"
        cbShito.Size = New Size(182, 24)
        cbShito.TabIndex = 40
        cbShito.Text = "Extra Shito (+GH₵2.00)"
        cbShito.UseVisualStyleBackColor = False
        ' 
        ' cbTurkey
        ' 
        cbTurkey.AutoSize = True
        cbTurkey.BackColor = Color.Transparent
        cbTurkey.Cursor = Cursors.Hand
        cbTurkey.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbTurkey.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbTurkey.Location = New Point(20, 162)
        cbTurkey.Name = "cbTurkey"
        cbTurkey.Size = New Size(74, 24)
        cbTurkey.TabIndex = 39
        cbTurkey.Text = "Turkey"
        cbTurkey.UseVisualStyleBackColor = False
        ' 
        ' cbFish
        ' 
        cbFish.AutoSize = True
        cbFish.BackColor = Color.Transparent
        cbFish.Cursor = Cursors.Hand
        cbFish.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbFish.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbFish.Location = New Point(20, 140)
        cbFish.Name = "cbFish"
        cbFish.Size = New Size(56, 24)
        cbFish.TabIndex = 38
        cbFish.Text = "Fish"
        cbFish.UseVisualStyleBackColor = False
        ' 
        ' cbChicken
        ' 
        cbChicken.AutoSize = True
        cbChicken.BackColor = Color.Transparent
        cbChicken.Cursor = Cursors.Hand
        cbChicken.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbChicken.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbChicken.Location = New Point(20, 118)
        cbChicken.Name = "cbChicken"
        cbChicken.Size = New Size(82, 24)
        cbChicken.TabIndex = 37
        cbChicken.Text = "Chicken"
        cbChicken.UseVisualStyleBackColor = False
        ' 
        ' cbBeef
        ' 
        cbBeef.AutoSize = True
        cbBeef.BackColor = Color.Transparent
        cbBeef.Cursor = Cursors.Hand
        cbBeef.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cbBeef.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        cbBeef.Location = New Point(20, 96)
        cbBeef.Name = "cbBeef"
        cbBeef.Size = New Size(61, 24)
        cbBeef.TabIndex = 36
        cbBeef.Text = "Beef"
        cbBeef.UseVisualStyleBackColor = False
        ' 
        ' lblNote
        ' 
        lblNote.AutoSize = True
        lblNote.BackColor = Color.Transparent
        lblNote.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblNote.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblNote.Location = New Point(12, 304)
        lblNote.Name = "lblNote"
        lblNote.Size = New Size(172, 20)
        lblNote.TabIndex = 35
        lblNote.Text = "Special Note (Optional)"
        ' 
        ' lblExtras
        ' 
        lblExtras.AutoSize = True
        lblExtras.BackColor = Color.Transparent
        lblExtras.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblExtras.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblExtras.Location = New Point(290, 70)
        lblExtras.Name = "lblExtras"
        lblExtras.Size = New Size(52, 20)
        lblExtras.TabIndex = 34
        lblExtras.Text = "Extras"
        ' 
        ' lblProtein
        ' 
        lblProtein.AutoSize = True
        lblProtein.BackColor = Color.Transparent
        lblProtein.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblProtein.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblProtein.Location = New Point(12, 70)
        lblProtein.Name = "lblProtein"
        lblProtein.Size = New Size(174, 20)
        lblProtein.TabIndex = 33
        lblProtein.Text = "Choose Protein (Max 1)"
        ' 
        ' lblSelected
        ' 
        lblSelected.BackColor = Color.Transparent
        lblSelected.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblSelected.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblSelected.Location = New Point(12, 44)
        lblSelected.Name = "lblSelected"
        lblSelected.Size = New Size(530, 22)
        lblSelected.TabIndex = 32
        lblSelected.Text = "Selected Item: None"
        ' 
        ' lblCustTitle
        ' 
        lblCustTitle.AutoSize = True
        lblCustTitle.BackColor = Color.Transparent
        lblCustTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblCustTitle.Location = New Point(12, 8)
        lblCustTitle.Name = "lblCustTitle"
        lblCustTitle.Size = New Size(201, 28)
        lblCustTitle.TabIndex = 7
        lblCustTitle.Text = "Meal Customization"
        ' 
        ' pnlOrder
        ' 
        pnlOrder.Controls.Add(lblBreakdown)
        pnlOrder.Controls.Add(txtTable)
        pnlOrder.Controls.Add(lblTableCap)
        pnlOrder.Controls.Add(rbTakeAway)
        pnlOrder.Controls.Add(rbDineIn)
        pnlOrder.Controls.Add(lblChangeCap)
        pnlOrder.Controls.Add(lblChange)
        pnlOrder.Controls.Add(lblOrderTitle)
        pnlOrder.Controls.Add(btnReport)
        pnlOrder.Controls.Add(btnPay)
        pnlOrder.Controls.Add(lvOrder)
        pnlOrder.Controls.Add(nudQty)
        pnlOrder.Controls.Add(txtPaid)
        pnlOrder.Controls.Add(lblPaidCap)
        pnlOrder.Controls.Add(lblQtyCap)
        pnlOrder.Controls.Add(lblTotalCap)
        pnlOrder.Controls.Add(lblTotal)
        pnlOrder.Controls.Add(btnRemove)
        pnlOrder.Controls.Add(btnClear)
        pnlOrder.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlOrder.Location = New Point(466, 426)
        pnlOrder.Name = "pnlOrder"
        pnlOrder.Size = New Size(802, 226)
        pnlOrder.TabIndex = 0
        ' 
        ' lblBreakdown
        ' 
        lblBreakdown.Font = New Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblBreakdown.ForeColor = Color.FromArgb(CByte(107), CByte(114), CByte(128))
        lblBreakdown.Location = New Point(464, 192)
        lblBreakdown.Name = "lblBreakdown"
        lblBreakdown.Size = New Size(190, 30)
        lblBreakdown.TabIndex = 36
        ' 
        ' txtTable
        ' 
        txtTable.BorderStyle = BorderStyle.FixedSingle
        txtTable.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtTable.Location = New Point(430, 7)
        txtTable.MaxLength = 3
        txtTable.Name = "txtTable"
        txtTable.Size = New Size(70, 30)
        txtTable.TabIndex = 35
        ' 
        ' lblTableCap
        ' 
        lblTableCap.AutoSize = True
        lblTableCap.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTableCap.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblTableCap.Location = New Point(340, 12)
        lblTableCap.Name = "lblTableCap"
        lblTableCap.Size = New Size(86, 23)
        lblTableCap.TabIndex = 34
        lblTableCap.Text = "Table No:"
        ' 
        ' rbTakeAway
        ' 
        rbTakeAway.Appearance = Appearance.Button
        rbTakeAway.BackColor = Color.White
        rbTakeAway.Cursor = Cursors.Hand
        rbTakeAway.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbTakeAway.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbTakeAway.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbTakeAway.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbTakeAway.Location = New Point(658, 8)
        rbTakeAway.Name = "rbTakeAway"
        rbTakeAway.Size = New Size(124, 30)
        rbTakeAway.TabIndex = 33
        rbTakeAway.TabStop = True
        rbTakeAway.Text = "Take-Away"
        rbTakeAway.TextAlign = ContentAlignment.MiddleCenter
        rbTakeAway.UseVisualStyleBackColor = False
        ' 
        ' rbDineIn
        ' 
        rbDineIn.Appearance = Appearance.Button
        rbDineIn.BackColor = Color.White
        rbDineIn.Cursor = Cursors.Hand
        rbDineIn.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        rbDineIn.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbDineIn.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbDineIn.FlatStyle = FlatStyle.Flat
        rbDineIn.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbDineIn.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbDineIn.Location = New Point(550, 8)
        rbDineIn.Name = "rbDineIn"
        rbDineIn.Size = New Size(100, 30)
        rbDineIn.TabIndex = 32
        rbDineIn.TabStop = True
        rbDineIn.Text = "Dine-In"
        rbDineIn.TextAlign = ContentAlignment.MiddleCenter
        rbDineIn.UseVisualStyleBackColor = False
        ' 
        ' lblChangeCap
        ' 
        lblChangeCap.AutoSize = True
        lblChangeCap.BackColor = Color.Transparent
        lblChangeCap.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblChangeCap.Location = New Point(464, 162)
        lblChangeCap.Name = "lblChangeCap"
        lblChangeCap.Size = New Size(81, 25)
        lblChangeCap.TabIndex = 28
        lblChangeCap.Text = "Change:"
        ' 
        ' lblChange
        ' 
        lblChange.AutoSize = True
        lblChange.BackColor = Color.Transparent
        lblChange.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblChange.ForeColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        lblChange.Location = New Point(540, 158)
        lblChange.Name = "lblChange"
        lblChange.Size = New Size(106, 31)
        lblChange.TabIndex = 29
        lblChange.Text = "GH₵0.00"
        ' 
        ' lblOrderTitle
        ' 
        lblOrderTitle.AutoSize = True
        lblOrderTitle.BackColor = Color.Transparent
        lblOrderTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblOrderTitle.Location = New Point(12, 8)
        lblOrderTitle.Name = "lblOrderTitle"
        lblOrderTitle.Size = New Size(143, 28)
        lblOrderTitle.TabIndex = 7
        lblOrderTitle.Text = "Current Order"
        ' 
        ' btnReport
        ' 
        btnReport.BackColor = Color.FromArgb(CByte(225), CByte(225), CByte(225))
        btnReport.Cursor = Cursors.Hand
        btnReport.FlatAppearance.BorderColor = Color.FromArgb(CByte(150), CByte(150), CByte(150))
        btnReport.FlatAppearance.BorderSize = 0
        btnReport.FlatStyle = FlatStyle.Flat
        btnReport.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnReport.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnReport.Location = New Point(664, 166)
        btnReport.Name = "btnReport"
        btnReport.Size = New Size(126, 40)
        btnReport.TabIndex = 31
        btnReport.Text = "Daily Report"
        btnReport.UseVisualStyleBackColor = False
        ' 
        ' btnPay
        ' 
        btnPay.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        btnPay.Cursor = Cursors.Hand
        btnPay.FlatAppearance.BorderSize = 0
        btnPay.FlatStyle = FlatStyle.Flat
        btnPay.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnPay.ForeColor = Color.White
        btnPay.Location = New Point(664, 86)
        btnPay.Name = "btnPay"
        btnPay.Size = New Size(126, 72)
        btnPay.TabIndex = 30
        btnPay.Text = "Pay and Print Receipt"
        btnPay.UseVisualStyleBackColor = False
        ' 
        ' lvOrder
        ' 
        lvOrder.BorderStyle = BorderStyle.FixedSingle
        lvOrder.Columns.AddRange(New ColumnHeader() {colItem, colPrice, colQty, colSub, colCust})
        lvOrder.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lvOrder.FullRowSelect = True
        lvOrder.GridLines = True
        lvOrder.Location = New Point(12, 44)
        lvOrder.MultiSelect = False
        lvOrder.Name = "lvOrder"
        lvOrder.Size = New Size(440, 172)
        lvOrder.TabIndex = 19
        lvOrder.UseCompatibleStateImageBehavior = False
        lvOrder.View = View.Details
        ' 
        ' colItem
        ' 
        colItem.Text = "Item"
        colItem.Width = 120
        ' 
        ' colPrice
        ' 
        colPrice.Text = "Price"
        colPrice.Width = 75
        ' 
        ' colQty
        ' 
        colQty.Text = "Qty"
        colQty.Width = 45
        ' 
        ' colSub
        ' 
        colSub.Text = "Subtotal"
        colSub.Width = 85
        ' 
        ' colCust
        ' 
        colCust.Text = "Customizations"
        colCust.Width = 120
        ' 
        ' nudQty
        ' 
        nudQty.Font = New Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        nudQty.Location = New Point(508, 46)
        nudQty.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        nudQty.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        nudQty.Name = "nudQty"
        nudQty.Size = New Size(60, 30)
        nudQty.TabIndex = 21
        nudQty.Value = New Decimal(New Integer() {1, 0, 0, 0})
        ' 
        ' txtPaid
        ' 
        txtPaid.Font = New Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPaid.Location = New Point(540, 122)
        txtPaid.MaxLength = 10
        txtPaid.Name = "txtPaid"
        txtPaid.PlaceholderText = "GH₵0.00"
        txtPaid.Size = New Size(110, 31)
        txtPaid.TabIndex = 25
        ' 
        ' lblPaidCap
        ' 
        lblPaidCap.AutoSize = True
        lblPaidCap.BackColor = Color.Transparent
        lblPaidCap.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblPaidCap.Location = New Point(464, 126)
        lblPaidCap.Name = "lblPaidCap"
        lblPaidCap.Size = New Size(54, 25)
        lblPaidCap.TabIndex = 27
        lblPaidCap.Text = "Paid:"
        ' 
        ' lblQtyCap
        ' 
        lblQtyCap.AutoSize = True
        lblQtyCap.BackColor = Color.Transparent
        lblQtyCap.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblQtyCap.Location = New Point(464, 50)
        lblQtyCap.Name = "lblQtyCap"
        lblQtyCap.Size = New Size(44, 23)
        lblQtyCap.TabIndex = 20
        lblQtyCap.Text = "Qty:"
        ' 
        ' lblTotalCap
        ' 
        lblTotalCap.AutoSize = True
        lblTotalCap.BackColor = Color.Transparent
        lblTotalCap.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotalCap.Location = New Point(464, 90)
        lblTotalCap.Name = "lblTotalCap"
        lblTotalCap.Size = New Size(59, 25)
        lblTotalCap.TabIndex = 24
        lblTotalCap.Text = "Total:"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.BackColor = Color.Transparent
        lblTotal.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotal.ForeColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        lblTotal.Location = New Point(540, 86)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(106, 31)
        lblTotal.TabIndex = 26
        lblTotal.Text = "GH₵0.00"
        ' 
        ' btnRemove
        ' 
        btnRemove.BackColor = Color.FromArgb(CByte(225), CByte(225), CByte(225))
        btnRemove.Cursor = Cursors.Hand
        btnRemove.FlatAppearance.BorderColor = Color.FromArgb(CByte(150), CByte(150), CByte(150))
        btnRemove.FlatStyle = FlatStyle.Flat
        btnRemove.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnRemove.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnRemove.Location = New Point(576, 44)
        btnRemove.Name = "btnRemove"
        btnRemove.Size = New Size(90, 32)
        btnRemove.TabIndex = 22
        btnRemove.Text = "Remove"
        btnRemove.UseVisualStyleBackColor = False
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.FromArgb(CByte(225), CByte(225), CByte(225))
        btnClear.Cursor = Cursors.Hand
        btnClear.FlatAppearance.BorderColor = Color.FromArgb(CByte(150), CByte(150), CByte(150))
        btnClear.FlatStyle = FlatStyle.Flat
        btnClear.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnClear.Location = New Point(672, 44)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(90, 32)
        btnClear.TabIndex = 23
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' pnlMeals
        ' 
        pnlMeals.Controls.Add(lblMealCount)
        pnlMeals.Controls.Add(flpMeals)
        pnlMeals.Controls.Add(lblMealsTitle)
        pnlMeals.Controls.Add(txtSearch)
        pnlMeals.Controls.Add(lblStockHint)
        pnlMeals.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlMeals.Location = New Point(148, 8)
        pnlMeals.Name = "pnlMeals"
        pnlMeals.Size = New Size(556, 410)
        pnlMeals.TabIndex = 32
        ' 
        ' lblMealCount
        ' 
        lblMealCount.Font = New Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblMealCount.ForeColor = Color.FromArgb(CByte(107), CByte(114), CByte(128))
        lblMealCount.Location = New Point(300, 384)
        lblMealCount.Name = "lblMealCount"
        lblMealCount.Size = New Size(244, 17)
        lblMealCount.TabIndex = 51
        lblMealCount.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' flpMeals
        ' 
        flpMeals.AutoScroll = True
        flpMeals.BackColor = Color.Transparent
        flpMeals.Controls.Add(btnWaakye)
        flpMeals.Controls.Add(btnFufu)
        flpMeals.Controls.Add(btnBanku)
        flpMeals.Controls.Add(btnJollof)
        flpMeals.Controls.Add(btnFriedRice)
        flpMeals.Controls.Add(btnPlainRice)
        flpMeals.Controls.Add(btnTurkey)
        flpMeals.Controls.Add(btnChicken)
        flpMeals.Controls.Add(btnBeef)
        flpMeals.Controls.Add(btnWater)
        flpMeals.Controls.Add(btnSobolo)
        flpMeals.Controls.Add(btnSoftDrink)
        flpMeals.Controls.Add(btnMalta)
        flpMeals.Controls.Add(btnJuice)
        flpMeals.Controls.Add(btnPalmWine)
        flpMeals.Location = New Point(8, 42)
        flpMeals.Name = "flpMeals"
        flpMeals.Size = New Size(540, 336)
        flpMeals.TabIndex = 7
        ' 
        ' btnWaakye
        ' 
        btnWaakye.BackColor = Color.White
        btnWaakye.Cursor = Cursors.Hand
        btnWaakye.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnWaakye.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnWaakye.FlatStyle = FlatStyle.Flat
        btnWaakye.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnWaakye.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnWaakye.Location = New Point(3, 3)
        btnWaakye.Name = "btnWaakye"
        btnWaakye.Size = New Size(100, 100)
        btnWaakye.TabIndex = 4
        btnWaakye.Tag = "`Waakye"
        btnWaakye.Text = "Waakye" & vbCrLf & "GH₵15.00"
        btnWaakye.UseVisualStyleBackColor = False
        ' 
        ' btnFufu
        ' 
        btnFufu.BackColor = Color.White
        btnFufu.Cursor = Cursors.Hand
        btnFufu.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnFufu.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnFufu.FlatStyle = FlatStyle.Flat
        btnFufu.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnFufu.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnFufu.Location = New Point(109, 3)
        btnFufu.Name = "btnFufu"
        btnFufu.Size = New Size(100, 100)
        btnFufu.TabIndex = 5
        btnFufu.Tag = "`Fufu"
        btnFufu.Text = "Fufu" & vbCrLf & "GH₵20.00"
        btnFufu.UseVisualStyleBackColor = False
        ' 
        ' btnBanku
        ' 
        btnBanku.BackColor = Color.White
        btnBanku.Cursor = Cursors.Hand
        btnBanku.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnBanku.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnBanku.FlatStyle = FlatStyle.Flat
        btnBanku.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBanku.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnBanku.Location = New Point(215, 3)
        btnBanku.Name = "btnBanku"
        btnBanku.Size = New Size(100, 100)
        btnBanku.TabIndex = 6
        btnBanku.Tag = "`Banku"
        btnBanku.Text = "Banku" & vbCrLf & "GH₵25.00"
        btnBanku.UseVisualStyleBackColor = False
        ' 
        ' btnJollof
        ' 
        btnJollof.BackColor = Color.White
        btnJollof.Cursor = Cursors.Hand
        btnJollof.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnJollof.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnJollof.FlatStyle = FlatStyle.Flat
        btnJollof.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnJollof.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnJollof.Location = New Point(321, 3)
        btnJollof.Name = "btnJollof"
        btnJollof.Size = New Size(100, 100)
        btnJollof.TabIndex = 7
        btnJollof.Tag = "`Jollof Rice"
        btnJollof.Text = "Jollof Rice" & vbCrLf & "GH₵18.00"
        btnJollof.UseVisualStyleBackColor = False
        ' 
        ' btnFriedRice
        ' 
        btnFriedRice.BackColor = Color.White
        btnFriedRice.Cursor = Cursors.Hand
        btnFriedRice.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnFriedRice.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnFriedRice.FlatStyle = FlatStyle.Flat
        btnFriedRice.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnFriedRice.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnFriedRice.Location = New Point(427, 3)
        btnFriedRice.Name = "btnFriedRice"
        btnFriedRice.Size = New Size(100, 100)
        btnFriedRice.TabIndex = 8
        btnFriedRice.Tag = "`Fried Rice"
        btnFriedRice.Text = "Fried Rice" & vbCrLf & "GH₵16.00"
        btnFriedRice.UseVisualStyleBackColor = False
        ' 
        ' btnPlainRice
        ' 
        btnPlainRice.BackColor = Color.White
        btnPlainRice.Cursor = Cursors.Hand
        btnPlainRice.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnPlainRice.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnPlainRice.FlatStyle = FlatStyle.Flat
        btnPlainRice.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnPlainRice.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnPlainRice.Location = New Point(3, 109)
        btnPlainRice.Name = "btnPlainRice"
        btnPlainRice.Size = New Size(100, 100)
        btnPlainRice.TabIndex = 9
        btnPlainRice.Tag = "`Plain Rice"
        btnPlainRice.Text = "Plain Rice" & vbCrLf & "GH₵12.00"
        btnPlainRice.UseVisualStyleBackColor = False
        ' 
        ' btnTurkey
        ' 
        btnTurkey.BackColor = Color.White
        btnTurkey.Cursor = Cursors.Hand
        btnTurkey.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnTurkey.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnTurkey.FlatStyle = FlatStyle.Flat
        btnTurkey.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnTurkey.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnTurkey.Location = New Point(109, 109)
        btnTurkey.Name = "btnTurkey"
        btnTurkey.Size = New Size(100, 100)
        btnTurkey.TabIndex = 10
        btnTurkey.Tag = "`Turkey Stew"
        btnTurkey.Text = "Turkey Stew" & vbCrLf & "GH₵10.00"
        btnTurkey.UseVisualStyleBackColor = False
        ' 
        ' btnChicken
        ' 
        btnChicken.BackColor = Color.White
        btnChicken.Cursor = Cursors.Hand
        btnChicken.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnChicken.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnChicken.FlatStyle = FlatStyle.Flat
        btnChicken.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnChicken.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnChicken.Location = New Point(215, 109)
        btnChicken.Name = "btnChicken"
        btnChicken.Size = New Size(100, 100)
        btnChicken.TabIndex = 11
        btnChicken.Tag = "`Chicken Stew"
        btnChicken.Text = "Chicken Stew" & vbCrLf & "GH₵10.00"
        btnChicken.UseVisualStyleBackColor = False
        ' 
        ' btnBeef
        ' 
        btnBeef.BackColor = Color.White
        btnBeef.Cursor = Cursors.Hand
        btnBeef.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnBeef.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnBeef.FlatStyle = FlatStyle.Flat
        btnBeef.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBeef.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnBeef.Location = New Point(321, 109)
        btnBeef.Name = "btnBeef"
        btnBeef.Size = New Size(100, 100)
        btnBeef.TabIndex = 12
        btnBeef.Tag = "`Beef Stew"
        btnBeef.Text = "Beef Stew" & vbCrLf & "GH₵12.00"
        btnBeef.UseVisualStyleBackColor = False
        ' 
        ' btnWater
        ' 
        btnWater.BackColor = Color.White
        btnWater.Cursor = Cursors.Hand
        btnWater.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnWater.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnWater.FlatStyle = FlatStyle.Flat
        btnWater.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnWater.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnWater.Location = New Point(427, 109)
        btnWater.Name = "btnWater"
        btnWater.Size = New Size(100, 100)
        btnWater.TabIndex = 13
        btnWater.Tag = "`Bottled Water"
        btnWater.Text = "Bottled Water" & vbCrLf & "GH₵3.00"
        btnWater.UseVisualStyleBackColor = False
        ' 
        ' btnSobolo
        ' 
        btnSobolo.BackColor = Color.White
        btnSobolo.Cursor = Cursors.Hand
        btnSobolo.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnSobolo.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnSobolo.FlatStyle = FlatStyle.Flat
        btnSobolo.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSobolo.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnSobolo.Location = New Point(3, 215)
        btnSobolo.Name = "btnSobolo"
        btnSobolo.Size = New Size(100, 100)
        btnSobolo.TabIndex = 14
        btnSobolo.Tag = "`Sobolo"
        btnSobolo.Text = "Sobolo" & vbCrLf & "GH₵5.00"
        btnSobolo.UseVisualStyleBackColor = False
        ' 
        ' btnSoftDrink
        ' 
        btnSoftDrink.BackColor = Color.White
        btnSoftDrink.Cursor = Cursors.Hand
        btnSoftDrink.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnSoftDrink.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnSoftDrink.FlatStyle = FlatStyle.Flat
        btnSoftDrink.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSoftDrink.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnSoftDrink.Location = New Point(109, 215)
        btnSoftDrink.Name = "btnSoftDrink"
        btnSoftDrink.Size = New Size(100, 100)
        btnSoftDrink.TabIndex = 15
        btnSoftDrink.Tag = "`Soft Drink"
        btnSoftDrink.Text = "Soft Drink" & vbCrLf & "GH₵6.00"
        btnSoftDrink.UseVisualStyleBackColor = False
        ' 
        ' btnMalta
        ' 
        btnMalta.BackColor = Color.White
        btnMalta.Cursor = Cursors.Hand
        btnMalta.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnMalta.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnMalta.FlatStyle = FlatStyle.Flat
        btnMalta.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMalta.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnMalta.Location = New Point(215, 215)
        btnMalta.Name = "btnMalta"
        btnMalta.Size = New Size(100, 100)
        btnMalta.TabIndex = 16
        btnMalta.Tag = "`Malta Guinness"
        btnMalta.Text = "Malta Guinness" & vbCrLf & "GH₵8.00"
        btnMalta.UseVisualStyleBackColor = False
        ' 
        ' btnJuice
        ' 
        btnJuice.BackColor = Color.White
        btnJuice.Cursor = Cursors.Hand
        btnJuice.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnJuice.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnJuice.FlatStyle = FlatStyle.Flat
        btnJuice.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnJuice.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnJuice.Location = New Point(321, 215)
        btnJuice.Name = "btnJuice"
        btnJuice.Size = New Size(100, 100)
        btnJuice.TabIndex = 17
        btnJuice.Tag = "`Fruit Juice"
        btnJuice.Text = "Fruit Juice" & vbCrLf & "GH₵10.00" & vbCrLf
        btnJuice.UseVisualStyleBackColor = False
        ' 
        ' btnPalmWine
        ' 
        btnPalmWine.BackColor = Color.White
        btnPalmWine.Cursor = Cursors.Hand
        btnPalmWine.FlatAppearance.BorderColor = Color.FromArgb(CByte(200), CByte(205), CByte(210))
        btnPalmWine.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(255), CByte(243), CByte(205))
        btnPalmWine.FlatStyle = FlatStyle.Flat
        btnPalmWine.Font = New Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnPalmWine.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnPalmWine.Location = New Point(427, 215)
        btnPalmWine.Name = "btnPalmWine"
        btnPalmWine.Size = New Size(100, 100)
        btnPalmWine.TabIndex = 18
        btnPalmWine.Tag = "`Palm Wine"
        btnPalmWine.Text = "Palm Wine" & vbCrLf & "GH₵10.00" & vbCrLf
        btnPalmWine.UseVisualStyleBackColor = False
        ' 
        ' lblMealsTitle
        ' 
        lblMealsTitle.AutoSize = True
        lblMealsTitle.BackColor = Color.Transparent
        lblMealsTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblMealsTitle.Location = New Point(12, 8)
        lblMealsTitle.Name = "lblMealsTitle"
        lblMealsTitle.Size = New Size(162, 28)
        lblMealsTitle.TabIndex = 6
        lblMealsTitle.Text = "Meals Available"
        ' 
        ' txtSearch
        ' 
        txtSearch.BorderStyle = BorderStyle.FixedSingle
        txtSearch.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtSearch.Location = New Point(230, 6)
        txtSearch.Name = "txtSearch"
        txtSearch.PlaceholderText = "Search meals..."
        txtSearch.Size = New Size(310, 30)
        txtSearch.TabIndex = 50
        ' 
        ' lblStockHint
        ' 
        lblStockHint.AutoSize = True
        lblStockHint.Font = New Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblStockHint.ForeColor = Color.FromArgb(CByte(107), CByte(114), CByte(128))
        lblStockHint.Location = New Point(12, 384)
        lblStockHint.Name = "lblStockHint"
        lblStockHint.Size = New Size(244, 17)
        lblStockHint.TabIndex = 19
        lblStockHint.Text = "Tip: right-click a meal to mark it sold out"
        ' 
        ' pnlStats
        ' 
        pnlStats.Controls.Add(pnlAvgCard)
        pnlStats.Controls.Add(Panel2)
        pnlStats.Controls.Add(Panel1)
        pnlStats.Controls.Add(pnlSalesCard)
        pnlStats.Controls.Add(lblStatsTitle)
        pnlStats.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlStats.Location = New Point(12, 8)
        pnlStats.Name = "pnlStats"
        pnlStats.Size = New Size(1250, 118)
        pnlStats.TabIndex = 0
        ' 
        ' pnlAvgCard
        ' 
        pnlAvgCard.BackColor = Color.FromArgb(CByte(253), CByte(243), CByte(215))
        pnlAvgCard.Controls.Add(lblAvgVal)
        pnlAvgCard.Controls.Add(lblAvgCap)
        pnlAvgCard.Font = New Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        pnlAvgCard.ForeColor = Color.FromArgb(CByte(75), CByte(85), CByte(99))
        pnlAvgCard.Location = New Point(632, 40)
        pnlAvgCard.Name = "pnlAvgCard"
        pnlAvgCard.Size = New Size(290, 70)
        pnlAvgCard.TabIndex = 9
        ' 
        ' lblAvgVal
        ' 
        lblAvgVal.AutoSize = True
        lblAvgVal.BackColor = Color.Transparent
        lblAvgVal.Font = New Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAvgVal.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblAvgVal.Location = New Point(8, 32)
        lblAvgVal.Name = "lblAvgVal"
        lblAvgVal.Size = New Size(106, 31)
        lblAvgVal.TabIndex = 1
        lblAvgVal.Text = "GH₵0.00"
        ' 
        ' lblAvgCap
        ' 
        lblAvgCap.AutoSize = True
        lblAvgCap.BackColor = Color.Transparent
        lblAvgCap.Location = New Point(8, 8)
        lblAvgCap.Name = "lblAvgCap"
        lblAvgCap.Size = New Size(104, 17)
        lblAvgCap.TabIndex = 0
        lblAvgCap.Text = "Avg Order Value"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(240), CByte(234), CByte(250))
        Panel2.Controls.Add(lblMethodVal)
        Panel2.Controls.Add(lblMethodCap)
        Panel2.Font = New Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Panel2.ForeColor = Color.FromArgb(CByte(75), CByte(85), CByte(99))
        Panel2.Location = New Point(942, 40)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(290, 70)
        Panel2.TabIndex = 11
        ' 
        ' lblMethodVal
        ' 
        lblMethodVal.AutoSize = True
        lblMethodVal.BackColor = Color.Transparent
        lblMethodVal.Font = New Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMethodVal.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblMethodVal.Location = New Point(8, 32)
        lblMethodVal.Name = "lblMethodVal"
        lblMethodVal.Size = New Size(23, 31)
        lblMethodVal.TabIndex = 1
        lblMethodVal.Text = "-"
        ' 
        ' lblMethodCap
        ' 
        lblMethodCap.AutoSize = True
        lblMethodCap.BackColor = Color.Transparent
        lblMethodCap.Location = New Point(8, 8)
        lblMethodCap.Name = "lblMethodCap"
        lblMethodCap.Size = New Size(129, 17)
        lblMethodCap.TabIndex = 0
        lblMethodCap.Text = "Most Used Payment "
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(227), CByte(240), CByte(250))
        Panel1.Controls.Add(lblOrdersVal)
        Panel1.Controls.Add(lblOrdersCap)
        Panel1.Font = New Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Panel1.ForeColor = Color.FromArgb(CByte(75), CByte(85), CByte(99))
        Panel1.Location = New Point(322, 40)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(290, 70)
        Panel1.TabIndex = 10
        ' 
        ' lblOrdersVal
        ' 
        lblOrdersVal.AutoSize = True
        lblOrdersVal.BackColor = Color.Transparent
        lblOrdersVal.Font = New Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblOrdersVal.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblOrdersVal.Location = New Point(8, 32)
        lblOrdersVal.Name = "lblOrdersVal"
        lblOrdersVal.Size = New Size(27, 31)
        lblOrdersVal.TabIndex = 1
        lblOrdersVal.Text = "0"
        ' 
        ' lblOrdersCap
        ' 
        lblOrdersCap.AutoSize = True
        lblOrdersCap.BackColor = Color.Transparent
        lblOrdersCap.Location = New Point(8, 8)
        lblOrdersCap.Name = "lblOrdersCap"
        lblOrdersCap.Size = New Size(81, 17)
        lblOrdersCap.TabIndex = 0
        lblOrdersCap.Text = "Total Orders" & vbTab
        ' 
        ' pnlSalesCard
        ' 
        pnlSalesCard.BackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        pnlSalesCard.Controls.Add(lblSalesVal)
        pnlSalesCard.Controls.Add(lblSalesCap)
        pnlSalesCard.Font = New Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        pnlSalesCard.ForeColor = Color.FromArgb(CByte(75), CByte(85), CByte(99))
        pnlSalesCard.Location = New Point(12, 40)
        pnlSalesCard.Name = "pnlSalesCard"
        pnlSalesCard.Size = New Size(290, 70)
        pnlSalesCard.TabIndex = 8
        ' 
        ' lblSalesVal
        ' 
        lblSalesVal.AutoSize = True
        lblSalesVal.BackColor = Color.Transparent
        lblSalesVal.Font = New Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblSalesVal.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblSalesVal.Location = New Point(8, 32)
        lblSalesVal.Name = "lblSalesVal"
        lblSalesVal.Size = New Size(106, 31)
        lblSalesVal.TabIndex = 1
        lblSalesVal.Text = "GH₵0.00"
        ' 
        ' lblSalesCap
        ' 
        lblSalesCap.AutoSize = True
        lblSalesCap.BackColor = Color.Transparent
        lblSalesCap.Location = New Point(8, 8)
        lblSalesCap.Name = "lblSalesCap"
        lblSalesCap.Size = New Size(117, 17)
        lblSalesCap.TabIndex = 0
        lblSalesCap.Text = "Total Sales (Today)"
        ' 
        ' lblStatsTitle
        ' 
        lblStatsTitle.AutoSize = True
        lblStatsTitle.BackColor = Color.Transparent
        lblStatsTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblStatsTitle.Location = New Point(12, 8)
        lblStatsTitle.Name = "lblStatsTitle"
        lblStatsTitle.Size = New Size(119, 28)
        lblStatsTitle.TabIndex = 7
        lblStatsTitle.Text = "Quick Stats"
        ' 
        ' pnlHistory
        ' 
        pnlHistory.Controls.Add(dtpTo)
        pnlHistory.Controls.Add(lblTo)
        pnlHistory.Controls.Add(dtpFrom)
        pnlHistory.Controls.Add(lblFrom)
        pnlHistory.Controls.Add(btnFilter)
        pnlHistory.Controls.Add(btnViewAll)
        pnlHistory.Controls.Add(lvHistory)
        pnlHistory.Controls.Add(lblHistoryTitle)
        pnlHistory.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlHistory.Location = New Point(12, 134)
        pnlHistory.Name = "pnlHistory"
        pnlHistory.Size = New Size(1250, 520)
        pnlHistory.TabIndex = 0
        ' 
        ' dtpTo
        ' 
        dtpTo.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        dtpTo.Location = New Point(280, 480)
        dtpTo.Name = "dtpTo"
        dtpTo.Size = New Size(90, 27)
        dtpTo.TabIndex = 14
        ' 
        ' lblTo
        ' 
        lblTo.AutoSize = True
        lblTo.BackColor = Color.Transparent
        lblTo.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTo.Location = New Point(254, 484)
        lblTo.Name = "lblTo"
        lblTo.Size = New Size(30, 20)
        lblTo.TabIndex = 13
        lblTo.Text = "To:"
        ' 
        ' dtpFrom
        ' 
        dtpFrom.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        dtpFrom.Format = DateTimePickerFormat.Short
        dtpFrom.Location = New Point(155, 480)
        dtpFrom.Name = "dtpFrom"
        dtpFrom.Size = New Size(100, 27)
        dtpFrom.TabIndex = 12
        ' 
        ' lblFrom
        ' 
        lblFrom.AutoSize = True
        lblFrom.BackColor = Color.Transparent
        lblFrom.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblFrom.Location = New Point(108, 484)
        lblFrom.Name = "lblFrom"
        lblFrom.Size = New Size(50, 20)
        lblFrom.TabIndex = 11
        lblFrom.Text = "From:"
        ' 
        ' btnFilter
        ' 
        btnFilter.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        btnFilter.Cursor = Cursors.Hand
        btnFilter.FlatAppearance.BorderSize = 0
        btnFilter.FlatStyle = FlatStyle.Flat
        btnFilter.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnFilter.ForeColor = Color.White
        btnFilter.Location = New Point(392, 476)
        btnFilter.Name = "btnFilter"
        btnFilter.Size = New Size(90, 32)
        btnFilter.TabIndex = 10
        btnFilter.Text = "Filter"
        btnFilter.UseVisualStyleBackColor = False
        ' 
        ' btnViewAll
        ' 
        btnViewAll.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        btnViewAll.Cursor = Cursors.Hand
        btnViewAll.FlatAppearance.BorderSize = 0
        btnViewAll.FlatStyle = FlatStyle.Flat
        btnViewAll.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnViewAll.ForeColor = Color.White
        btnViewAll.Location = New Point(12, 476)
        btnViewAll.Name = "btnViewAll"
        btnViewAll.Size = New Size(88, 32)
        btnViewAll.TabIndex = 9
        btnViewAll.Text = "View All"
        btnViewAll.UseVisualStyleBackColor = False
        ' 
        ' lvHistory
        ' 
        lvHistory.BorderStyle = BorderStyle.FixedSingle
        lvHistory.Columns.AddRange(New ColumnHeader() {colHDate, colHCust, colHItems, colHTotal, colHMethod})
        lvHistory.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lvHistory.FullRowSelect = True
        lvHistory.GridLines = True
        lvHistory.Location = New Point(12, 44)
        lvHistory.Name = "lvHistory"
        lvHistory.Size = New Size(1226, 420)
        lvHistory.TabIndex = 8
        lvHistory.UseCompatibleStateImageBehavior = False
        lvHistory.View = View.Details
        ' 
        ' colHDate
        ' 
        colHDate.Text = "Date & Time"
        colHDate.Width = 160
        ' 
        ' colHCust
        ' 
        colHCust.Text = "Customer"
        colHCust.Width = 130
        ' 
        ' colHItems
        ' 
        colHItems.Text = "Items"
        colHItems.Width = 520
        ' 
        ' colHTotal
        ' 
        colHTotal.Text = "Total"
        colHTotal.Width = 150
        ' 
        ' colHMethod
        ' 
        colHMethod.Text = "Payment Method"
        colHMethod.Width = 200
        ' 
        ' lblHistoryTitle
        ' 
        lblHistoryTitle.AutoSize = True
        lblHistoryTitle.BackColor = Color.Transparent
        lblHistoryTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblHistoryTitle.Location = New Point(12, 8)
        lblHistoryTitle.Name = "lblHistoryTitle"
        lblHistoryTitle.Size = New Size(122, 28)
        lblHistoryTitle.TabIndex = 7
        lblHistoryTitle.Text = "History Log"
        ' 
        ' tabMain
        ' 
        tabMain.Controls.Add(tpOrder)
        tabMain.Controls.Add(tpReports)
        tabMain.Dock = DockStyle.Fill
        tabMain.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        tabMain.Location = New Point(0, 56)
        tabMain.Name = "tabMain"
        tabMain.SelectedIndex = 0
        tabMain.Size = New Size(1295, 705)
        tabMain.SizeMode = TabSizeMode.Fixed
        tabMain.TabIndex = 5
        ' 
        ' tpOrder
        ' 
        tpOrder.Controls.Add(pnlMeals)
        tpOrder.Controls.Add(pnlMenu)
        tpOrder.Controls.Add(pnlPayment)
        tpOrder.Controls.Add(pnlCustomization)
        tpOrder.Controls.Add(pnlOrder)
        tpOrder.Location = New Point(4, 32)
        tpOrder.Name = "tpOrder"
        tpOrder.Padding = New Padding(3)
        tpOrder.Size = New Size(1287, 669)
        tpOrder.TabIndex = 0
        tpOrder.Text = "Order"
        tpOrder.UseVisualStyleBackColor = True
        ' 
        ' pnlMenu
        ' 
        pnlMenu.Controls.Add(rbDrinks)
        pnlMenu.Controls.Add(rbOthers)
        pnlMenu.Controls.Add(rbFufu)
        pnlMenu.Controls.Add(rbJollof)
        pnlMenu.Controls.Add(rbWaakye)
        pnlMenu.Controls.Add(rbBanku)
        pnlMenu.Controls.Add(rbAll)
        pnlMenu.Controls.Add(lblMenu)
        pnlMenu.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        pnlMenu.Location = New Point(12, 8)
        pnlMenu.Name = "pnlMenu"
        pnlMenu.Size = New Size(128, 410)
        pnlMenu.TabIndex = 6
        ' 
        ' rbDrinks
        ' 
        rbDrinks.Appearance = Appearance.Button
        rbDrinks.BackColor = Color.Transparent
        rbDrinks.Cursor = Cursors.Hand
        rbDrinks.FlatAppearance.BorderSize = 0
        rbDrinks.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbDrinks.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbDrinks.FlatStyle = FlatStyle.Flat
        rbDrinks.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbDrinks.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbDrinks.Location = New Point(4, 294)
        rbDrinks.Name = "rbDrinks"
        rbDrinks.Padding = New Padding(4, 0, 0, 0)
        rbDrinks.Size = New Size(112, 44)
        rbDrinks.TabIndex = 14
        rbDrinks.TabStop = True
        rbDrinks.Text = ChrW(55358) & ChrW(56676) & " Drinks"
        rbDrinks.UseVisualStyleBackColor = False
        ' 
        ' rbOthers
        ' 
        rbOthers.Appearance = Appearance.Button
        rbOthers.BackColor = Color.Transparent
        rbOthers.Cursor = Cursors.Hand
        rbOthers.FlatAppearance.BorderSize = 0
        rbOthers.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbOthers.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbOthers.FlatStyle = FlatStyle.Flat
        rbOthers.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbOthers.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbOthers.Location = New Point(4, 344)
        rbOthers.Name = "rbOthers"
        rbOthers.Padding = New Padding(4, 0, 0, 0)
        rbOthers.Size = New Size(112, 44)
        rbOthers.TabIndex = 13
        rbOthers.TabStop = True
        rbOthers.Text = "⋯ Others"
        rbOthers.UseVisualStyleBackColor = False
        ' 
        ' rbFufu
        ' 
        rbFufu.Appearance = Appearance.Button
        rbFufu.BackColor = Color.Transparent
        rbFufu.Cursor = Cursors.Hand
        rbFufu.FlatAppearance.BorderSize = 0
        rbFufu.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbFufu.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbFufu.FlatStyle = FlatStyle.Flat
        rbFufu.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbFufu.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbFufu.Location = New Point(4, 244)
        rbFufu.Name = "rbFufu"
        rbFufu.Padding = New Padding(4, 0, 0, 0)
        rbFufu.Size = New Size(112, 44)
        rbFufu.TabIndex = 12
        rbFufu.TabStop = True
        rbFufu.Text = "🍲 Fufu"
        rbFufu.UseVisualStyleBackColor = False
        ' 
        ' rbJollof
        ' 
        rbJollof.Appearance = Appearance.Button
        rbJollof.BackColor = Color.Transparent
        rbJollof.Cursor = Cursors.Hand
        rbJollof.FlatAppearance.BorderSize = 0
        rbJollof.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbJollof.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbJollof.FlatStyle = FlatStyle.Flat
        rbJollof.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbJollof.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbJollof.Location = New Point(4, 194)
        rbJollof.Name = "rbJollof"
        rbJollof.Padding = New Padding(4, 0, 0, 0)
        rbJollof.Size = New Size(112, 44)
        rbJollof.TabIndex = 11
        rbJollof.TabStop = True
        rbJollof.Text = "🍲 Jollof"
        rbJollof.UseVisualStyleBackColor = False
        ' 
        ' rbWaakye
        ' 
        rbWaakye.Appearance = Appearance.Button
        rbWaakye.BackColor = Color.Transparent
        rbWaakye.Cursor = Cursors.Hand
        rbWaakye.FlatAppearance.BorderSize = 0
        rbWaakye.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbWaakye.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbWaakye.FlatStyle = FlatStyle.Flat
        rbWaakye.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbWaakye.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbWaakye.Location = New Point(4, 144)
        rbWaakye.Name = "rbWaakye"
        rbWaakye.Padding = New Padding(4, 0, 0, 0)
        rbWaakye.Size = New Size(112, 44)
        rbWaakye.TabIndex = 10
        rbWaakye.TabStop = True
        rbWaakye.Text = "🍲 Waakye"
        rbWaakye.UseVisualStyleBackColor = False
        ' 
        ' rbBanku
        ' 
        rbBanku.Appearance = Appearance.Button
        rbBanku.BackColor = Color.Transparent
        rbBanku.Cursor = Cursors.Hand
        rbBanku.FlatAppearance.BorderSize = 0
        rbBanku.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbBanku.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbBanku.FlatStyle = FlatStyle.Flat
        rbBanku.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbBanku.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbBanku.Location = New Point(4, 94)
        rbBanku.Name = "rbBanku"
        rbBanku.Padding = New Padding(4, 0, 0, 0)
        rbBanku.Size = New Size(112, 44)
        rbBanku.TabIndex = 9
        rbBanku.TabStop = True
        rbBanku.Text = "🍲 Banku"
        rbBanku.UseVisualStyleBackColor = False
        ' 
        ' rbAll
        ' 
        rbAll.Appearance = Appearance.Button
        rbAll.BackColor = Color.Transparent
        rbAll.Cursor = Cursors.Hand
        rbAll.FlatAppearance.BorderSize = 0
        rbAll.FlatAppearance.CheckedBackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        rbAll.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(231), CByte(241), CByte(236))
        rbAll.FlatStyle = FlatStyle.Flat
        rbAll.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        rbAll.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        rbAll.Location = New Point(4, 44)
        rbAll.Name = "rbAll"
        rbAll.Padding = New Padding(4, 0, 0, 0)
        rbAll.Size = New Size(112, 44)
        rbAll.TabIndex = 8
        rbAll.TabStop = True
        rbAll.Text = "🍽 All Meals"
        rbAll.UseVisualStyleBackColor = False
        ' 
        ' lblMenu
        ' 
        lblMenu.AutoSize = True
        lblMenu.BackColor = Color.Transparent
        lblMenu.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblMenu.Location = New Point(12, 8)
        lblMenu.Name = "lblMenu"
        lblMenu.Size = New Size(66, 28)
        lblMenu.TabIndex = 7
        lblMenu.Text = "Menu"
        ' 
        ' tpReports
        ' 
        tpReports.Controls.Add(pnlHistory)
        tpReports.Controls.Add(pnlStats)
        tpReports.Location = New Point(4, 32)
        tpReports.Name = "tpReports"
        tpReports.Padding = New Padding(3)
        tpReports.Size = New Size(1287, 669)
        tpReports.TabIndex = 1
        tpReports.Text = "Reports"
        tpReports.UseVisualStyleBackColor = True
        ' 
        ' frmDashboard
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(243), CByte(247), CByte(245))
        ClientSize = New Size(1295, 761)
        Controls.Add(tabMain)
        Controls.Add(pnlHeader)
        FormBorderStyle = FormBorderStyle.FixedSingle
        MaximizeBox = False
        Name = "frmDashboard"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ChopBar POS - Cashier Dashboard"
        pnlHeader.ResumeLayout(False)
        pnlHeader.PerformLayout()
        pnlPayment.ResumeLayout(False)
        pnlPayment.PerformLayout()
        pnlCustomization.ResumeLayout(False)
        pnlCustomization.PerformLayout()
        pnlOrder.ResumeLayout(False)
        pnlOrder.PerformLayout()
        CType(nudQty, ComponentModel.ISupportInitialize).EndInit()
        pnlMeals.ResumeLayout(False)
        pnlMeals.PerformLayout()
        flpMeals.ResumeLayout(False)
        pnlStats.ResumeLayout(False)
        pnlStats.PerformLayout()
        pnlAvgCard.ResumeLayout(False)
        pnlAvgCard.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        pnlSalesCard.ResumeLayout(False)
        pnlSalesCard.PerformLayout()
        pnlHistory.ResumeLayout(False)
        pnlHistory.PerformLayout()
        tabMain.ResumeLayout(False)
        tpOrder.ResumeLayout(False)
        pnlMenu.ResumeLayout(False)
        pnlMenu.PerformLayout()
        tpReports.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents pnlHeader As Panel
    Friend WithEvents pnlPayment As Panel
    Friend WithEvents pnlOrder As Panel
    Friend WithEvents pnlCustomization As Panel
    Friend WithEvents pnlStats As Panel
    Friend WithEvents pnlHistory As Panel
    Friend WithEvents lblUser As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblLogo As Label
    Friend WithEvents lblUserIcon As Label
    Friend WithEvents lblCalIcon As Label
    Friend WithEvents lblOrderTitle As Label
    Friend WithEvents lblCustTitle As Label
    Friend WithEvents lblPaymentTitle As Label
    Friend WithEvents lblHistoryTitle As Label
    Friend WithEvents lblStatsTitle As Label
    Friend WithEvents rbCash As RadioButton
    Friend WithEvents rbMoMo As RadioButton
    Friend WithEvents rbBank As RadioButton
    Friend WithEvents rbCard As RadioButton
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents lblAmtCap As Label
    Friend WithEvents btnComplete As Button
    Friend WithEvents lvOrder As ListView
    Friend WithEvents colItem As ColumnHeader
    Friend WithEvents colPrice As ColumnHeader
    Friend WithEvents colQty As ColumnHeader
    Friend WithEvents colSub As ColumnHeader
    Friend WithEvents colCust As ColumnHeader
    Friend WithEvents nudQty As NumericUpDown
    Friend WithEvents lblQtyCap As Label
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents lblChangeCap As Label
    Friend WithEvents lblChange As Label
    Friend WithEvents lblExtras As Label
    Friend WithEvents lblProtein As Label
    Friend WithEvents txtPaid As TextBox
    Friend WithEvents lblTotalCap As Label
    Friend WithEvents lblPaidCap As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnReport As Button
    Friend WithEvents btnPay As Button
    Friend WithEvents lblNote As Label
    Friend WithEvents lblSelected As Label
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents cbAvocado As CheckBox
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents cbPlantain As CheckBox
    Friend WithEvents cbEgg As CheckBox
    Friend WithEvents cbShito As CheckBox
    Friend WithEvents cbTurkey As CheckBox
    Friend WithEvents cbFish As CheckBox
    Friend WithEvents cbChicken As CheckBox
    Friend WithEvents cbBeef As CheckBox
    Friend WithEvents txtNote As TextBox
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnCustCancel As Button
    Friend WithEvents lvHistory As ListView
    Friend WithEvents btnViewAll As Button
    Friend WithEvents btnFilter As Button
    Friend WithEvents lblTo As Label
    Friend WithEvents dtpFrom As DateTimePicker
    Friend WithEvents lblFrom As Label
    Friend WithEvents dtpTo As DateTimePicker
    Friend WithEvents colHDate As ColumnHeader
    Friend WithEvents colHCust As ColumnHeader
    Friend WithEvents colHItems As ColumnHeader
    Friend WithEvents colHTotal As ColumnHeader
    Friend WithEvents colHMethod As ColumnHeader
    Friend WithEvents pnlSalesCard As Panel
    Friend WithEvents pnlOrdersCard As Panel
    Friend WithEvents lblSalesVal As Label
    Friend WithEvents lblSalesCap As Label
    Friend WithEvents pnlAvgCard As Panel
    Private lblAvgVal As Label
    Friend WithEvents lblStockHint As Label
    Friend WithEvents lblAvgCap As Label
    Friend WithEvents Panel2 As Panel
    Private WithEvents lblMethodVal As Label
    Friend WithEvents lblMethodCap As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblOrdersVal As Label
    Friend WithEvents lblOrdersCap As Label
    Friend WithEvents pnlMeals As Panel
    Friend WithEvents flpMeals As FlowLayoutPanel
    Friend WithEvents btnWaakye As Button
    Friend WithEvents btnFufu As Button
    Friend WithEvents btnBanku As Button
    Friend WithEvents btnJollof As Button
    Friend WithEvents btnFriedRice As Button
    Friend WithEvents btnPlainRice As Button
    Friend WithEvents btnTurkey As Button
    Friend WithEvents btnChicken As Button
    Friend WithEvents btnBeef As Button
    Friend WithEvents btnWater As Button
    Friend WithEvents btnSobolo As Button
    Friend WithEvents btnSoftDrink As Button
    Friend WithEvents btnMalta As Button
    Friend WithEvents btnJuice As Button
    Friend WithEvents btnPalmWine As Button
    Friend WithEvents lblMealsTitle As Label
    Friend WithEvents tabMain As TabControl
    Friend WithEvents tpOrder As TabPage
    Friend WithEvents tpReports As TabPage
    Friend WithEvents pnlMenu As Panel
    Friend WithEvents rbDrinks As RadioButton
    Friend WithEvents rbOthers As RadioButton
    Friend WithEvents rbFufu As RadioButton
    Friend WithEvents rbJollof As RadioButton
    Friend WithEvents rbWaakye As RadioButton
    Friend WithEvents rbBanku As RadioButton
    Friend WithEvents rbAll As RadioButton
    Friend WithEvents lblMenu As Label
    Friend WithEvents rbTakeAway As RadioButton
    Friend WithEvents rbDineIn As RadioButton
    Friend WithEvents lblPortion As Label
    Friend WithEvents rbSmall As RadioButton
    Friend WithEvents rbLarge As RadioButton
    Friend WithEvents rbRegular As RadioButton
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnLogout As Button
    Friend WithEvents lblMealCount As Label
    Friend WithEvents lblDiscCap As Label
    Friend WithEvents txtDiscount As TextBox
    Friend WithEvents lblTableCap As Label
    Friend WithEvents lblBreakdown As Label
    Friend WithEvents txtTable As TextBox
End Class
