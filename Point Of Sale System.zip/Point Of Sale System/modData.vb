﻿' ===== Shared data used by the login, cashier and admin forms =====

Public Class MenuEntry
    Public Id As Integer
    Public Name As String = ""
    Public Category As String = "Others"
    Public Price As Decimal
    Public SoldOut As Boolean
End Class

Public Class SaleLine
    Public Name As String = ""
    Public Category As String = ""
    Public Qty As Integer
    Public Amount As Decimal
End Class

Public Class SaleRecord
    Public SoldAt As DateTime
    Public Cashier As String = ""
    Public Customer As String = "Walk-in"
    Public OrderType As String = "Dine In"
    Public Table As String = ""
    Public Items As String = ""
    Public Total As Decimal
    Public Method As String = "Cash"
    Public Ticket As Integer
    Public Lines As New List(Of SaleLine)
End Class

Public Class Account
    Public Username As String = ""
    Public Password As String = ""
    Public Role As String = "Cashier"
    Public Active As Boolean = True
    Public LastLogin As String = "-"
End Class

Public Module AppData
    Public ReadOnly MenuList As List(Of MenuEntry) = BuildMenu()
    Public ReadOnly SalesList As New List(Of SaleRecord)
    Public ReadOnly Accounts As List(Of Account) = BuildAccounts()
    Public CurrentUser As String = ""
    Private ticketNo As Integer = 0

    Private Function BuildMenu() As List(Of MenuEntry)
        Dim l As New List(Of MenuEntry)
        l.Add(New MenuEntry With {.Id = 1, .Name = "Waakye", .Category = "Waakye", .Price = 15D})
        l.Add(New MenuEntry With {.Id = 2, .Name = "Fufu", .Category = "Fufu", .Price = 20D})
        l.Add(New MenuEntry With {.Id = 3, .Name = "Banku", .Category = "Banku", .Price = 25D})
        l.Add(New MenuEntry With {.Id = 4, .Name = "Jollof Rice", .Category = "Jollof", .Price = 18D})
        l.Add(New MenuEntry With {.Id = 5, .Name = "Fried Rice", .Category = "Others", .Price = 16D})
        l.Add(New MenuEntry With {.Id = 6, .Name = "Plain Rice", .Category = "Others", .Price = 12D})
        l.Add(New MenuEntry With {.Id = 7, .Name = "Turkey Stew", .Category = "Others", .Price = 10D})
        l.Add(New MenuEntry With {.Id = 8, .Name = "Chicken Stew", .Category = "Others", .Price = 10D})
        l.Add(New MenuEntry With {.Id = 9, .Name = "Beef Stew", .Category = "Others", .Price = 12D})
        l.Add(New MenuEntry With {.Id = 10, .Name = "Bottled Water", .Category = "Drinks", .Price = 3D})
        l.Add(New MenuEntry With {.Id = 11, .Name = "Sobolo", .Category = "Drinks", .Price = 5D})
        l.Add(New MenuEntry With {.Id = 12, .Name = "Soft Drink", .Category = "Drinks", .Price = 6D})
        l.Add(New MenuEntry With {.Id = 13, .Name = "Malta Guinness", .Category = "Drinks", .Price = 8D})
        l.Add(New MenuEntry With {.Id = 14, .Name = "Fruit Juice", .Category = "Drinks", .Price = 10D})
        l.Add(New MenuEntry With {.Id = 15, .Name = "Palm Wine", .Category = "Drinks", .Price = 10D})
        Return l
    End Function

    Private Function BuildAccounts() As List(Of Account)
        Dim l As New List(Of Account)
        l.Add(New Account With {.Username = "admin", .Password = "admin123", .Role = "Admin"})
        l.Add(New Account With {.Username = "cashier", .Password = "1234", .Role = "Cashier"})
        l.Add(New Account With {.Username = "akosua", .Password = "1234", .Role = "Cashier", .Active = False})
        Return l
    End Function

    Public Function FindMenu(name As String) As MenuEntry
        For Each m As MenuEntry In MenuList
            If String.Equals(m.Name, name, StringComparison.OrdinalIgnoreCase) Then Return m
        Next
        Return Nothing
    End Function

    Public Function FindMenuById(id As Integer) As MenuEntry
        For Each m As MenuEntry In MenuList
            If m.Id = id Then Return m
        Next
        Return Nothing
    End Function

    Public Function NextMenuId() As Integer
        Dim highest As Integer = 0
        For Each m As MenuEntry In MenuList
            If m.Id > highest Then highest = m.Id
        Next
        Return highest + 1
    End Function

    Public Function CategoryOf(name As String) As String
        Dim m As MenuEntry = FindMenu(name)
        If m Is Nothing Then Return "Others"
        Return m.Category
    End Function

    Public Function SoldOutCount() As Integer
        Dim n As Integer = 0
        For Each m As MenuEntry In MenuList
            If m.SoldOut Then n += 1
        Next
        Return n
    End Function

    Public Function FindAccount(user As String) As Account
        For Each a As Account In Accounts
            If String.Equals(a.Username, user, StringComparison.OrdinalIgnoreCase) Then Return a
        Next
        Return Nothing
    End Function

    Public Function PasswordExists(pass As String) As Boolean
        For Each a As Account In Accounts
            If a.Password = pass Then Return True
        Next
        Return False
    End Function

    Public Function ActiveAdminCount() As Integer
        Dim n As Integer = 0
        For Each a As Account In Accounts
            If a.Role = "Admin" AndAlso a.Active Then n += 1
        Next
        Return n
    End Function

    Public Function NextTicket() As Integer
        ticketNo = If(ticketNo >= 999, 1, ticketNo + 1)
        Return ticketNo
    End Function

    Public Function DisplayName(user As String) As String
        If String.IsNullOrEmpty(user) Then Return "Admin"
        Return Char.ToUpper(user(0)) & user.Substring(1)
    End Function
End Module
