﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle9 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As DataGridViewCellStyle = New DataGridViewCellStyle()
        tabs = New TabControl()
        tpOverview = New TabPage()
        tlpOverview = New TableLayoutPanel()
        cardRecent = New Panel()
        lblRecent = New Label()
        gridRecent = New DataGridView()
        col_gridRecent_0 = New DataGridViewTextBoxColumn()
        col_gridRecent_1 = New DataGridViewTextBoxColumn()
        col_gridRecent_2 = New DataGridViewTextBoxColumn()
        col_gridRecent_3 = New DataGridViewTextBoxColumn()
        col_gridRecent_4 = New DataGridViewTextBoxColumn()
        cardCategory = New Panel()
        lblCategory = New Label()
        lblCat1 = New Label()
        pnlTrack1 = New Panel()
        pnlFill1 = New Panel()
        lblCat2 = New Label()
        pnlTrack2 = New Panel()
        pnlFill2 = New Panel()
        lblCat3 = New Label()
        pnlTrack3 = New Panel()
        pnlFill3 = New Panel()
        lblCat4 = New Label()
        pnlTrack4 = New Panel()
        pnlFill4 = New Panel()
        ovRow = New TableLayoutPanel()
        ovCard1 = New Panel()
        ovCap1 = New Label()
        ovVal1 = New Label()
        ovCard2 = New Panel()
        ovCap2 = New Label()
        ovVal2 = New Label()
        ovCard3 = New Panel()
        ovCap3 = New Label()
        ovVal3 = New Label()
        ovCard4 = New Panel()
        ovCap4 = New Label()
        ovVal4 = New Label()
        tpMenu = New TabPage()
        tlpMenu = New TableLayoutPanel()
        cardMenuList = New Panel()
        lblMenuList = New Label()
        txtSearch = New TextBox()
        gridMenu = New DataGridView()
        col_gridMenu_0 = New DataGridViewTextBoxColumn()
        col_gridMenu_1 = New DataGridViewTextBoxColumn()
        col_gridMenu_2 = New DataGridViewTextBoxColumn()
        col_gridMenu_3 = New DataGridViewTextBoxColumn()
        cardMenuForm = New Panel()
        lblMenuForm = New Label()
        lblItemName = New Label()
        txtItemName = New TextBox()
        lblCategoryCap = New Label()
        cboCategory = New ComboBox()
        lblPriceCap = New Label()
        txtPrice = New TextBox()
        btnSaveItem = New Button()
        btnSoldOut = New Button()
        btnDeleteItem = New Button()
        tpSales = New TabPage()
        cardHistory = New Panel()
        lblHistory = New Label()
        gridSales = New DataGridView()
        col_gridSales_0 = New DataGridViewTextBoxColumn()
        col_gridSales_1 = New DataGridViewTextBoxColumn()
        col_gridSales_2 = New DataGridViewTextBoxColumn()
        col_gridSales_3 = New DataGridViewTextBoxColumn()
        col_gridSales_4 = New DataGridViewTextBoxColumn()
        col_gridSales_5 = New DataGridViewTextBoxColumn()
        col_gridSales_6 = New DataGridViewTextBoxColumn()
        col_gridSales_7 = New DataGridViewTextBoxColumn()
        saRow = New TableLayoutPanel()
        saCard1 = New Panel()
        saCap1 = New Label()
        saVal1 = New Label()
        saCard2 = New Panel()
        saCap2 = New Label()
        saVal2 = New Label()
        saCard3 = New Panel()
        saCap3 = New Label()
        saVal3 = New Label()
        saCard4 = New Panel()
        saCap4 = New Label()
        saVal4 = New Label()
        pnlFilter = New Panel()
        lblFrom = New Label()
        dtpFrom = New DateTimePicker()
        lblTo = New Label()
        dtpTo = New DateTimePicker()
        lblCashierCap = New Label()
        cboCashier = New ComboBox()
        btnFilter = New Button()
        btnDaily = New Button()
        btnExport = New Button()
        tpStaff = New TabPage()
        tlpStaff = New TableLayoutPanel()
        cardStaffList = New Panel()
        lblStaffList = New Label()
        gridStaff = New DataGridView()
        col_gridStaff_0 = New DataGridViewTextBoxColumn()
        col_gridStaff_1 = New DataGridViewTextBoxColumn()
        col_gridStaff_2 = New DataGridViewTextBoxColumn()
        col_gridStaff_3 = New DataGridViewTextBoxColumn()
        cardStaffForm = New Panel()
        lblStaffForm = New Label()
        lblUsernameCap = New Label()
        txtUsername = New TextBox()
        lblPasswordCap = New Label()
        txtPassword = New TextBox()
        lblRoleCap = New Label()
        cboRole = New ComboBox()
        btnSaveAccount = New Button()
        btnResetPwd = New Button()
        btnDisable = New Button()
        pnlHeader = New Panel()
        btnLogout = New Button()
        lblTitle = New Label()
        lblHeaderRight = New Label()
        tabs.SuspendLayout()
        tpOverview.SuspendLayout()
        tlpOverview.SuspendLayout()
        cardRecent.SuspendLayout()
        CType(gridRecent, ComponentModel.ISupportInitialize).BeginInit()
        cardCategory.SuspendLayout()
        pnlTrack1.SuspendLayout()
        pnlTrack2.SuspendLayout()
        pnlTrack3.SuspendLayout()
        pnlTrack4.SuspendLayout()
        ovRow.SuspendLayout()
        ovCard1.SuspendLayout()
        ovCard2.SuspendLayout()
        ovCard3.SuspendLayout()
        ovCard4.SuspendLayout()
        tpMenu.SuspendLayout()
        tlpMenu.SuspendLayout()
        cardMenuList.SuspendLayout()
        CType(gridMenu, ComponentModel.ISupportInitialize).BeginInit()
        cardMenuForm.SuspendLayout()
        tpSales.SuspendLayout()
        cardHistory.SuspendLayout()
        CType(gridSales, ComponentModel.ISupportInitialize).BeginInit()
        saRow.SuspendLayout()
        saCard1.SuspendLayout()
        saCard2.SuspendLayout()
        saCard3.SuspendLayout()
        saCard4.SuspendLayout()
        pnlFilter.SuspendLayout()
        tpStaff.SuspendLayout()
        tlpStaff.SuspendLayout()
        cardStaffList.SuspendLayout()
        CType(gridStaff, ComponentModel.ISupportInitialize).BeginInit()
        cardStaffForm.SuspendLayout()
        pnlHeader.SuspendLayout()
        SuspendLayout()
        ' 
        ' tabs
        ' 
        tabs.Controls.Add(tpOverview)
        tabs.Controls.Add(tpMenu)
        tabs.Controls.Add(tpSales)
        tabs.Controls.Add(tpStaff)
        tabs.Dock = DockStyle.Fill
        tabs.ItemSize = New Size(150, 36)
        tabs.Location = New Point(0, 50)
        tabs.Name = "tabs"
        tabs.Padding = New Point(10, 4)
        tabs.SelectedIndex = 0
        tabs.Size = New Size(1295, 711)
        tabs.SizeMode = TabSizeMode.Fixed
        tabs.TabIndex = 0
        ' 
        ' tpOverview
        ' 
        tpOverview.BackColor = Color.FromArgb(CByte(243), CByte(247), CByte(245))
        tpOverview.Controls.Add(tlpOverview)
        tpOverview.Controls.Add(ovRow)
        tpOverview.Location = New Point(4, 40)
        tpOverview.Name = "tpOverview"
        tpOverview.Padding = New Padding(14)
        tpOverview.Size = New Size(1287, 667)
        tpOverview.TabIndex = 0
        tpOverview.Text = "Overview"
        ' 
        ' tlpOverview
        ' 
        tlpOverview.ColumnCount = 2
        tlpOverview.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 60.0F))
        tlpOverview.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 40.0F))
        tlpOverview.Controls.Add(cardRecent, 0, 0)
        tlpOverview.Controls.Add(cardCategory, 1, 0)
        tlpOverview.Dock = DockStyle.Fill
        tlpOverview.Location = New Point(14, 98)
        tlpOverview.Name = "tlpOverview"
        tlpOverview.Padding = New Padding(0, 14, 0, 0)
        tlpOverview.RowCount = 1
        tlpOverview.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
        tlpOverview.Size = New Size(1259, 555)
        tlpOverview.TabIndex = 2
        ' 
        ' cardRecent
        ' 
        cardRecent.BackColor = Color.White
        cardRecent.BorderStyle = BorderStyle.FixedSingle
        cardRecent.Controls.Add(lblRecent)
        cardRecent.Controls.Add(gridRecent)
        cardRecent.Dock = DockStyle.Fill
        cardRecent.Location = New Point(0, 14)
        cardRecent.Margin = New Padding(0, 0, 12, 0)
        cardRecent.Name = "cardRecent"
        cardRecent.Size = New Size(743, 541)
        cardRecent.TabIndex = 3
        ' 
        ' lblRecent
        ' 
        lblRecent.AutoSize = True
        lblRecent.Font = New Font("Segoe UI", 11.5F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblRecent.Location = New Point(14, 12)
        lblRecent.Name = "lblRecent"
        lblRecent.Size = New Size(129, 28)
        lblRecent.TabIndex = 4
        lblRecent.Text = "Recent sales"
        ' 
        ' gridRecent
        ' 
        gridRecent.AllowUserToAddRows = False
        gridRecent.AllowUserToDeleteRows = False
        gridRecent.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        gridRecent.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        gridRecent.BackgroundColor = Color.White
        gridRecent.BorderStyle = BorderStyle.None
        gridRecent.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        gridRecent.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle9.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle9.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle9.ForeColor = Color.White
        DataGridViewCellStyle9.SelectionBackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle9.SelectionForeColor = Color.White
        gridRecent.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        gridRecent.ColumnHeadersHeight = 34
        gridRecent.Columns.AddRange(New DataGridViewColumn() {col_gridRecent_0, col_gridRecent_1, col_gridRecent_2, col_gridRecent_3, col_gridRecent_4})
        DataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = SystemColors.Window
        DataGridViewCellStyle10.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle10.ForeColor = SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = Color.FromArgb(CByte(222), CByte(238), CByte(230))
        DataGridViewCellStyle10.SelectionForeColor = Color.Black
        DataGridViewCellStyle10.WrapMode = DataGridViewTriState.False
        gridRecent.DefaultCellStyle = DataGridViewCellStyle10
        gridRecent.EnableHeadersVisualStyles = False
        gridRecent.GridColor = Color.FromArgb(CByte(230), CByte(235), CByte(232))
        gridRecent.Location = New Point(16, 46)
        gridRecent.MultiSelect = False
        gridRecent.Name = "gridRecent"
        gridRecent.ReadOnly = True
        gridRecent.RowHeadersVisible = False
        gridRecent.RowHeadersWidth = 62
        gridRecent.RowTemplate.Height = 30
        gridRecent.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        gridRecent.Size = New Size(584, 319)
        gridRecent.TabIndex = 5
        ' 
        ' col_gridRecent_0
        ' 
        col_gridRecent_0.HeaderText = "Ticket"
        col_gridRecent_0.MinimumWidth = 8
        col_gridRecent_0.Name = "col_gridRecent_0"
        col_gridRecent_0.ReadOnly = True
        ' 
        ' col_gridRecent_1
        ' 
        col_gridRecent_1.HeaderText = "Time"
        col_gridRecent_1.MinimumWidth = 8
        col_gridRecent_1.Name = "col_gridRecent_1"
        col_gridRecent_1.ReadOnly = True
        ' 
        ' col_gridRecent_2
        ' 
        col_gridRecent_2.HeaderText = "Type"
        col_gridRecent_2.MinimumWidth = 8
        col_gridRecent_2.Name = "col_gridRecent_2"
        col_gridRecent_2.ReadOnly = True
        ' 
        ' col_gridRecent_3
        ' 
        col_gridRecent_3.HeaderText = "Method"
        col_gridRecent_3.MinimumWidth = 8
        col_gridRecent_3.Name = "col_gridRecent_3"
        col_gridRecent_3.ReadOnly = True
        ' 
        ' col_gridRecent_4
        ' 
        col_gridRecent_4.HeaderText = "Total"
        col_gridRecent_4.MinimumWidth = 8
        col_gridRecent_4.Name = "col_gridRecent_4"
        col_gridRecent_4.ReadOnly = True
        ' 
        ' cardCategory
        ' 
        cardCategory.BackColor = Color.White
        cardCategory.BorderStyle = BorderStyle.FixedSingle
        cardCategory.Controls.Add(lblCategory)
        cardCategory.Controls.Add(lblCat1)
        cardCategory.Controls.Add(pnlTrack1)
        cardCategory.Controls.Add(lblCat2)
        cardCategory.Controls.Add(pnlTrack2)
        cardCategory.Controls.Add(lblCat3)
        cardCategory.Controls.Add(pnlTrack3)
        cardCategory.Controls.Add(lblCat4)
        cardCategory.Controls.Add(pnlTrack4)
        cardCategory.Dock = DockStyle.Fill
        cardCategory.Location = New Point(758, 17)
        cardCategory.Name = "cardCategory"
        cardCategory.Size = New Size(498, 535)
        cardCategory.TabIndex = 6
        ' 
        ' lblCategory
        ' 
        lblCategory.AutoSize = True
        lblCategory.Font = New Font("Segoe UI", 11.5F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblCategory.Location = New Point(14, 12)
        lblCategory.Name = "lblCategory"
        lblCategory.Size = New Size(179, 28)
        lblCategory.TabIndex = 7
        lblCategory.Text = "Sales by category"
        ' 
        ' lblCat1
        ' 
        lblCat1.AutoSize = True
        lblCat1.Location = New Point(16, 50)
        lblCat1.Name = "lblCat1"
        lblCat1.Size = New Size(49, 23)
        lblCat1.TabIndex = 8
        lblCat1.Text = "Jollof"
        ' 
        ' pnlTrack1
        ' 
        pnlTrack1.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        pnlTrack1.BackColor = Color.FromArgb(CByte(230), CByte(238), CByte(234))
        pnlTrack1.Controls.Add(pnlFill1)
        pnlTrack1.Location = New Point(16, 76)
        pnlTrack1.Name = "pnlTrack1"
        pnlTrack1.Size = New Size(382, 20)
        pnlTrack1.TabIndex = 9
        ' 
        ' pnlFill1
        ' 
        pnlFill1.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        pnlFill1.Dock = DockStyle.Left
        pnlFill1.Location = New Point(0, 0)
        pnlFill1.Name = "pnlFill1"
        pnlFill1.Size = New Size(304, 20)
        pnlFill1.TabIndex = 10
        ' 
        ' lblCat2
        ' 
        lblCat2.AutoSize = True
        lblCat2.Location = New Point(16, 110)
        lblCat2.Name = "lblCat2"
        lblCat2.Size = New Size(57, 23)
        lblCat2.TabIndex = 11
        lblCat2.Text = "Banku"
        ' 
        ' pnlTrack2
        ' 
        pnlTrack2.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        pnlTrack2.BackColor = Color.FromArgb(CByte(230), CByte(238), CByte(234))
        pnlTrack2.Controls.Add(pnlFill2)
        pnlTrack2.Location = New Point(16, 136)
        pnlTrack2.Name = "pnlTrack2"
        pnlTrack2.Size = New Size(382, 20)
        pnlTrack2.TabIndex = 12
        ' 
        ' pnlFill2
        ' 
        pnlFill2.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        pnlFill2.Dock = DockStyle.Left
        pnlFill2.Location = New Point(0, 0)
        pnlFill2.Name = "pnlFill2"
        pnlFill2.Size = New Size(209, 20)
        pnlFill2.TabIndex = 13
        ' 
        ' lblCat3
        ' 
        lblCat3.AutoSize = True
        lblCat3.Location = New Point(16, 170)
        lblCat3.Name = "lblCat3"
        lblCat3.Size = New Size(68, 23)
        lblCat3.TabIndex = 14
        lblCat3.Text = "Waakye"
        ' 
        ' pnlTrack3
        ' 
        pnlTrack3.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        pnlTrack3.BackColor = Color.FromArgb(CByte(230), CByte(238), CByte(234))
        pnlTrack3.Controls.Add(pnlFill3)
        pnlTrack3.Location = New Point(16, 196)
        pnlTrack3.Name = "pnlTrack3"
        pnlTrack3.Size = New Size(382, 20)
        pnlTrack3.TabIndex = 15
        ' 
        ' pnlFill3
        ' 
        pnlFill3.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        pnlFill3.Dock = DockStyle.Left
        pnlFill3.Location = New Point(0, 0)
        pnlFill3.Name = "pnlFill3"
        pnlFill3.Size = New Size(182, 20)
        pnlFill3.TabIndex = 16
        ' 
        ' lblCat4
        ' 
        lblCat4.AutoSize = True
        lblCat4.Location = New Point(16, 230)
        lblCat4.Name = "lblCat4"
        lblCat4.Size = New Size(57, 23)
        lblCat4.TabIndex = 17
        lblCat4.Text = "Drinks"
        ' 
        ' pnlTrack4
        ' 
        pnlTrack4.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        pnlTrack4.BackColor = Color.FromArgb(CByte(230), CByte(238), CByte(234))
        pnlTrack4.Controls.Add(pnlFill4)
        pnlTrack4.Location = New Point(16, 256)
        pnlTrack4.Name = "pnlTrack4"
        pnlTrack4.Size = New Size(382, 20)
        pnlTrack4.TabIndex = 18
        ' 
        ' pnlFill4
        ' 
        pnlFill4.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        pnlFill4.Dock = DockStyle.Left
        pnlFill4.Location = New Point(0, 0)
        pnlFill4.Name = "pnlFill4"
        pnlFill4.Size = New Size(152, 20)
        pnlFill4.TabIndex = 19
        ' 
        ' ovRow
        ' 
        ovRow.ColumnCount = 4
        ovRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        ovRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        ovRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        ovRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        ovRow.Controls.Add(ovCard1, 0, 0)
        ovRow.Controls.Add(ovCard2, 1, 0)
        ovRow.Controls.Add(ovCard3, 2, 0)
        ovRow.Controls.Add(ovCard4, 3, 0)
        ovRow.Dock = DockStyle.Top
        ovRow.Location = New Point(14, 14)
        ovRow.Name = "ovRow"
        ovRow.RowCount = 1
        ovRow.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
        ovRow.Size = New Size(1259, 84)
        ovRow.TabIndex = 20
        ' 
        ' ovCard1
        ' 
        ovCard1.BackColor = Color.White
        ovCard1.BorderStyle = BorderStyle.FixedSingle
        ovCard1.Controls.Add(ovCap1)
        ovCard1.Controls.Add(ovVal1)
        ovCard1.Dock = DockStyle.Fill
        ovCard1.Location = New Point(0, 0)
        ovCard1.Margin = New Padding(0, 0, 6, 0)
        ovCard1.Name = "ovCard1"
        ovCard1.Size = New Size(308, 84)
        ovCard1.TabIndex = 21
        ' 
        ' ovCap1
        ' 
        ovCap1.AutoSize = True
        ovCap1.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        ovCap1.Location = New Point(12, 10)
        ovCap1.Name = "ovCap1"
        ovCap1.Size = New Size(106, 23)
        ovCap1.TabIndex = 22
        ovCap1.Text = "Today's sales"
        ' 
        ' ovVal1
        ' 
        ovVal1.AutoSize = True
        ovVal1.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ovVal1.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        ovVal1.Location = New Point(10, 30)
        ovVal1.Name = "ovVal1"
        ovVal1.Size = New Size(228, 46)
        ovVal1.TabIndex = 23
        ovVal1.Text = "GH₵1,240.00"
        ' 
        ' ovCard2
        ' 
        ovCard2.BackColor = Color.White
        ovCard2.BorderStyle = BorderStyle.FixedSingle
        ovCard2.Controls.Add(ovCap2)
        ovCard2.Controls.Add(ovVal2)
        ovCard2.Dock = DockStyle.Fill
        ovCard2.Location = New Point(320, 0)
        ovCard2.Margin = New Padding(6, 0, 6, 0)
        ovCard2.Name = "ovCard2"
        ovCard2.Size = New Size(302, 84)
        ovCard2.TabIndex = 24
        ' 
        ' ovCap2
        ' 
        ovCap2.AutoSize = True
        ovCap2.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        ovCap2.Location = New Point(12, 10)
        ovCap2.Name = "ovCap2"
        ovCap2.Size = New Size(109, 23)
        ovCap2.TabIndex = 25
        ovCap2.Text = "Orders today"
        ' 
        ' ovVal2
        ' 
        ovVal2.AutoSize = True
        ovVal2.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ovVal2.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        ovVal2.Location = New Point(10, 30)
        ovVal2.Name = "ovVal2"
        ovVal2.Size = New Size(60, 46)
        ovVal2.TabIndex = 26
        ovVal2.Text = "58"
        ' 
        ' ovCard3
        ' 
        ovCard3.BackColor = Color.White
        ovCard3.BorderStyle = BorderStyle.FixedSingle
        ovCard3.Controls.Add(ovCap3)
        ovCard3.Controls.Add(ovVal3)
        ovCard3.Dock = DockStyle.Fill
        ovCard3.Location = New Point(634, 0)
        ovCard3.Margin = New Padding(6, 0, 6, 0)
        ovCard3.Name = "ovCard3"
        ovCard3.Size = New Size(302, 84)
        ovCard3.TabIndex = 27
        ' 
        ' ovCap3
        ' 
        ovCap3.AutoSize = True
        ovCap3.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        ovCap3.Location = New Point(12, 10)
        ovCap3.Name = "ovCap3"
        ovCap3.Size = New Size(86, 23)
        ovCap3.TabIndex = 28
        ovCap3.Text = "Best seller"
        ' 
        ' ovVal3
        ' 
        ovVal3.AutoSize = True
        ovVal3.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ovVal3.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        ovVal3.Location = New Point(10, 30)
        ovVal3.Name = "ovVal3"
        ovVal3.Size = New Size(184, 46)
        ovVal3.TabIndex = 29
        ovVal3.Text = "Jollof Rice"
        ' 
        ' ovCard4
        ' 
        ovCard4.BackColor = Color.White
        ovCard4.BorderStyle = BorderStyle.FixedSingle
        ovCard4.Controls.Add(ovCap4)
        ovCard4.Controls.Add(ovVal4)
        ovCard4.Dock = DockStyle.Fill
        ovCard4.Location = New Point(948, 0)
        ovCard4.Margin = New Padding(6, 0, 0, 0)
        ovCard4.Name = "ovCard4"
        ovCard4.Size = New Size(311, 84)
        ovCard4.TabIndex = 30
        ' 
        ' ovCap4
        ' 
        ovCap4.AutoSize = True
        ovCap4.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        ovCap4.Location = New Point(12, 10)
        ovCap4.Name = "ovCap4"
        ovCap4.Size = New Size(122, 23)
        ovCap4.TabIndex = 31
        ovCap4.Text = "Sold-out items"
        ' 
        ' ovVal4
        ' 
        ovVal4.AutoSize = True
        ovVal4.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ovVal4.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        ovVal4.Location = New Point(10, 30)
        ovVal4.Name = "ovVal4"
        ovVal4.Size = New Size(40, 46)
        ovVal4.TabIndex = 32
        ovVal4.Text = "2"
        ' 
        ' tpMenu
        ' 
        tpMenu.BackColor = Color.FromArgb(CByte(243), CByte(247), CByte(245))
        tpMenu.Controls.Add(tlpMenu)
        tpMenu.Location = New Point(4, 40)
        tpMenu.Name = "tpMenu"
        tpMenu.Padding = New Padding(14)
        tpMenu.Size = New Size(1287, 667)
        tpMenu.TabIndex = 1
        tpMenu.Text = "Menu management"
        ' 
        ' tlpMenu
        ' 
        tlpMenu.ColumnCount = 2
        tlpMenu.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 60.0F))
        tlpMenu.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 40.0F))
        tlpMenu.Controls.Add(cardMenuList, 0, 0)
        tlpMenu.Controls.Add(cardMenuForm, 1, 0)
        tlpMenu.Dock = DockStyle.Fill
        tlpMenu.Location = New Point(14, 14)
        tlpMenu.Name = "tlpMenu"
        tlpMenu.RowCount = 1
        tlpMenu.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
        tlpMenu.Size = New Size(1259, 639)
        tlpMenu.TabIndex = 34
        ' 
        ' cardMenuList
        ' 
        cardMenuList.BackColor = Color.White
        cardMenuList.BorderStyle = BorderStyle.FixedSingle
        cardMenuList.Controls.Add(lblMenuList)
        cardMenuList.Controls.Add(txtSearch)
        cardMenuList.Controls.Add(gridMenu)
        cardMenuList.Dock = DockStyle.Fill
        cardMenuList.Location = New Point(0, 0)
        cardMenuList.Margin = New Padding(0, 0, 12, 0)
        cardMenuList.Name = "cardMenuList"
        cardMenuList.Size = New Size(743, 639)
        cardMenuList.TabIndex = 35
        ' 
        ' lblMenuList
        ' 
        lblMenuList.AutoSize = True
        lblMenuList.Font = New Font("Segoe UI", 11.5F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMenuList.Location = New Point(14, 12)
        lblMenuList.Name = "lblMenuList"
        lblMenuList.Size = New Size(155, 28)
        lblMenuList.TabIndex = 36
        lblMenuList.Text = "All menu items"
        ' 
        ' txtSearch
        ' 
        txtSearch.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtSearch.Location = New Point(16, 46)
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(280, 30)
        txtSearch.TabIndex = 37
        ' 
        ' gridMenu
        ' 
        gridMenu.AllowUserToAddRows = False
        gridMenu.AllowUserToDeleteRows = False
        gridMenu.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        gridMenu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        gridMenu.BackgroundColor = Color.White
        gridMenu.BorderStyle = BorderStyle.None
        gridMenu.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        gridMenu.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle11.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle11.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle11.ForeColor = Color.White
        DataGridViewCellStyle11.SelectionBackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle11.SelectionForeColor = Color.White
        gridMenu.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        gridMenu.ColumnHeadersHeight = 34
        gridMenu.Columns.AddRange(New DataGridViewColumn() {col_gridMenu_0, col_gridMenu_1, col_gridMenu_2, col_gridMenu_3})
        DataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = SystemColors.Window
        DataGridViewCellStyle12.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle12.ForeColor = SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = Color.FromArgb(CByte(222), CByte(238), CByte(230))
        DataGridViewCellStyle12.SelectionForeColor = Color.Black
        DataGridViewCellStyle12.WrapMode = DataGridViewTriState.False
        gridMenu.DefaultCellStyle = DataGridViewCellStyle12
        gridMenu.EnableHeadersVisualStyles = False
        gridMenu.GridColor = Color.FromArgb(CByte(230), CByte(235), CByte(232))
        gridMenu.Location = New Point(16, 86)
        gridMenu.MultiSelect = False
        gridMenu.Name = "gridMenu"
        gridMenu.ReadOnly = True
        gridMenu.RowHeadersVisible = False
        gridMenu.RowHeadersWidth = 62
        gridMenu.RowTemplate.Height = 30
        gridMenu.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        gridMenu.Size = New Size(584, 377)
        gridMenu.TabIndex = 38
        ' 
        ' col_gridMenu_0
        ' 
        col_gridMenu_0.HeaderText = "Name"
        col_gridMenu_0.MinimumWidth = 8
        col_gridMenu_0.Name = "col_gridMenu_0"
        col_gridMenu_0.ReadOnly = True
        ' 
        ' col_gridMenu_1
        ' 
        col_gridMenu_1.HeaderText = "Category"
        col_gridMenu_1.MinimumWidth = 8
        col_gridMenu_1.Name = "col_gridMenu_1"
        col_gridMenu_1.ReadOnly = True
        ' 
        ' col_gridMenu_2
        ' 
        col_gridMenu_2.HeaderText = "Price"
        col_gridMenu_2.MinimumWidth = 8
        col_gridMenu_2.Name = "col_gridMenu_2"
        col_gridMenu_2.ReadOnly = True
        ' 
        ' col_gridMenu_3
        ' 
        col_gridMenu_3.HeaderText = "Status"
        col_gridMenu_3.MinimumWidth = 8
        col_gridMenu_3.Name = "col_gridMenu_3"
        col_gridMenu_3.ReadOnly = True
        ' 
        ' cardMenuForm
        ' 
        cardMenuForm.BackColor = Color.White
        cardMenuForm.BorderStyle = BorderStyle.FixedSingle
        cardMenuForm.Controls.Add(lblMenuForm)
        cardMenuForm.Controls.Add(lblItemName)
        cardMenuForm.Controls.Add(txtItemName)
        cardMenuForm.Controls.Add(lblCategoryCap)
        cardMenuForm.Controls.Add(cboCategory)
        cardMenuForm.Controls.Add(lblPriceCap)
        cardMenuForm.Controls.Add(txtPrice)
        cardMenuForm.Controls.Add(btnSaveItem)
        cardMenuForm.Controls.Add(btnSoldOut)
        cardMenuForm.Controls.Add(btnDeleteItem)
        cardMenuForm.Dock = DockStyle.Fill
        cardMenuForm.Location = New Point(758, 3)
        cardMenuForm.Name = "cardMenuForm"
        cardMenuForm.Size = New Size(498, 633)
        cardMenuForm.TabIndex = 39
        ' 
        ' lblMenuForm
        ' 
        lblMenuForm.AutoSize = True
        lblMenuForm.Font = New Font("Segoe UI", 11.5F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMenuForm.Location = New Point(14, 12)
        lblMenuForm.Name = "lblMenuForm"
        lblMenuForm.Size = New Size(168, 28)
        lblMenuForm.TabIndex = 40
        lblMenuForm.Text = "Add or edit item"
        ' 
        ' lblItemName
        ' 
        lblItemName.AutoSize = True
        lblItemName.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblItemName.Location = New Point(16, 50)
        lblItemName.Name = "lblItemName"
        lblItemName.Size = New Size(93, 23)
        lblItemName.TabIndex = 41
        lblItemName.Text = "Item name"
        ' 
        ' txtItemName
        ' 
        txtItemName.Font = New Font("Segoe UI", 11.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtItemName.Location = New Point(16, 72)
        txtItemName.Name = "txtItemName"
        txtItemName.Size = New Size(340, 32)
        txtItemName.TabIndex = 42
        ' 
        ' lblCategoryCap
        ' 
        lblCategoryCap.AutoSize = True
        lblCategoryCap.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblCategoryCap.Location = New Point(16, 120)
        lblCategoryCap.Name = "lblCategoryCap"
        lblCategoryCap.Size = New Size(79, 23)
        lblCategoryCap.TabIndex = 43
        lblCategoryCap.Text = "Category"
        ' 
        ' cboCategory
        ' 
        cboCategory.DropDownStyle = ComboBoxStyle.DropDownList
        cboCategory.Font = New Font("Segoe UI", 11.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cboCategory.FormattingEnabled = True
        cboCategory.Items.AddRange(New Object() {"Waakye", "Fufu", "Banku", "Jollof", "Drinks", "Others"})
        cboCategory.Location = New Point(16, 148)
        cboCategory.Name = "cboCategory"
        cboCategory.Size = New Size(340, 33)
        cboCategory.TabIndex = 44
        ' 
        ' lblPriceCap
        ' 
        lblPriceCap.AutoSize = True
        lblPriceCap.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblPriceCap.Location = New Point(16, 204)
        lblPriceCap.Name = "lblPriceCap"
        lblPriceCap.Size = New Size(95, 23)
        lblPriceCap.TabIndex = 45
        lblPriceCap.Text = "Price (GH₵)"
        ' 
        ' txtPrice
        ' 
        txtPrice.Font = New Font("Segoe UI", 11.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPrice.Location = New Point(16, 226)
        txtPrice.Name = "txtPrice"
        txtPrice.Size = New Size(200, 32)
        txtPrice.TabIndex = 46
        txtPrice.Text = "0.00"
        ' 
        ' btnSaveItem
        ' 
        btnSaveItem.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        btnSaveItem.Cursor = Cursors.Hand
        btnSaveItem.FlatAppearance.BorderSize = 0
        btnSaveItem.FlatStyle = FlatStyle.Flat
        btnSaveItem.ForeColor = Color.White
        btnSaveItem.Location = New Point(16, 282)
        btnSaveItem.Name = "btnSaveItem"
        btnSaveItem.Size = New Size(110, 36)
        btnSaveItem.TabIndex = 47
        btnSaveItem.Text = "Save item"
        btnSaveItem.UseVisualStyleBackColor = False
        ' 
        ' btnSoldOut
        ' 
        btnSoldOut.BackColor = Color.FromArgb(CByte(245), CByte(183), CByte(0))
        btnSoldOut.Cursor = Cursors.Hand
        btnSoldOut.FlatAppearance.BorderSize = 0
        btnSoldOut.FlatStyle = FlatStyle.Flat
        btnSoldOut.ForeColor = Color.Black
        btnSoldOut.Location = New Point(134, 282)
        btnSoldOut.Name = "btnSoldOut"
        btnSoldOut.Size = New Size(130, 36)
        btnSoldOut.TabIndex = 48
        btnSoldOut.Text = "Mark sold out"
        btnSoldOut.UseVisualStyleBackColor = False
        ' 
        ' btnDeleteItem
        ' 
        btnDeleteItem.BackColor = Color.FromArgb(CByte(192), CByte(57), CByte(43))
        btnDeleteItem.Cursor = Cursors.Hand
        btnDeleteItem.FlatAppearance.BorderSize = 0
        btnDeleteItem.FlatStyle = FlatStyle.Flat
        btnDeleteItem.ForeColor = Color.White
        btnDeleteItem.Location = New Point(272, 282)
        btnDeleteItem.Name = "btnDeleteItem"
        btnDeleteItem.Size = New Size(90, 36)
        btnDeleteItem.TabIndex = 49
        btnDeleteItem.Text = "Delete"
        btnDeleteItem.UseVisualStyleBackColor = False
        ' 
        ' tpSales
        ' 
        tpSales.BackColor = Color.FromArgb(CByte(243), CByte(247), CByte(245))
        tpSales.Controls.Add(cardHistory)
        tpSales.Controls.Add(saRow)
        tpSales.Controls.Add(pnlFilter)
        tpSales.Location = New Point(4, 40)
        tpSales.Name = "tpSales"
        tpSales.Padding = New Padding(14)
        tpSales.Size = New Size(1287, 667)
        tpSales.TabIndex = 2
        tpSales.Text = "Sales reports"
        ' 
        ' cardHistory
        ' 
        cardHistory.BackColor = Color.White
        cardHistory.BorderStyle = BorderStyle.FixedSingle
        cardHistory.Controls.Add(lblHistory)
        cardHistory.Controls.Add(gridSales)
        cardHistory.Dock = DockStyle.Fill
        cardHistory.Location = New Point(14, 180)
        cardHistory.Margin = New Padding(0, 12, 0, 0)
        cardHistory.Name = "cardHistory"
        cardHistory.Size = New Size(1259, 473)
        cardHistory.TabIndex = 51
        ' 
        ' lblHistory
        ' 
        lblHistory.AutoSize = True
        lblHistory.Font = New Font("Segoe UI", 11.5F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblHistory.Location = New Point(14, 12)
        lblHistory.Name = "lblHistory"
        lblHistory.Size = New Size(133, 28)
        lblHistory.TabIndex = 52
        lblHistory.Text = "Sales history"
        ' 
        ' gridSales
        ' 
        gridSales.AllowUserToAddRows = False
        gridSales.AllowUserToDeleteRows = False
        gridSales.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        gridSales.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        gridSales.BackgroundColor = Color.White
        gridSales.BorderStyle = BorderStyle.None
        gridSales.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        gridSales.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle13.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle13.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle13.ForeColor = Color.White
        DataGridViewCellStyle13.SelectionBackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle13.SelectionForeColor = Color.White
        gridSales.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        gridSales.ColumnHeadersHeight = 34
        gridSales.Columns.AddRange(New DataGridViewColumn() {col_gridSales_0, col_gridSales_1, col_gridSales_2, col_gridSales_3, col_gridSales_4, col_gridSales_5, col_gridSales_6, col_gridSales_7})
        DataGridViewCellStyle14.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = SystemColors.Window
        DataGridViewCellStyle14.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle14.ForeColor = SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = Color.FromArgb(CByte(222), CByte(238), CByte(230))
        DataGridViewCellStyle14.SelectionForeColor = Color.Black
        DataGridViewCellStyle14.WrapMode = DataGridViewTriState.False
        gridSales.DefaultCellStyle = DataGridViewCellStyle14
        gridSales.EnableHeadersVisualStyles = False
        gridSales.GridColor = Color.FromArgb(CByte(230), CByte(235), CByte(232))
        gridSales.Location = New Point(16, 46)
        gridSales.MultiSelect = False
        gridSales.Name = "gridSales"
        gridSales.ReadOnly = True
        gridSales.RowHeadersVisible = False
        gridSales.RowHeadersWidth = 62
        gridSales.RowTemplate.Height = 30
        gridSales.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        gridSales.Size = New Size(1016, 251)
        gridSales.TabIndex = 53
        ' 
        ' col_gridSales_0
        ' 
        col_gridSales_0.HeaderText = "Ticket"
        col_gridSales_0.MinimumWidth = 8
        col_gridSales_0.Name = "col_gridSales_0"
        col_gridSales_0.ReadOnly = True
        ' 
        ' col_gridSales_1
        ' 
        col_gridSales_1.HeaderText = "Date and time"
        col_gridSales_1.MinimumWidth = 8
        col_gridSales_1.Name = "col_gridSales_1"
        col_gridSales_1.ReadOnly = True
        ' 
        ' col_gridSales_2
        ' 
        col_gridSales_2.HeaderText = "Cashier"
        col_gridSales_2.MinimumWidth = 8
        col_gridSales_2.Name = "col_gridSales_2"
        col_gridSales_2.ReadOnly = True
        ' 
        ' col_gridSales_3
        ' 
        col_gridSales_3.HeaderText = "Customer"
        col_gridSales_3.MinimumWidth = 8
        col_gridSales_3.Name = "col_gridSales_3"
        col_gridSales_3.ReadOnly = True
        ' 
        ' col_gridSales_4
        ' 
        col_gridSales_4.HeaderText = "Type"
        col_gridSales_4.MinimumWidth = 8
        col_gridSales_4.Name = "col_gridSales_4"
        col_gridSales_4.ReadOnly = True
        ' 
        ' col_gridSales_5
        ' 
        col_gridSales_5.HeaderText = "Items"
        col_gridSales_5.MinimumWidth = 8
        col_gridSales_5.Name = "col_gridSales_5"
        col_gridSales_5.ReadOnly = True
        ' 
        ' col_gridSales_6
        ' 
        col_gridSales_6.HeaderText = "Method"
        col_gridSales_6.MinimumWidth = 8
        col_gridSales_6.Name = "col_gridSales_6"
        col_gridSales_6.ReadOnly = True
        ' 
        ' col_gridSales_7
        ' 
        col_gridSales_7.HeaderText = "Total"
        col_gridSales_7.MinimumWidth = 8
        col_gridSales_7.Name = "col_gridSales_7"
        col_gridSales_7.ReadOnly = True
        ' 
        ' saRow
        ' 
        saRow.ColumnCount = 4
        saRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        saRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        saRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        saRow.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 25.0F))
        saRow.Controls.Add(saCard1, 0, 0)
        saRow.Controls.Add(saCard2, 1, 0)
        saRow.Controls.Add(saCard3, 2, 0)
        saRow.Controls.Add(saCard4, 3, 0)
        saRow.Dock = DockStyle.Top
        saRow.Location = New Point(14, 84)
        saRow.Name = "saRow"
        saRow.Padding = New Padding(0, 12, 0, 0)
        saRow.RowCount = 1
        saRow.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
        saRow.Size = New Size(1259, 96)
        saRow.TabIndex = 54
        ' 
        ' saCard1
        ' 
        saCard1.BackColor = Color.White
        saCard1.BorderStyle = BorderStyle.FixedSingle
        saCard1.Controls.Add(saCap1)
        saCard1.Controls.Add(saVal1)
        saCard1.Dock = DockStyle.Fill
        saCard1.Location = New Point(0, 12)
        saCard1.Margin = New Padding(0, 0, 6, 0)
        saCard1.Name = "saCard1"
        saCard1.Size = New Size(308, 84)
        saCard1.TabIndex = 55
        ' 
        ' saCap1
        ' 
        saCap1.AutoSize = True
        saCap1.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        saCap1.Location = New Point(12, 10)
        saCap1.Name = "saCap1"
        saCap1.Size = New Size(87, 23)
        saCap1.TabIndex = 56
        saCap1.Text = "Total sales"
        ' 
        ' saVal1
        ' 
        saVal1.AutoSize = True
        saVal1.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        saVal1.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        saVal1.Location = New Point(10, 30)
        saVal1.Name = "saVal1"
        saVal1.Size = New Size(228, 46)
        saVal1.TabIndex = 57
        saVal1.Text = "GH₵1,240.00"
        ' 
        ' saCard2
        ' 
        saCard2.BackColor = Color.White
        saCard2.BorderStyle = BorderStyle.FixedSingle
        saCard2.Controls.Add(saCap2)
        saCard2.Controls.Add(saVal2)
        saCard2.Dock = DockStyle.Fill
        saCard2.Location = New Point(320, 12)
        saCard2.Margin = New Padding(6, 0, 6, 0)
        saCard2.Name = "saCard2"
        saCard2.Size = New Size(302, 84)
        saCard2.TabIndex = 58
        ' 
        ' saCap2
        ' 
        saCap2.AutoSize = True
        saCap2.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        saCap2.Location = New Point(12, 10)
        saCap2.Name = "saCap2"
        saCap2.Size = New Size(47, 23)
        saCap2.TabIndex = 59
        saCap2.Text = "Cash"
        ' 
        ' saVal2
        ' 
        saVal2.AutoSize = True
        saVal2.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        saVal2.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        saVal2.Location = New Point(10, 30)
        saVal2.Name = "saVal2"
        saVal2.Size = New Size(199, 46)
        saVal2.TabIndex = 60
        saVal2.Text = "GH₵760.00"
        ' 
        ' saCard3
        ' 
        saCard3.BackColor = Color.White
        saCard3.BorderStyle = BorderStyle.FixedSingle
        saCard3.Controls.Add(saCap3)
        saCard3.Controls.Add(saVal3)
        saCard3.Dock = DockStyle.Fill
        saCard3.Location = New Point(634, 12)
        saCard3.Margin = New Padding(6, 0, 6, 0)
        saCard3.Name = "saCard3"
        saCard3.Size = New Size(302, 84)
        saCard3.TabIndex = 61
        ' 
        ' saCap3
        ' 
        saCap3.AutoSize = True
        saCap3.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        saCap3.Location = New Point(12, 10)
        saCap3.Name = "saCap3"
        saCap3.Size = New Size(119, 23)
        saCap3.TabIndex = 62
        saCap3.Text = "Mobile money"
        ' 
        ' saVal3
        ' 
        saVal3.AutoSize = True
        saVal3.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        saVal3.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        saVal3.Location = New Point(10, 30)
        saVal3.Name = "saVal3"
        saVal3.Size = New Size(199, 46)
        saVal3.TabIndex = 63
        saVal3.Text = "GH₵480.00"
        ' 
        ' saCard4
        ' 
        saCard4.BackColor = Color.White
        saCard4.BorderStyle = BorderStyle.FixedSingle
        saCard4.Controls.Add(saCap4)
        saCard4.Controls.Add(saVal4)
        saCard4.Dock = DockStyle.Fill
        saCard4.Location = New Point(948, 12)
        saCard4.Margin = New Padding(6, 0, 0, 0)
        saCard4.Name = "saCard4"
        saCard4.Size = New Size(311, 84)
        saCard4.TabIndex = 64
        ' 
        ' saCap4
        ' 
        saCap4.AutoSize = True
        saCap4.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        saCap4.Location = New Point(12, 10)
        saCap4.Name = "saCap4"
        saCap4.Size = New Size(160, 23)
        saCap4.TabIndex = 65
        saCap4.Text = "Dine In / Take Away"
        ' 
        ' saVal4
        ' 
        saVal4.AutoSize = True
        saVal4.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        saVal4.ForeColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        saVal4.Location = New Point(10, 30)
        saVal4.Name = "saVal4"
        saVal4.Size = New Size(133, 46)
        saVal4.TabIndex = 66
        saVal4.Text = "34 / 24"
        ' 
        ' pnlFilter
        ' 
        pnlFilter.BackColor = Color.White
        pnlFilter.BorderStyle = BorderStyle.FixedSingle
        pnlFilter.Controls.Add(lblFrom)
        pnlFilter.Controls.Add(dtpFrom)
        pnlFilter.Controls.Add(lblTo)
        pnlFilter.Controls.Add(dtpTo)
        pnlFilter.Controls.Add(lblCashierCap)
        pnlFilter.Controls.Add(cboCashier)
        pnlFilter.Controls.Add(btnFilter)
        pnlFilter.Controls.Add(btnDaily)
        pnlFilter.Controls.Add(btnExport)
        pnlFilter.Dock = DockStyle.Top
        pnlFilter.Location = New Point(14, 14)
        pnlFilter.Name = "pnlFilter"
        pnlFilter.Size = New Size(1259, 70)
        pnlFilter.TabIndex = 67
        ' 
        ' lblFrom
        ' 
        lblFrom.AutoSize = True
        lblFrom.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblFrom.Location = New Point(14, 24)
        lblFrom.Name = "lblFrom"
        lblFrom.Size = New Size(49, 23)
        lblFrom.TabIndex = 68
        lblFrom.Text = "From"
        ' 
        ' dtpFrom
        ' 
        dtpFrom.CustomFormat = "dd/MM/yyyy"
        dtpFrom.Format = DateTimePickerFormat.Custom
        dtpFrom.Location = New Point(58, 20)
        dtpFrom.Name = "dtpFrom"
        dtpFrom.Size = New Size(130, 30)
        dtpFrom.TabIndex = 69
        ' 
        ' lblTo
        ' 
        lblTo.AutoSize = True
        lblTo.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblTo.Location = New Point(210, 24)
        lblTo.Name = "lblTo"
        lblTo.Size = New Size(27, 23)
        lblTo.TabIndex = 70
        lblTo.Text = "To"
        ' 
        ' dtpTo
        ' 
        dtpTo.CustomFormat = "dd/MM/yyyy"
        dtpTo.Format = DateTimePickerFormat.Custom
        dtpTo.Location = New Point(240, 20)
        dtpTo.Name = "dtpTo"
        dtpTo.Size = New Size(130, 30)
        dtpTo.TabIndex = 71
        ' 
        ' lblCashierCap
        ' 
        lblCashierCap.AutoSize = True
        lblCashierCap.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblCashierCap.Location = New Point(385, 24)
        lblCashierCap.Name = "lblCashierCap"
        lblCashierCap.Size = New Size(66, 23)
        lblCashierCap.TabIndex = 72
        lblCashierCap.Text = "Cashier"
        ' 
        ' cboCashier
        ' 
        cboCashier.DropDownStyle = ComboBoxStyle.DropDownList
        cboCashier.Font = New Font("Segoe UI", 11.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cboCashier.FormattingEnabled = True
        cboCashier.Items.AddRange(New Object() {"All", "cashier", "akosua"})
        cboCashier.Location = New Point(454, 20)
        cboCashier.Name = "cboCashier"
        cboCashier.Size = New Size(140, 33)
        cboCashier.TabIndex = 73
        ' 
        ' btnFilter
        ' 
        btnFilter.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        btnFilter.Cursor = Cursors.Hand
        btnFilter.FlatAppearance.BorderSize = 0
        btnFilter.FlatStyle = FlatStyle.Flat
        btnFilter.ForeColor = Color.White
        btnFilter.Location = New Point(610, 17)
        btnFilter.Name = "btnFilter"
        btnFilter.Size = New Size(80, 36)
        btnFilter.TabIndex = 74
        btnFilter.Text = "Filter"
        btnFilter.UseVisualStyleBackColor = False
        ' 
        ' btnDaily
        ' 
        btnDaily.BackColor = Color.FromArgb(CByte(245), CByte(183), CByte(0))
        btnDaily.Cursor = Cursors.Hand
        btnDaily.FlatAppearance.BorderSize = 0
        btnDaily.FlatStyle = FlatStyle.Flat
        btnDaily.ForeColor = Color.Black
        btnDaily.Location = New Point(700, 17)
        btnDaily.Name = "btnDaily"
        btnDaily.Size = New Size(120, 36)
        btnDaily.TabIndex = 75
        btnDaily.Text = "Daily report"
        btnDaily.UseVisualStyleBackColor = False
        ' 
        ' btnExport
        ' 
        btnExport.BackColor = Color.FromArgb(CByte(235), CByte(235), CByte(235))
        btnExport.Cursor = Cursors.Hand
        btnExport.FlatAppearance.BorderColor = Color.Gray
        btnExport.FlatStyle = FlatStyle.Flat
        btnExport.ForeColor = Color.Black
        btnExport.Location = New Point(830, 17)
        btnExport.Name = "btnExport"
        btnExport.Size = New Size(110, 36)
        btnExport.TabIndex = 76
        btnExport.Text = "Export CSV"
        btnExport.UseVisualStyleBackColor = False
        ' 
        ' tpStaff
        ' 
        tpStaff.BackColor = Color.FromArgb(CByte(243), CByte(247), CByte(245))
        tpStaff.Controls.Add(tlpStaff)
        tpStaff.Location = New Point(4, 40)
        tpStaff.Name = "tpStaff"
        tpStaff.Padding = New Padding(14)
        tpStaff.Size = New Size(1287, 667)
        tpStaff.TabIndex = 3
        tpStaff.Text = "Staff accounts"
        ' 
        ' tlpStaff
        ' 
        tlpStaff.ColumnCount = 2
        tlpStaff.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 60.0F))
        tlpStaff.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 40.0F))
        tlpStaff.Controls.Add(cardStaffList, 0, 0)
        tlpStaff.Controls.Add(cardStaffForm, 1, 0)
        tlpStaff.Dock = DockStyle.Fill
        tlpStaff.Location = New Point(14, 14)
        tlpStaff.Name = "tlpStaff"
        tlpStaff.RowCount = 1
        tlpStaff.RowStyles.Add(New RowStyle(SizeType.Percent, 100.0F))
        tlpStaff.Size = New Size(1259, 639)
        tlpStaff.TabIndex = 78
        ' 
        ' cardStaffList
        ' 
        cardStaffList.BackColor = Color.White
        cardStaffList.BorderStyle = BorderStyle.FixedSingle
        cardStaffList.Controls.Add(lblStaffList)
        cardStaffList.Controls.Add(gridStaff)
        cardStaffList.Dock = DockStyle.Fill
        cardStaffList.Location = New Point(0, 0)
        cardStaffList.Margin = New Padding(0, 0, 12, 0)
        cardStaffList.Name = "cardStaffList"
        cardStaffList.Size = New Size(743, 639)
        cardStaffList.TabIndex = 79
        ' 
        ' lblStaffList
        ' 
        lblStaffList.AutoSize = True
        lblStaffList.Font = New Font("Segoe UI", 11.5F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblStaffList.Location = New Point(14, 12)
        lblStaffList.Name = "lblStaffList"
        lblStaffList.Size = New Size(148, 28)
        lblStaffList.TabIndex = 80
        lblStaffList.Text = "Staff accounts"
        ' 
        ' gridStaff
        ' 
        gridStaff.AllowUserToAddRows = False
        gridStaff.AllowUserToDeleteRows = False
        gridStaff.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        gridStaff.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        gridStaff.BackgroundColor = Color.White
        gridStaff.BorderStyle = BorderStyle.None
        gridStaff.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        gridStaff.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle15.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle15.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle15.ForeColor = Color.White
        DataGridViewCellStyle15.SelectionBackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        DataGridViewCellStyle15.SelectionForeColor = Color.White
        gridStaff.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle15
        gridStaff.ColumnHeadersHeight = 34
        gridStaff.Columns.AddRange(New DataGridViewColumn() {col_gridStaff_0, col_gridStaff_1, col_gridStaff_2, col_gridStaff_3})
        DataGridViewCellStyle16.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = SystemColors.Window
        DataGridViewCellStyle16.Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle16.ForeColor = SystemColors.ControlText
        DataGridViewCellStyle16.SelectionBackColor = Color.FromArgb(CByte(222), CByte(238), CByte(230))
        DataGridViewCellStyle16.SelectionForeColor = Color.Black
        DataGridViewCellStyle16.WrapMode = DataGridViewTriState.False
        gridStaff.DefaultCellStyle = DataGridViewCellStyle16
        gridStaff.EnableHeadersVisualStyles = False
        gridStaff.GridColor = Color.FromArgb(CByte(230), CByte(235), CByte(232))
        gridStaff.Location = New Point(16, 46)
        gridStaff.MultiSelect = False
        gridStaff.Name = "gridStaff"
        gridStaff.ReadOnly = True
        gridStaff.RowHeadersVisible = False
        gridStaff.RowHeadersWidth = 62
        gridStaff.RowTemplate.Height = 30
        gridStaff.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        gridStaff.Size = New Size(584, 417)
        gridStaff.TabIndex = 81
        ' 
        ' col_gridStaff_0
        ' 
        col_gridStaff_0.HeaderText = "Username"
        col_gridStaff_0.MinimumWidth = 8
        col_gridStaff_0.Name = "col_gridStaff_0"
        col_gridStaff_0.ReadOnly = True
        ' 
        ' col_gridStaff_1
        ' 
        col_gridStaff_1.HeaderText = "Role"
        col_gridStaff_1.MinimumWidth = 8
        col_gridStaff_1.Name = "col_gridStaff_1"
        col_gridStaff_1.ReadOnly = True
        ' 
        ' col_gridStaff_2
        ' 
        col_gridStaff_2.HeaderText = "Status"
        col_gridStaff_2.MinimumWidth = 8
        col_gridStaff_2.Name = "col_gridStaff_2"
        col_gridStaff_2.ReadOnly = True
        ' 
        ' col_gridStaff_3
        ' 
        col_gridStaff_3.HeaderText = "Last login"
        col_gridStaff_3.MinimumWidth = 8
        col_gridStaff_3.Name = "col_gridStaff_3"
        col_gridStaff_3.ReadOnly = True
        ' 
        ' cardStaffForm
        ' 
        cardStaffForm.BackColor = Color.White
        cardStaffForm.BorderStyle = BorderStyle.FixedSingle
        cardStaffForm.Controls.Add(lblStaffForm)
        cardStaffForm.Controls.Add(lblUsernameCap)
        cardStaffForm.Controls.Add(txtUsername)
        cardStaffForm.Controls.Add(lblPasswordCap)
        cardStaffForm.Controls.Add(txtPassword)
        cardStaffForm.Controls.Add(lblRoleCap)
        cardStaffForm.Controls.Add(cboRole)
        cardStaffForm.Controls.Add(btnSaveAccount)
        cardStaffForm.Controls.Add(btnResetPwd)
        cardStaffForm.Controls.Add(btnDisable)
        cardStaffForm.Dock = DockStyle.Fill
        cardStaffForm.Location = New Point(758, 3)
        cardStaffForm.Name = "cardStaffForm"
        cardStaffForm.Size = New Size(498, 633)
        cardStaffForm.TabIndex = 82
        ' 
        ' lblStaffForm
        ' 
        lblStaffForm.AutoSize = True
        lblStaffForm.Font = New Font("Segoe UI", 11.5F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblStaffForm.Location = New Point(14, 12)
        lblStaffForm.Name = "lblStaffForm"
        lblStaffForm.Size = New Size(200, 28)
        lblStaffForm.TabIndex = 83
        lblStaffForm.Text = "Add or edit account"
        ' 
        ' lblUsernameCap
        ' 
        lblUsernameCap.AutoSize = True
        lblUsernameCap.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblUsernameCap.Location = New Point(16, 50)
        lblUsernameCap.Name = "lblUsernameCap"
        lblUsernameCap.Size = New Size(87, 23)
        lblUsernameCap.TabIndex = 84
        lblUsernameCap.Text = "Username"
        ' 
        ' txtUsername
        ' 
        txtUsername.Font = New Font("Segoe UI", 11.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtUsername.Location = New Point(16, 72)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(340, 32)
        txtUsername.TabIndex = 85
        ' 
        ' lblPasswordCap
        ' 
        lblPasswordCap.AutoSize = True
        lblPasswordCap.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblPasswordCap.Location = New Point(16, 126)
        lblPasswordCap.Name = "lblPasswordCap"
        lblPasswordCap.Size = New Size(80, 23)
        lblPasswordCap.TabIndex = 86
        lblPasswordCap.Text = "Password"
        ' 
        ' txtPassword
        ' 
        txtPassword.Font = New Font("Segoe UI", 11.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPassword.Location = New Point(16, 148)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(340, 32)
        txtPassword.TabIndex = 87
        txtPassword.Text = "123456"
        txtPassword.UseSystemPasswordChar = True
        ' 
        ' lblRoleCap
        ' 
        lblRoleCap.AutoSize = True
        lblRoleCap.ForeColor = Color.FromArgb(CByte(85), CByte(95), CByte(90))
        lblRoleCap.Location = New Point(16, 202)
        lblRoleCap.Name = "lblRoleCap"
        lblRoleCap.Size = New Size(43, 23)
        lblRoleCap.TabIndex = 88
        lblRoleCap.Text = "Role"
        ' 
        ' cboRole
        ' 
        cboRole.DropDownStyle = ComboBoxStyle.DropDownList
        cboRole.Font = New Font("Segoe UI", 11.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cboRole.FormattingEnabled = True
        cboRole.Items.AddRange(New Object() {"Admin", "Cashier"})
        cboRole.Location = New Point(16, 224)
        cboRole.Name = "cboRole"
        cboRole.Size = New Size(340, 33)
        cboRole.TabIndex = 89
        ' 
        ' btnSaveAccount
        ' 
        btnSaveAccount.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        btnSaveAccount.Cursor = Cursors.Hand
        btnSaveAccount.FlatAppearance.BorderSize = 0
        btnSaveAccount.FlatStyle = FlatStyle.Flat
        btnSaveAccount.ForeColor = Color.White
        btnSaveAccount.Location = New Point(16, 282)
        btnSaveAccount.Name = "btnSaveAccount"
        btnSaveAccount.Size = New Size(120, 36)
        btnSaveAccount.TabIndex = 90
        btnSaveAccount.Text = "Save account"
        btnSaveAccount.UseVisualStyleBackColor = False
        ' 
        ' btnResetPwd
        ' 
        btnResetPwd.BackColor = Color.FromArgb(CByte(245), CByte(183), CByte(0))
        btnResetPwd.Cursor = Cursors.Hand
        btnResetPwd.FlatAppearance.BorderSize = 0
        btnResetPwd.FlatStyle = FlatStyle.Flat
        btnResetPwd.ForeColor = Color.Black
        btnResetPwd.Location = New Point(144, 282)
        btnResetPwd.Name = "btnResetPwd"
        btnResetPwd.Size = New Size(140, 36)
        btnResetPwd.TabIndex = 91
        btnResetPwd.Text = "Reset password"
        btnResetPwd.UseVisualStyleBackColor = False
        ' 
        ' btnDisable
        ' 
        btnDisable.BackColor = Color.FromArgb(CByte(192), CByte(57), CByte(43))
        btnDisable.Cursor = Cursors.Hand
        btnDisable.FlatAppearance.BorderSize = 0
        btnDisable.FlatStyle = FlatStyle.Flat
        btnDisable.ForeColor = Color.White
        btnDisable.Location = New Point(292, 282)
        btnDisable.Name = "btnDisable"
        btnDisable.Size = New Size(90, 36)
        btnDisable.TabIndex = 92
        btnDisable.Text = "Disable"
        btnDisable.UseVisualStyleBackColor = False
        ' 
        ' pnlHeader
        ' 
        pnlHeader.BackColor = Color.FromArgb(CByte(15), CByte(92), CByte(61))
        pnlHeader.Controls.Add(btnLogout)
        pnlHeader.Controls.Add(lblTitle)
        pnlHeader.Controls.Add(lblHeaderRight)
        pnlHeader.Dock = DockStyle.Top
        pnlHeader.Location = New Point(0, 0)
        pnlHeader.Name = "pnlHeader"
        pnlHeader.Size = New Size(1295, 50)
        pnlHeader.TabIndex = 93
        ' 
        ' btnLogout
        ' 
        btnLogout.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        btnLogout.BackColor = Color.FromArgb(CByte(245), CByte(183), CByte(0))
        btnLogout.Cursor = Cursors.Hand
        btnLogout.FlatAppearance.BorderSize = 0
        btnLogout.Font = New Font("Segoe UI", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnLogout.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        btnLogout.Location = New Point(956, 9)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(110, 32)
        btnLogout.TabIndex = 96
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 15.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.ForeColor = Color.White
        lblTitle.Location = New Point(18, 10)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(285, 35)
        lblTitle.TabIndex = 94
        lblTitle.Text = "ChopBar POS  |  Admin"
        ' 
        ' lblHeaderRight
        ' 
        lblHeaderRight.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        lblHeaderRight.AutoSize = True
        lblHeaderRight.ForeColor = Color.White
        lblHeaderRight.Location = New Point(654, 15)
        lblHeaderRight.Name = "lblHeaderRight"
        lblHeaderRight.Size = New Size(253, 23)
        lblHeaderRight.TabIndex = 95
        lblHeaderRight.Text = "Mon, 02 Nov 2026   |   Admin ▾"
        ' 
        ' AdminForm
        ' 
        AutoScaleDimensions = New SizeF(120.0F, 120.0F)
        AutoScaleMode = AutoScaleMode.Dpi
        BackColor = Color.FromArgb(CByte(243), CByte(247), CByte(245))
        ClientSize = New Size(1295, 761)
        Controls.Add(tabs)
        Controls.Add(pnlHeader)
        Font = New Font("Segoe UI", 10.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        MinimumSize = New Size(900, 560)
        Name = "AdminForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ChopBar POS | Admin"
        tabs.ResumeLayout(False)
        tpOverview.ResumeLayout(False)
        tlpOverview.ResumeLayout(False)
        cardRecent.ResumeLayout(False)
        cardRecent.PerformLayout()
        CType(gridRecent, ComponentModel.ISupportInitialize).EndInit()
        cardCategory.ResumeLayout(False)
        cardCategory.PerformLayout()
        pnlTrack1.ResumeLayout(False)
        pnlTrack2.ResumeLayout(False)
        pnlTrack3.ResumeLayout(False)
        pnlTrack4.ResumeLayout(False)
        ovRow.ResumeLayout(False)
        ovCard1.ResumeLayout(False)
        ovCard1.PerformLayout()
        ovCard2.ResumeLayout(False)
        ovCard2.PerformLayout()
        ovCard3.ResumeLayout(False)
        ovCard3.PerformLayout()
        ovCard4.ResumeLayout(False)
        ovCard4.PerformLayout()
        tpMenu.ResumeLayout(False)
        tlpMenu.ResumeLayout(False)
        cardMenuList.ResumeLayout(False)
        cardMenuList.PerformLayout()
        CType(gridMenu, ComponentModel.ISupportInitialize).EndInit()
        cardMenuForm.ResumeLayout(False)
        cardMenuForm.PerformLayout()
        tpSales.ResumeLayout(False)
        cardHistory.ResumeLayout(False)
        cardHistory.PerformLayout()
        CType(gridSales, ComponentModel.ISupportInitialize).EndInit()
        saRow.ResumeLayout(False)
        saCard1.ResumeLayout(False)
        saCard1.PerformLayout()
        saCard2.ResumeLayout(False)
        saCard2.PerformLayout()
        saCard3.ResumeLayout(False)
        saCard3.PerformLayout()
        saCard4.ResumeLayout(False)
        saCard4.PerformLayout()
        pnlFilter.ResumeLayout(False)
        pnlFilter.PerformLayout()
        tpStaff.ResumeLayout(False)
        tlpStaff.ResumeLayout(False)
        cardStaffList.ResumeLayout(False)
        cardStaffList.PerformLayout()
        CType(gridStaff, ComponentModel.ISupportInitialize).EndInit()
        cardStaffForm.ResumeLayout(False)
        cardStaffForm.PerformLayout()
        pnlHeader.ResumeLayout(False)
        pnlHeader.PerformLayout()
        ResumeLayout(False)

    End Sub

    Friend WithEvents tabs As System.Windows.Forms.TabControl
    Friend WithEvents tpOverview As System.Windows.Forms.TabPage
    Friend WithEvents tlpOverview As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cardRecent As System.Windows.Forms.Panel
    Friend WithEvents lblRecent As System.Windows.Forms.Label
    Friend WithEvents gridRecent As System.Windows.Forms.DataGridView
    Friend WithEvents col_gridRecent_0 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridRecent_1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridRecent_2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridRecent_3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridRecent_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cardCategory As System.Windows.Forms.Panel
    Friend WithEvents lblCategory As System.Windows.Forms.Label
    Friend WithEvents lblCat1 As System.Windows.Forms.Label
    Friend WithEvents pnlTrack1 As System.Windows.Forms.Panel
    Friend WithEvents pnlFill1 As System.Windows.Forms.Panel
    Friend WithEvents lblCat2 As System.Windows.Forms.Label
    Friend WithEvents pnlTrack2 As System.Windows.Forms.Panel
    Friend WithEvents pnlFill2 As System.Windows.Forms.Panel
    Friend WithEvents lblCat3 As System.Windows.Forms.Label
    Friend WithEvents pnlTrack3 As System.Windows.Forms.Panel
    Friend WithEvents pnlFill3 As System.Windows.Forms.Panel
    Friend WithEvents lblCat4 As System.Windows.Forms.Label
    Friend WithEvents pnlTrack4 As System.Windows.Forms.Panel
    Friend WithEvents pnlFill4 As System.Windows.Forms.Panel
    Friend WithEvents ovRow As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents ovCard1 As System.Windows.Forms.Panel
    Friend WithEvents ovCap1 As System.Windows.Forms.Label
    Friend WithEvents ovVal1 As System.Windows.Forms.Label
    Friend WithEvents ovCard2 As System.Windows.Forms.Panel
    Friend WithEvents ovCap2 As System.Windows.Forms.Label
    Friend WithEvents ovVal2 As System.Windows.Forms.Label
    Friend WithEvents ovCard3 As System.Windows.Forms.Panel
    Friend WithEvents ovCap3 As System.Windows.Forms.Label
    Friend WithEvents ovVal3 As System.Windows.Forms.Label
    Friend WithEvents ovCard4 As System.Windows.Forms.Panel
    Friend WithEvents ovCap4 As System.Windows.Forms.Label
    Friend WithEvents ovVal4 As System.Windows.Forms.Label
    Friend WithEvents tpMenu As System.Windows.Forms.TabPage
    Friend WithEvents tlpMenu As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cardMenuList As System.Windows.Forms.Panel
    Friend WithEvents lblMenuList As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents gridMenu As System.Windows.Forms.DataGridView
    Friend WithEvents col_gridMenu_0 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridMenu_1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridMenu_2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridMenu_3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cardMenuForm As System.Windows.Forms.Panel
    Friend WithEvents lblMenuForm As System.Windows.Forms.Label
    Friend WithEvents lblItemName As System.Windows.Forms.Label
    Friend WithEvents txtItemName As System.Windows.Forms.TextBox
    Friend WithEvents lblCategoryCap As System.Windows.Forms.Label
    Friend WithEvents cboCategory As System.Windows.Forms.ComboBox
    Friend WithEvents lblPriceCap As System.Windows.Forms.Label
    Friend WithEvents txtPrice As System.Windows.Forms.TextBox
    Friend WithEvents btnSaveItem As System.Windows.Forms.Button
    Friend WithEvents btnSoldOut As System.Windows.Forms.Button
    Friend WithEvents btnDeleteItem As System.Windows.Forms.Button
    Friend WithEvents tpSales As System.Windows.Forms.TabPage
    Friend WithEvents cardHistory As System.Windows.Forms.Panel
    Friend WithEvents lblHistory As System.Windows.Forms.Label
    Friend WithEvents gridSales As System.Windows.Forms.DataGridView
    Friend WithEvents col_gridSales_0 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridSales_1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridSales_2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridSales_3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridSales_4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridSales_5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridSales_6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridSales_7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents saRow As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents saCard1 As System.Windows.Forms.Panel
    Friend WithEvents saCap1 As System.Windows.Forms.Label
    Friend WithEvents saVal1 As System.Windows.Forms.Label
    Friend WithEvents saCard2 As System.Windows.Forms.Panel
    Friend WithEvents saCap2 As System.Windows.Forms.Label
    Friend WithEvents saVal2 As System.Windows.Forms.Label
    Friend WithEvents saCard3 As System.Windows.Forms.Panel
    Friend WithEvents saCap3 As System.Windows.Forms.Label
    Friend WithEvents saVal3 As System.Windows.Forms.Label
    Friend WithEvents saCard4 As System.Windows.Forms.Panel
    Friend WithEvents saCap4 As System.Windows.Forms.Label
    Friend WithEvents saVal4 As System.Windows.Forms.Label
    Friend WithEvents pnlFilter As System.Windows.Forms.Panel
    Friend WithEvents lblFrom As System.Windows.Forms.Label
    Friend WithEvents dtpFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblTo As System.Windows.Forms.Label
    Friend WithEvents dtpTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblCashierCap As System.Windows.Forms.Label
    Friend WithEvents cboCashier As System.Windows.Forms.ComboBox
    Friend WithEvents btnFilter As System.Windows.Forms.Button
    Friend WithEvents btnDaily As System.Windows.Forms.Button
    Friend WithEvents btnExport As System.Windows.Forms.Button
    Friend WithEvents tpStaff As System.Windows.Forms.TabPage
    Friend WithEvents tlpStaff As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cardStaffList As System.Windows.Forms.Panel
    Friend WithEvents lblStaffList As System.Windows.Forms.Label
    Friend WithEvents gridStaff As System.Windows.Forms.DataGridView
    Friend WithEvents col_gridStaff_0 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridStaff_1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridStaff_2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gridStaff_3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cardStaffForm As System.Windows.Forms.Panel
    Friend WithEvents lblStaffForm As System.Windows.Forms.Label
    Friend WithEvents lblUsernameCap As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents lblPasswordCap As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents lblRoleCap As System.Windows.Forms.Label
    Friend WithEvents cboRole As System.Windows.Forms.ComboBox
    Friend WithEvents btnSaveAccount As System.Windows.Forms.Button
    Friend WithEvents btnResetPwd As System.Windows.Forms.Button
    Friend WithEvents btnDisable As System.Windows.Forms.Button
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblHeaderRight As System.Windows.Forms.Label
    Friend WithEvents btnLogout As Button
End Class
