﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        lblTagLine = New Label()
        lblBrandName = New Label()
        lblBrandIcon = New Label()
        lblWelcome = New Label()
        lblSub = New Label()
        lblUserCap = New Label()
        txtUsername = New TextBox()
        txtPassword = New TextBox()
        lblPassCap = New Label()
        chkShow = New CheckBox()
        btnLogin = New Button()
        lblHint = New Label()
        lblError = New Label()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        Panel1.Controls.Add(lblTagLine)
        Panel1.Controls.Add(lblBrandName)
        Panel1.Controls.Add(lblBrandIcon)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(380, 513)
        Panel1.TabIndex = 0
        ' 
        ' lblTagLine
        ' 
        lblTagLine.AutoSize = True
        lblTagLine.Font = New Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTagLine.ForeColor = Color.White
        lblTagLine.Location = New Point(40, 295)
        lblTagLine.Name = "lblTagLine"
        lblTagLine.Size = New Size(257, 25)
        lblTagLine.TabIndex = 2
        lblTagLine.Text = "Chop bar order && sales system"
        ' 
        ' lblBrandName
        ' 
        lblBrandName.AutoSize = True
        lblBrandName.Font = New Font("Segoe UI", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblBrandName.ForeColor = Color.FromArgb(CByte(245), CByte(183), CByte(0))
        lblBrandName.Location = New Point(30, 215)
        lblBrandName.Name = "lblBrandName"
        lblBrandName.Size = New Size(299, 60)
        lblBrandName.TabIndex = 1
        lblBrandName.Text = "ChopBar POS"
        ' 
        ' lblBrandIcon
        ' 
        lblBrandIcon.AutoSize = True
        lblBrandIcon.BackColor = Color.Transparent
        lblBrandIcon.Font = New Font("Segoe UI Emoji", 43.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblBrandIcon.ForeColor = Color.White
        lblBrandIcon.Location = New Point(30, 120)
        lblBrandIcon.Name = "lblBrandIcon"
        lblBrandIcon.Size = New Size(142, 97)
        lblBrandIcon.TabIndex = 0
        lblBrandIcon.Text = "🍴"
        ' 
        ' lblWelcome
        ' 
        lblWelcome.AutoSize = True
        lblWelcome.Font = New Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblWelcome.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(51))
        lblWelcome.Location = New Point(440, 80)
        lblWelcome.Name = "lblWelcome"
        lblWelcome.Size = New Size(250, 46)
        lblWelcome.TabIndex = 3
        lblWelcome.Text = "Welcome back"
        ' 
        ' lblSub
        ' 
        lblSub.AutoSize = True
        lblSub.Font = New Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblSub.ForeColor = Color.FromArgb(CByte(107), CByte(114), CByte(128))
        lblSub.Location = New Point(443, 130)
        lblSub.Name = "lblSub"
        lblSub.Size = New Size(155, 23)
        lblSub.TabIndex = 4
        lblSub.Text = "Sign in to continue"
        ' 
        ' lblUserCap
        ' 
        lblUserCap.AutoSize = True
        lblUserCap.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblUserCap.Location = New Point(440, 180)
        lblUserCap.Name = "lblUserCap"
        lblUserCap.Size = New Size(89, 23)
        lblUserCap.TabIndex = 5
        lblUserCap.Text = "Username"
        ' 
        ' txtUsername
        ' 
        txtUsername.BorderStyle = BorderStyle.FixedSingle
        txtUsername.Font = New Font("Segoe UI", 12.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtUsername.ForeColor = Color.FromArgb(CByte(107), CByte(114), CByte(128))
        txtUsername.Location = New Point(440, 206)
        txtUsername.MaxLength = 20
        txtUsername.Name = "txtUsername"
        txtUsername.PlaceholderText = "Enter username"
        txtUsername.Size = New Size(360, 34)
        txtUsername.TabIndex = 6
        ' 
        ' txtPassword
        ' 
        txtPassword.BorderStyle = BorderStyle.FixedSingle
        txtPassword.Font = New Font("Segoe UI", 12.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPassword.Location = New Point(440, 286)
        txtPassword.MaxLength = 20
        txtPassword.Name = "txtPassword"
        txtPassword.PlaceholderText = "Enter password"
        txtPassword.Size = New Size(360, 34)
        txtPassword.TabIndex = 7
        txtPassword.UseSystemPasswordChar = True
        ' 
        ' lblPassCap
        ' 
        lblPassCap.AutoSize = True
        lblPassCap.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblPassCap.Location = New Point(440, 260)
        lblPassCap.Name = "lblPassCap"
        lblPassCap.Size = New Size(85, 23)
        lblPassCap.TabIndex = 8
        lblPassCap.Text = "Password"
        ' 
        ' chkShow
        ' 
        chkShow.AutoSize = True
        chkShow.Location = New Point(440, 330)
        chkShow.Name = "chkShow"
        chkShow.Size = New Size(134, 24)
        chkShow.TabIndex = 9
        chkShow.Text = "Show password"
        chkShow.UseVisualStyleBackColor = True
        ' 
        ' btnLogin
        ' 
        btnLogin.BackColor = Color.FromArgb(CByte(14), CByte(90), CByte(58))
        btnLogin.Cursor = Cursors.Hand
        btnLogin.FlatAppearance.BorderSize = 0
        btnLogin.FlatStyle = FlatStyle.Flat
        btnLogin.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogin.ForeColor = Color.White
        btnLogin.Location = New Point(440, 392)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(360, 44)
        btnLogin.TabIndex = 10
        btnLogin.Text = "Login"
        btnLogin.UseVisualStyleBackColor = False
        ' 
        ' lblHint
        ' 
        lblHint.AutoSize = True
        lblHint.Location = New Point(440, 452)
        lblHint.Name = "lblHint"
        lblHint.Size = New Size(283, 40)
        lblHint.TabIndex = 11
        lblHint.Text = "Demo: admin / admin123 | cashier / 1234" & vbCrLf & vbCrLf
        ' 
        ' lblError
        ' 
        lblError.BackColor = Color.White
        lblError.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblError.ForeColor = Color.FromArgb(CByte(192), CByte(57), CByte(43))
        lblError.Location = New Point(440, 360)
        lblError.Name = "lblError"
        lblError.Size = New Size(360, 24)
        lblError.TabIndex = 12
        lblError.Visible = False
        ' 
        ' frmLogin
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(842, 513)
        Controls.Add(lblError)
        Controls.Add(lblHint)
        Controls.Add(btnLogin)
        Controls.Add(chkShow)
        Controls.Add(lblPassCap)
        Controls.Add(txtPassword)
        Controls.Add(txtUsername)
        Controls.Add(lblUserCap)
        Controls.Add(lblSub)
        Controls.Add(lblWelcome)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.FixedDialog
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmLogin"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ChopBar POS - Login"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblBrandIcon As Label
    Friend WithEvents lblTagLine As Label
    Friend WithEvents lblBrandName As Label
    Friend WithEvents lblWelcome As Label
    Friend WithEvents lblSub As Label
    Friend WithEvents lblUserCap As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents lblPassCap As Label
    Friend WithEvents chkShow As CheckBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents lblHint As Label
    Friend WithEvents lblError As Label
End Class
